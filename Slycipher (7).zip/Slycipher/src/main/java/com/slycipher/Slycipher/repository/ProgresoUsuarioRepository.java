package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.ProgresoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProgresoUsuarioRepository extends JpaRepository<ProgresoUsuario, Long> {
    List<ProgresoUsuario> findByUserId(Long userId);
    List<ProgresoUsuario> findByLessonId(Long lessonId);
    Optional<ProgresoUsuario> findByUserIdAndLessonId(Long userId, Long lessonId);
}
