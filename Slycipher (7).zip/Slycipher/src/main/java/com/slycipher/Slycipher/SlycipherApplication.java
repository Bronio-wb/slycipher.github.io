package com.slycipher.Slycipher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlycipherApplication {

	public static void main(String[] args) {
		SpringApplication.run(SlycipherApplication.class, args);
	}

}
