package com.slycipher.Slycipher.dto;

public class CategoriaDTO {
    private Long categoryId;
    private String nombre;

    // Constructores
    public CategoriaDTO() {}

    public CategoriaDTO(Long categoryId, String nombre) {
        this.categoryId = categoryId;
        this.nombre = nombre;
    }

    // Getters y Setters
    public Long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Long categoryId) {
        this.categoryId = categoryId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
