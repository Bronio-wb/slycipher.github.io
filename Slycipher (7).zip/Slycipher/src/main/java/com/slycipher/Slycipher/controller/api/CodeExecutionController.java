package com.slycipher.Slycipher.controller.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.*;

@RestController
@RequestMapping("/api/execute")
public class CodeExecutionController {

    private static final int TIMEOUT_SECONDS = 10;
    private static final String TEMP_DIR = System.getProperty("java.io.tmpdir");

    @PostMapping("/python")
    public ResponseEntity<Map<String, Object>> executePythonCode(@RequestBody Map<String, String> request) {
        String code = request.get("code");
        Map<String, Object> response = new HashMap<>();

        if (code == null || code.trim().isEmpty()) {
            response.put("success", false);
            response.put("output", "");
            response.put("error", "No se proporcionó código para ejecutar");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            // Crear archivo temporal con código
            String fileName = "code_" + UUID.randomUUID().toString() + ".py";
            Path tempFile = Paths.get(TEMP_DIR, fileName);
            Files.write(tempFile, code.getBytes());

            // Verificar si Python está instalado
            String pythonCommand = getPythonCommand();
            if (pythonCommand == null) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Python no está instalado o no está en el PATH del sistema.\n\n" +
                        "Por favor instala Python desde: https://www.python.org/downloads/\n" +
                        "Asegúrate de marcar 'Add Python to PATH' durante la instalación.");
                return ResponseEntity.ok(response);
            }

            // Ejecutar código con timeout
            ExecutorService executor = Executors.newSingleThreadExecutor();
            Future<ProcessResult> future = executor.submit(() -> executeProcess(pythonCommand, tempFile.toString()));

            try {
                ProcessResult result = future.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                
                response.put("success", result.exitCode == 0);
                response.put("output", result.output);
                response.put("error", result.error);
                
            } catch (TimeoutException e) {
                future.cancel(true);
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Tiempo de ejecución excedido (" + TIMEOUT_SECONDS + " segundos)");
            } catch (Exception e) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Error al ejecutar el código: " + e.getMessage());
            } finally {
                executor.shutdownNow();
            }

            // Limpiar archivo temporal
            try {
                Files.deleteIfExists(tempFile);
            } catch (IOException e) {
                // Ignorar error al eliminar archivo temporal
            }

        } catch (Exception e) {
            response.put("success", false);
            response.put("output", "");
            response.put("error", "Error interno: " + e.getMessage());
        }

        return ResponseEntity.ok(response);
    }

    @PostMapping("/java")
    public ResponseEntity<Map<String, Object>> executeJavaCode(@RequestBody Map<String, String> request) {
        String code = request.get("code");
        Map<String, Object> response = new HashMap<>();

        if (code == null || code.trim().isEmpty()) {
            response.put("success", false);
            response.put("output", "");
            response.put("error", "No se proporcionó código para ejecutar");
            return ResponseEntity.badRequest().body(response);
        }

        try {
            // Extraer el nombre de la clase del código
            String className = extractClassName(code);
            if (className == null) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "No se pudo detectar el nombre de la clase pública. Asegúrate de tener una clase pública.");
                return ResponseEntity.ok(response);
            }

            // Crear directorio temporal para el código Java
            String tempDirName = "java_" + UUID.randomUUID().toString();
            Path tempDir = Paths.get(TEMP_DIR, tempDirName);
            Files.createDirectories(tempDir);

            // Crear archivo con el código
            String fileName = className + ".java";
            Path tempFile = Paths.get(tempDir.toString(), fileName);
            Files.write(tempFile, code.getBytes());

            // Verificar si Java está instalado
            if (!isJavaInstalled()) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Java no está instalado o no está en el PATH del sistema.\n\n" +
                        "Por favor instala Java JDK desde: https://www.oracle.com/java/technologies/downloads/");
                deleteDirectory(tempDir);
                return ResponseEntity.ok(response);
            }

            ExecutorService executor = Executors.newSingleThreadExecutor();
            
            try {
                // Compilar el código
                Future<ProcessResult> compileFuture = executor.submit(() -> 
                    executeJavaProcess("javac", tempFile.toString()));
                
                ProcessResult compileResult = compileFuture.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                
                if (compileResult.exitCode != 0) {
                    response.put("success", false);
                    response.put("output", "");
                    response.put("error", "Error de compilación:\n" + compileResult.error);
                    return ResponseEntity.ok(response);
                }

                // Ejecutar el código compilado
                Future<ProcessResult> runFuture = executor.submit(() -> 
                    executeJavaProcess("java", "-cp", tempDir.toString(), className));
                
                ProcessResult runResult = runFuture.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
                
                response.put("success", runResult.exitCode == 0);
                response.put("output", runResult.output);
                response.put("error", runResult.error);
                
            } catch (TimeoutException e) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Tiempo de ejecución excedido (" + TIMEOUT_SECONDS + " segundos)");
            } catch (Exception e) {
                response.put("success", false);
                response.put("output", "");
                response.put("error", "Error al ejecutar el código: " + e.getMessage());
            } finally {
                executor.shutdownNow();
                // Limpiar archivos temporales
                try {
                    deleteDirectory(tempDir);
                } catch (IOException e) {
                    // Ignorar error al eliminar
                }
            }

        } catch (Exception e) {
            response.put("success", false);
            response.put("output", "");
            response.put("error", "Error interno: " + e.getMessage());
        }

        return ResponseEntity.ok(response);
    }

    private String extractClassName(String code) {
        // Buscar "public class NombreClase"
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("public\\s+class\\s+(\\w+)");
        java.util.regex.Matcher matcher = pattern.matcher(code);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return null;
    }

    private boolean isJavaInstalled() {
        try {
            Process process = Runtime.getRuntime().exec("javac -version");
            process.waitFor(2, TimeUnit.SECONDS);
            return process.exitValue() == 0;
        } catch (Exception e) {
            return false;
        }
    }

    private ProcessResult executeJavaProcess(String... commands) throws IOException, InterruptedException {
        ProcessBuilder processBuilder = new ProcessBuilder(commands);
        processBuilder.redirectErrorStream(false);
        
        Process process = processBuilder.start();
        
        // Leer salida estándar
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        
        // Leer salida de error
        StringBuilder error = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                error.append(line).append("\n");
            }
        }
        
        process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        int exitCode = process.exitValue();
        
        return new ProcessResult(exitCode, output.toString(), error.toString());
    }

    private void deleteDirectory(Path path) throws IOException {
        if (Files.exists(path)) {
            Files.walk(path)
                .sorted(java.util.Comparator.reverseOrder())
                .forEach(p -> {
                    try {
                        Files.delete(p);
                    } catch (IOException e) {
                        // Ignorar
                    }
                });
        }
    }

    private String getPythonCommand() {
        // Intentar diferentes comandos de Python
        String[] commands = {"python", "python3", "py"};
        
        for (String cmd : commands) {
            try {
                Process process = Runtime.getRuntime().exec(cmd + " --version");
                process.waitFor(2, TimeUnit.SECONDS);
                if (process.exitValue() == 0) {
                    return cmd;
                }
            } catch (Exception e) {
                // Continuar con el siguiente comando
            }
        }
        
        return null;
    }

    private ProcessResult executeProcess(String pythonCommand, String filePath) throws IOException, InterruptedException {
        ProcessBuilder processBuilder = new ProcessBuilder(pythonCommand, filePath);
        processBuilder.redirectErrorStream(false);
        
        Process process = processBuilder.start();
        
        // Leer salida estándar
        StringBuilder output = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        
        // Leer salida de error
        StringBuilder error = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                error.append(line).append("\n");
            }
        }
        
        process.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        int exitCode = process.exitValue();
        
        return new ProcessResult(exitCode, output.toString(), error.toString());
    }

    private static class ProcessResult {
        int exitCode;
        String output;
        String error;

        ProcessResult(int exitCode, String output, String error) {
            this.exitCode = exitCode;
            this.output = output;
            this.error = error;
        }
    }
}
