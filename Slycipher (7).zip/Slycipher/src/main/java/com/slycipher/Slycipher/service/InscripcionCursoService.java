package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.InscripcionCurso;
import com.slycipher.Slycipher.repository.InscripcionCursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class InscripcionCursoService {
    
    @Autowired
    private InscripcionCursoRepository inscripcionCursoRepository;
    
    /**
     * Inscribir un usuario a un curso
     */
    @Transactional
    public InscripcionCurso inscribirUsuario(Integer usuarioId, Integer cursoId) {
        // Verificar si ya está inscrito
        if (estaInscrito(usuarioId, cursoId)) {
            throw new RuntimeException("El usuario ya está inscrito en este curso");
        }
        
        InscripcionCurso inscripcion = new InscripcionCurso(usuarioId, cursoId);
        return inscripcionCursoRepository.save(inscripcion);
    }
    
    /**
     * Verificar si un usuario está inscrito en un curso
     */
    public boolean estaInscrito(Integer usuarioId, Integer cursoId) {
        return inscripcionCursoRepository.existsByUsuarioIdAndCursoId(usuarioId, cursoId);
    }
    
    /**
     * Obtener inscripción específica
     */
    public Optional<InscripcionCurso> getInscripcion(Integer usuarioId, Integer cursoId) {
        return inscripcionCursoRepository.findByUsuarioIdAndCursoId(usuarioId, cursoId);
    }
    
    /**
     * Obtener todas las inscripciones de un usuario
     */
    public List<InscripcionCurso> getInscripcionesByUsuario(Integer usuarioId) {
        return inscripcionCursoRepository.findByUsuarioId(usuarioId);
    }
    
    /**
     * Obtener inscripciones activas de un usuario
     */
    public List<InscripcionCurso> getInscripcionesActivasByUsuario(Integer usuarioId) {
        return inscripcionCursoRepository.findByUsuarioIdAndEstado(usuarioId, "activo");
    }
    
    /**
     * Obtener todos los estudiantes inscritos en un curso
     */
    public List<InscripcionCurso> getInscripcionesByCurso(Integer cursoId) {
        return inscripcionCursoRepository.findByCursoId(cursoId);
    }
    
    /**
     * Contar inscripciones de un curso
     */
    public long contarInscripcionesCurso(Integer cursoId) {
        return inscripcionCursoRepository.countByCursoId(cursoId);
    }
    
    /**
     * Contar inscripciones activas de un usuario
     */
    public long contarInscripcionesActivas(Integer usuarioId) {
        return inscripcionCursoRepository.countByUsuarioIdAndEstado(usuarioId, "activo");
    }
    
    /**
     * Actualizar progreso de una inscripción
     */
    @Transactional
    public void actualizarProgreso(Integer usuarioId, Integer cursoId, int progreso) {
        Optional<InscripcionCurso> inscripcionOpt = inscripcionCursoRepository.findByUsuarioIdAndCursoId(usuarioId, cursoId);
        if (inscripcionOpt.isPresent()) {
            InscripcionCurso inscripcion = inscripcionOpt.get();
            inscripcion.setProgreso(progreso);
            inscripcion.setUltimaActividad(LocalDateTime.now());
            
            // Si completó el 100%, marcar como completado
            if (progreso >= 100) {
                inscripcion.setEstado("completado");
            }
            
            inscripcionCursoRepository.save(inscripcion);
        }
    }
    
    /**
     * Actualizar última actividad
     */
    @Transactional
    public void actualizarUltimaActividad(Integer usuarioId, Integer cursoId) {
        Optional<InscripcionCurso> inscripcionOpt = inscripcionCursoRepository.findByUsuarioIdAndCursoId(usuarioId, cursoId);
        if (inscripcionOpt.isPresent()) {
            InscripcionCurso inscripcion = inscripcionOpt.get();
            inscripcion.setUltimaActividad(LocalDateTime.now());
            inscripcionCursoRepository.save(inscripcion);
        }
    }
    
    /**
     * Cancelar inscripción (marcar como abandonado)
     */
    @Transactional
    public void cancelarInscripcion(Integer usuarioId, Integer cursoId) {
        Optional<InscripcionCurso> inscripcionOpt = inscripcionCursoRepository.findByUsuarioIdAndCursoId(usuarioId, cursoId);
        if (inscripcionOpt.isPresent()) {
            InscripcionCurso inscripcion = inscripcionOpt.get();
            inscripcion.setEstado("abandonado");
            inscripcionCursoRepository.save(inscripcion);
        }
    }
    
    /**
     * Obtener inscripciones recientes de un usuario
     */
    public List<InscripcionCurso> getInscripcionesRecientes(Integer usuarioId) {
        return inscripcionCursoRepository.findRecentInscripcionesByUsuarioId(usuarioId);
    }
}
