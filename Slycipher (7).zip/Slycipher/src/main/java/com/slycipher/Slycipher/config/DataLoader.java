package com.slycipher.Slycipher.config;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Lenguaje;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.repository.CursoRepository;
import com.slycipher.Slycipher.repository.LenguajeRepository;
import com.slycipher.Slycipher.repository.UsuarioRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataLoader {

    @Bean
    public CommandLineRunner loadInitialData(UsuarioRepository usuarioRepo, LenguajeRepository lenguajeRepo, CursoRepository cursoRepo, PasswordEncoder passwordEncoder) {
        return args -> {
            // Verificar y crear usuarios de prueba solo si no existen
            System.out.println("\n===========================================");
            System.out.println("Verificando usuarios de prueba...");
            
            // Admin
            if (usuarioRepo.findByUsername("admin") == null) {
                Usuario admin = new Usuario();
                admin.setUsername("admin");
                admin.setNombre("Administrador");
                admin.setApellido("Sistema");
                admin.setEmail("admin@slycipher.com");
                admin.setPasswordHash(passwordEncoder.encode("admin123"));
                admin.setRol("ADMIN");
                admin.setCreadoEn(LocalDateTime.now());
                admin.setActivo(true);
                usuarioRepo.save(admin);
                System.out.println("✅ Usuario Admin creado: admin / admin123");
            } else {
                System.out.println("ℹ️  Usuario admin ya existe");
            }
            
            // Desarrollador
            if (usuarioRepo.findByUsername("developer") == null) {
                Usuario developer = new Usuario();
                developer.setUsername("developer");
                developer.setNombre("Juan");
                developer.setApellido("Developer");
                developer.setEmail("developer@slycipher.com");
                developer.setPasswordHash(passwordEncoder.encode("dev123"));
                developer.setRol("DEVELOPER");
                developer.setCreadoEn(LocalDateTime.now());
                developer.setActivo(true);
                usuarioRepo.save(developer);
                System.out.println("✅ Usuario Developer creado: developer / dev123");
            } else {
                System.out.println("ℹ️  Usuario developer ya existe");
            }
            
            // Estudiante
            if (usuarioRepo.findByUsername("student") == null) {
                Usuario student = new Usuario();
                student.setUsername("student");
                student.setNombre("María");
                student.setApellido("Estudiante");
                student.setEmail("student@slycipher.com");
                student.setPasswordHash(passwordEncoder.encode("student123"));
                student.setRol("STUDENT");
                student.setCreadoEn(LocalDateTime.now());
                student.setActivo(true);
                usuarioRepo.save(student);
                System.out.println("✅ Usuario Student creado: student / student123");
            } else {
                System.out.println("ℹ️  Usuario student ya existe");
            }
            
            // Usuario demo
            if (usuarioRepo.findByUsername("demo") == null) {
                Usuario demo = new Usuario();
                demo.setUsername("demo");
                demo.setNombre("Demo");
                demo.setApellido("User");
                demo.setEmail("demo@example.com");
                demo.setPasswordHash(passwordEncoder.encode("demo123"));
                demo.setRol("USER");
                demo.setCreadoEn(LocalDateTime.now());
                demo.setActivo(true);
                usuarioRepo.save(demo);
                System.out.println("✅ Usuario Demo creado: demo / demo123");
            } else {
                System.out.println("ℹ️  Usuario demo ya existe");
            }
            
            // Admin1 - Juan Lopez
            if (usuarioRepo.findByEmail("admin1@example.com").isEmpty()) {
                Usuario admin1 = new Usuario();
                admin1.setUsername("juanlopez");
                admin1.setNombre("Juan");
                admin1.setApellido("Lopez");
                admin1.setEmail("admin1@example.com");
                admin1.setPasswordHash(passwordEncoder.encode("Adminsly123!"));
                admin1.setRol("ADMIN");
                admin1.setCreadoEn(LocalDateTime.now());
                admin1.setActivo(true);
                usuarioRepo.save(admin1);
                System.out.println("✅ Usuario Admin1 creado: admin1@example.com / Adminsly123!");
            } else {
                System.out.println("ℹ️  Usuario admin1@example.com ya existe");
            }
            
            // Developer1
            if (usuarioRepo.findByEmail("dev1@example.com").isEmpty()) {
                Usuario dev1 = new Usuario();
                dev1.setUsername("developer1");
                dev1.setNombre("Carlos");
                dev1.setApellido("Desarrollador");
                dev1.setEmail("dev1@example.com");
                dev1.setPasswordHash(passwordEncoder.encode("Devsly123!"));
                dev1.setRol("DEVELOPER");
                dev1.setCreadoEn(LocalDateTime.now());
                dev1.setActivo(true);
                usuarioRepo.save(dev1);
                System.out.println("✅ Usuario Developer1 creado: dev1@example.com / Devsly123!");
            } else {
                System.out.println("ℹ️  Usuario dev1@example.com ya existe");
            }
            
            // Student1
            if (usuarioRepo.findByEmail("est1@example.com").isEmpty()) {
                Usuario est1 = new Usuario();
                est1.setUsername("estudiante1");
                est1.setNombre("Ana");
                est1.setApellido("Estudiante");
                est1.setEmail("est1@example.com");
                est1.setPasswordHash(passwordEncoder.encode("Estsly123*"));
                est1.setRol("STUDENT");
                est1.setCreadoEn(LocalDateTime.now());
                est1.setActivo(true);
                usuarioRepo.save(est1);
                System.out.println("✅ Usuario Student1 creado: est1@example.com / Estsly123*");
            } else {
                System.out.println("ℹ️  Usuario est1@example.com ya existe");
            }
            
            System.out.println("\nUSUARIOS DE PRUEBA DISPONIBLES:");
            System.out.println("1. Admin:       admin / admin123");
            System.out.println("2. Developer:   developer / dev123");
            System.out.println("3. Student:     student / student123");
            System.out.println("4. Demo:        demo / demo123");
            System.out.println("5. Admin1:      admin1@example.com / Adminsly123!");
            System.out.println("6. Developer1:  dev1@example.com / Devsly123!");
            System.out.println("7. Student1:    est1@example.com / Estsly123*");
            System.out.println("===========================================\n");

            if (lenguajeRepo.count() == 0) {
                Lenguaje l = new Lenguaje();
                l.setNombre("Java");
                l.setDescripcion("Lenguaje Java");
                lenguajeRepo.save(l);
            }

            if (cursoRepo.count() == 0) {
                Lenguaje java = lenguajeRepo.findAll().stream().findFirst().orElse(null);
                Curso c = new Curso();
                c.setTitulo("Introducción a Java");
                c.setDescripcion("Curso básico de Java");
                c.setNivel("Principiante");
                if (java != null) c.setLanguageId(java.getLanguageId());
                c.setFechaCreacion(LocalDateTime.now());
                c.setPrecio(new BigDecimal("0.00"));
                cursoRepo.save(c);
            }
        };
    }
}
