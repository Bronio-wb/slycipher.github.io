package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import jakarta.persistence.FetchType;

@Entity
@Table(name = "desafio_usuarios")
public class DesafioUsuario {
    @Id
    @Column(name = "submission_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long submissionId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "challenge_id")
    private Long challengeId;

    @Column(name = "solucion_enviada", columnDefinition = "TEXT")
    private String solucionEnviada;

    private String estado;
    private Integer puntaje;

    @Column(name = "enviado_en")
    private LocalDateTime enviadoEn;

    @Column(name = "evaluado_en")
    private LocalDateTime evaluadoEn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "challenge_id", insertable = false, updatable = false)
    private Desafio desafio;

    // getters/setters
    public Long getSubmissionId() { return submissionId; }
    public void setSubmissionId(Long submissionId) { this.submissionId = submissionId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getChallengeId() { return challengeId; }
    public void setChallengeId(Long challengeId) { this.challengeId = challengeId; }
    public String getSolucionEnviada() { return solucionEnviada; }
    public void setSolucionEnviada(String solucionEnviada) { this.solucionEnviada = solucionEnviada; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Integer getPuntaje() { return puntaje; }
    public void setPuntaje(Integer puntaje) { this.puntaje = puntaje; }
    public LocalDateTime getEnviadoEn() { return enviadoEn; }
    public void setEnviadoEn(LocalDateTime enviadoEn) { this.enviadoEn = enviadoEn; }
    public LocalDateTime getEvaluadoEn() { return evaluadoEn; }
    public void setEvaluadoEn(LocalDateTime evaluadoEn) { this.evaluadoEn = evaluadoEn; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public Desafio getDesafio() { return desafio; }
    public void setDesafio(Desafio desafio) { this.desafio = desafio; }
}
