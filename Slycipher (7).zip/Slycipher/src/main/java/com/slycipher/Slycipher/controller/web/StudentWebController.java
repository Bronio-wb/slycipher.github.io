package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Leccion;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.model.Desafio;
import com.slycipher.Slycipher.model.InscripcionCurso;
import com.slycipher.Slycipher.model.DesafioUsuario;
import com.slycipher.Slycipher.service.CursoService;
import com.slycipher.Slycipher.service.LeccionService;
import com.slycipher.Slycipher.service.ProgresoUsuarioService;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.DesafioService;
import com.slycipher.Slycipher.service.InscripcionCursoService;
import com.slycipher.Slycipher.repository.DesafioUsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentWebController {

    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private LeccionService leccionService;
    
    @Autowired
    private ProgresoUsuarioService progresoUsuarioService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private DesafioService desafioService;
    
    @Autowired
    private InscripcionCursoService inscripcionCursoService;
    
    @Autowired
    private DesafioUsuarioRepository desafioUsuarioRepository;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener solo cursos aprobados y visibles (máximo 6 para el dashboard)
        List<Curso> cursosDisponibles = cursoService.getApprovedAndVisibleCursos();
        model.addAttribute("cursosDisponibles", cursosDisponibles.stream().limit(6).collect(java.util.stream.Collectors.toList()));
        
        // Obtener progreso del estudiante
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        model.addAttribute("progresosRecientes", progresos.stream().limit(5).collect(java.util.stream.Collectors.toList()));
        
        // Obtener cursos inscritos
        List<InscripcionCurso> inscripciones = inscripcionCursoService.getInscripcionesActivasByUsuario(usuario.getUserId().intValue());
        model.addAttribute("cursosInscritos", inscripciones.size());
        model.addAttribute("inscripcionesRecientes", inscripciones.stream().limit(6).collect(java.util.stream.Collectors.toList()));
        
        // Estadísticas del estudiante
        model.addAttribute("logros", progresos.size());
        model.addAttribute("puntos", 0); // TODO: Implementar desafíos
        
        return "student/dashboard";
    }
    
    @GetMapping("/cursos")
    public String cursos(Model model, Authentication authentication) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", authentication.getName());
        
        // Obtener solo cursos aprobados y visibles
        List<Curso> cursosDisponibles = cursoService.getApprovedAndVisibleCursos();
        model.addAttribute("cursos", cursosDisponibles);
        
        // Obtener inscripciones del usuario para mostrar estado
        List<InscripcionCurso> inscripciones = inscripcionCursoService.getInscripcionesByUsuario(usuario.getUserId().intValue());
        model.addAttribute("inscripciones", inscripciones);
        
        return "student/cursos";
    }
    
    @GetMapping("/cursos/{id}")
    public String verCurso(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null || !"aprobada".equals(curso.getEstado()) || !Boolean.TRUE.equals(curso.getVisible())) {
            return "redirect:/student/cursos";
        }
        
        model.addAttribute("curso", curso);
        
        // Verificar si el usuario está inscrito
        boolean estaInscrito = inscripcionCursoService.estaInscrito(usuario.getUserId().intValue(), id.intValue());
        model.addAttribute("estaInscrito", estaInscrito);
        
        // Si está inscrito, obtener las lecciones
        if (estaInscrito) {
            List<Leccion> lecciones = leccionService.findByCursoId(id)
                .stream()
                .filter(l -> Boolean.TRUE.equals(l.getVisible()))
                .sorted((l1, l2) -> {
                    Integer orden1 = l1.getOrden() != null ? l1.getOrden() : 0;
                    Integer orden2 = l2.getOrden() != null ? l2.getOrden() : 0;
                    return orden1.compareTo(orden2);
                })
                .collect(java.util.stream.Collectors.toList());
            model.addAttribute("lecciones", lecciones);
        }
        
        return "student/ver-curso";
    }
    
    @PostMapping("/cursos/{id}/inscribir")
    public String inscribirseCurso(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null || !"aprobada".equals(curso.getEstado()) || !Boolean.TRUE.equals(curso.getVisible())) {
            redirectAttributes.addFlashAttribute("error", "El curso no está disponible");
            return "redirect:/student/cursos";
        }
        
        try {
            // Verificar si ya está inscrito
            if (inscripcionCursoService.estaInscrito(usuario.getUserId().intValue(), id.intValue())) {
                redirectAttributes.addFlashAttribute("info", "Ya estás inscrito en este curso");
            } else {
                // Inscribir al usuario
                inscripcionCursoService.inscribirUsuario(usuario.getUserId().intValue(), id.intValue());
                redirectAttributes.addFlashAttribute("success", "¡Te has inscrito exitosamente al curso: " + curso.getTitulo() + "!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al inscribirse: " + e.getMessage());
        }
        
        return "redirect:/student/cursos/" + id;
    }
    
    @GetMapping("/lecciones/{id}")
    public String verLeccion(@PathVariable Long id, Model model, Authentication authentication, RedirectAttributes redirectAttributes) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", authentication.getName());
        
        Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null || !Boolean.TRUE.equals(leccion.getVisible())) {
            return "redirect:/student/cursos";
        }
        
        // VALIDAR QUE EL ESTUDIANTE ESTÉ INSCRITO EN EL CURSO
        boolean estaInscrito = inscripcionCursoService.estaInscrito(usuario.getUserId().intValue(), leccion.getCourseId().intValue());
        if (!estaInscrito) {
            redirectAttributes.addFlashAttribute("error", "Debes inscribirte en el curso para acceder a las lecciones");
            return "redirect:/student/cursos/" + leccion.getCourseId();
        }
        
        // Actualizar última actividad
        inscripcionCursoService.actualizarUltimaActividad(usuario.getUserId().intValue(), leccion.getCourseId().intValue());
        
        // Obtener todas las lecciones del curso ordenadas
        List<Leccion> todasLecciones = leccionService.findByCursoId(leccion.getCourseId())
            .stream()
            .filter(l -> Boolean.TRUE.equals(l.getVisible()))
            .sorted((l1, l2) -> {
                Integer orden1 = l1.getOrden() != null ? l1.getOrden() : 0;
                Integer orden2 = l2.getOrden() != null ? l2.getOrden() : 0;
                return orden1.compareTo(orden2);
            })
            .collect(java.util.stream.Collectors.toList());
        
        // Encontrar índice de la lección actual
        int currentIndex = -1;
        for (int i = 0; i < todasLecciones.size(); i++) {
            if (todasLecciones.get(i).getLeccionId().equals(id)) {
                currentIndex = i;
                break;
            }
        }
        
        // Determinar lección anterior y siguiente
        Leccion leccionAnterior = null;
        Leccion leccionSiguiente = null;
        
        if (currentIndex > 0) {
            leccionAnterior = todasLecciones.get(currentIndex - 1);
        }
        
        if (currentIndex >= 0 && currentIndex < todasLecciones.size() - 1) {
            leccionSiguiente = todasLecciones.get(currentIndex + 1);
        }
        
        model.addAttribute("leccion", leccion);
        model.addAttribute("leccionAnterior", leccionAnterior);
        model.addAttribute("leccionSiguiente", leccionSiguiente);
        
        // Obtener el lenguaje del curso de forma segura
        String lenguaje = "python"; // Por defecto
        try {
            Curso curso = cursoService.findByIdWithDetails(leccion.getCourseId()).orElse(null);
            if (curso != null && curso.getLenguaje() != null) {
                lenguaje = curso.getLenguaje().getNombre().toLowerCase();
            }
        } catch (Exception e) {
            // Si hay error, usar Python por defecto
            lenguaje = "python";
        }
        model.addAttribute("lenguaje", lenguaje);
        
        // Verificar si la lección ya está completada
        if (usuario != null) {
            boolean completada = progresoUsuarioService.isLeccionCompletada(usuario.getUserId(), id);
            model.addAttribute("leccionCompletada", completada);
        } else {
            model.addAttribute("leccionCompletada", false);
        }
        
        return "student/ver-leccion";
    }
    
    @PostMapping("/lecciones/{id}/completar")
    public String completarLeccion(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null) {
            redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
            return "redirect:/student/cursos";
        }
        
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
            return "redirect:/student/lecciones/" + id;
        }
        
        try {
            progresoUsuarioService.marcarLeccionCompletada(usuario.getUserId(), id);
            redirectAttributes.addFlashAttribute("success", "¡Lección marcada como completada!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al marcar la lección como completada");
        }
        
        return "redirect:/student/lecciones/" + id;
    }
    
    @GetMapping("/progreso")
    public String miProgreso(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener lecciones completadas
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        model.addAttribute("progresos", progresos);
        
        return "student/progreso";
    }
    
    @GetMapping("/logros")
    public String logros(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener lecciones completadas para calcular logros
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        
        return "student/logros";
    }
    
    @GetMapping("/desafios")
    public String desafios(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener todos los desafíos disponibles
        List<Desafio> desafios = desafioService.getAllDesafios();
        model.addAttribute("desafios", desafios);
        model.addAttribute("desafiosDisponibles", desafios.size());
        
        // Contar desafíos completados (estado = "aprobado")
        long desafiosCompletados = desafioUsuarioRepository.countByUserIdAndEstado(usuario.getUserId(), "aprobado");
        model.addAttribute("desafiosCompletados", desafiosCompletados);
        
        // Obtener lista de desafíos completados con toda su información
        List<DesafioUsuario> completados = desafioUsuarioRepository.findByUserId(usuario.getUserId())
            .stream()
            .filter(du -> "aprobado".equals(du.getEstado()))
            .collect(java.util.stream.Collectors.toList());
        
        // Crear map con información detallada de completados (ID -> DesafioUsuario)
        java.util.Map<Long, DesafioUsuario> desafiosCompletadosMap = completados.stream()
            .collect(java.util.stream.Collectors.toMap(
                DesafioUsuario::getChallengeId,
                du -> du,
                (existing, replacement) -> existing // En caso de duplicados, mantener el primero
            ));
        model.addAttribute("desafiosCompletadosMap", desafiosCompletadosMap);
        
        return "student/desafios";
    }
    
    @GetMapping("/desafios/{id}")
    public String verDesafio(@PathVariable Long id, Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        Desafio desafio = desafioService.getDesafioById(id);
        if (desafio == null) {
            return "redirect:/student/desafios";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        
        return "student/ver-desafio";
    }
    
    @GetMapping("/desafios/{id}/intentar")
    public String intentarDesafio(@PathVariable Long id, Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        Desafio desafio = desafioService.getDesafioById(id);
        if (desafio == null) {
            return "redirect:/student/desafios";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        
        // Determinar el lenguaje del desafío
        String lenguaje = "python"; // Por defecto
        try {
            if (desafio.getLenguaje() != null) {
                lenguaje = desafio.getLenguaje().getNombre().toLowerCase();
            }
        } catch (Exception e) {
            lenguaje = "python";
        }
        model.addAttribute("lenguaje", lenguaje);
        
        return "student/intentar-desafio";
    }
    
    @PostMapping("/desafios/ejecutar")
    @org.springframework.web.bind.annotation.ResponseBody
    public java.util.Map<String, String> ejecutarCodigo(@org.springframework.web.bind.annotation.RequestBody java.util.Map<String, String> request) {
        String codigo = request.get("codigo");
        String lenguaje = request.get("lenguaje");
        if (lenguaje == null || lenguaje.isEmpty()) {
            lenguaje = "python";
        }
        
        java.util.Map<String, String> response = new java.util.HashMap<>();
        
        if (codigo == null || codigo.trim().isEmpty()) {
            response.put("error", "No se proporcionó código para ejecutar");
            return response;
        }
        
        try {
            String salida = ejecutarCodigoInterno(codigo, lenguaje);
            response.put("salida", salida);
        } catch (Exception e) {
            response.put("error", e.getMessage());
        }
        
        return response;
    }
    
    @PostMapping("/desafios/{id}/enviar")
    @org.springframework.web.bind.annotation.ResponseBody
    public java.util.Map<String, Object> enviarSolucion(
            @PathVariable Long id,
            @org.springframework.web.bind.annotation.RequestBody java.util.Map<String, String> request,
            Authentication authentication) {
        
        java.util.Map<String, Object> response = new java.util.HashMap<>();
        
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            response.put("error", "Usuario no autenticado");
            return response;
        }
        
        Desafio desafio = desafioService.getDesafioById(id);
        if (desafio == null) {
            response.put("error", "Desafío no encontrado");
            return response;
        }
        
        String codigo = request.get("codigo");
        if (codigo == null || codigo.trim().isEmpty()) {
            response.put("error", "No se proporcionó código para evaluar");
            return response;
        }
        
        // Determinar el lenguaje del desafío
        String lenguaje = "python";
        try {
            if (desafio.getLenguaje() != null) {
                lenguaje = desafio.getLenguaje().getNombre().toLowerCase();
                System.out.println("DEBUG: Lenguaje del desafío " + id + ": " + lenguaje);
            } else {
                System.out.println("WARN: Desafío " + id + " no tiene lenguaje asignado, usando Python por defecto");
            }
        } catch (Exception e) {
            System.out.println("ERROR: No se pudo obtener el lenguaje del desafío " + id + ": " + e.getMessage());
            lenguaje = "python";
        }
        
        try {
            // Ejecutar el código y validar
            String salida = ejecutarCodigoInterno(codigo, lenguaje);
            System.out.println("DEBUG: Código ejecutado con lenguaje: " + lenguaje);
            
            // Marcar como pendiente de revisión (el desarrollador lo evaluará)
            String estado = "pendiente";
            Integer puntaje = null; // Sin puntaje hasta que el desarrollador lo evalúe
            
            // Verificar si ya existe un intento aprobado
            boolean yaAprobado = desafioUsuarioRepository.existsByUserIdAndChallengeIdAndEstado(
                usuario.getUserId(), id, "aprobado");
            
            if (yaAprobado) {
                response.put("error", "Ya has completado este desafío exitosamente");
                response.put("yaCompletado", true);
                return response;
            }
            
            // Guardar en base de datos como pendiente
            DesafioUsuario desafioUsuario = new DesafioUsuario();
            desafioUsuario.setUserId(usuario.getUserId());
            desafioUsuario.setChallengeId(id);
            desafioUsuario.setSolucionEnviada(codigo);
            desafioUsuario.setEstado(estado);
            desafioUsuario.setPuntaje(puntaje);
            desafioUsuario.setEnviadoEn(java.time.LocalDateTime.now());
            desafioUsuario.setEvaluadoEn(null); // Se evaluará cuando el desarrollador lo revise
            
            desafioUsuarioRepository.save(desafioUsuario);
            
            response.put("pendiente", true);
            response.put("estado", estado);
            response.put("mensaje", "¡Solución enviada! Un desarrollador la revisará pronto. 📝");
            response.put("salida", salida);
            
        } catch (Exception e) {
            response.put("error", "Error al enviar la solución: " + e.getMessage());
            response.put("pendiente", false);
        }
        
        return response;
    }
    
    private String ejecutarCodigoInterno(String codigo, String lenguaje) throws Exception {
        java.io.File tempFile;
        java.io.File outputDir = null;
        
        if (lenguaje.equalsIgnoreCase("java")) {
            // Para Java, crear un directorio temporal y archivo Main.java
            outputDir = java.nio.file.Files.createTempDirectory("java_exec_").toFile();
            outputDir.deleteOnExit();
            tempFile = new java.io.File(outputDir, "Main.java");
            tempFile.deleteOnExit();
        } else {
            // Para Python, archivo temporal normal
            tempFile = java.io.File.createTempFile("codigo_", ".py");
            tempFile.deleteOnExit();
        }
        
        java.io.BufferedWriter writer = new java.io.BufferedWriter(
            new java.io.OutputStreamWriter(
                new java.io.FileOutputStream(tempFile), 
                java.nio.charset.StandardCharsets.UTF_8
            )
        );
        writer.write(codigo);
        writer.close();
        
        ProcessBuilder processBuilder;
        
        if (lenguaje.equalsIgnoreCase("java")) {
            // Compilar Java
            ProcessBuilder compileBuilder = new ProcessBuilder("javac", "-encoding", "UTF-8", tempFile.getAbsolutePath());
            compileBuilder.redirectErrorStream(true);
            Process compileProcess = compileBuilder.start();
            
            StringBuilder compileOutput = new StringBuilder();
            java.io.BufferedReader compileReader = new java.io.BufferedReader(
                new java.io.InputStreamReader(compileProcess.getInputStream(), java.nio.charset.StandardCharsets.UTF_8)
            );
            
            boolean compileFinished = compileProcess.waitFor(10, java.util.concurrent.TimeUnit.SECONDS);
            if (!compileFinished) {
                compileProcess.destroy();
                throw new Exception("Tiempo de compilación excedido");
            }
            
            String line;
            while ((line = compileReader.readLine()) != null) {
                compileOutput.append(line).append("\n");
            }
            compileReader.close();
            
            if (compileProcess.exitValue() != 0) {
                throw new Exception("Error de compilación:\n" + compileOutput.toString());
            }
            
            // Ejecutar
            String className = "Main";
            processBuilder = new ProcessBuilder("java", "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-Dstderr.encoding=UTF-8", "-cp", outputDir.getAbsolutePath(), className);
        } else {
            processBuilder = new ProcessBuilder("python", "-X", "utf8", tempFile.getAbsolutePath());
        }
        
        // Configurar variables de entorno para UTF-8
        java.util.Map<String, String> env = processBuilder.environment();
        env.put("JAVA_TOOL_OPTIONS", "-Dfile.encoding=UTF-8");
        
        processBuilder.redirectErrorStream(true);
        Process process = processBuilder.start();
        
        StringBuilder output = new StringBuilder();
        java.io.BufferedReader reader = new java.io.BufferedReader(
            new java.io.InputStreamReader(process.getInputStream(), java.nio.charset.StandardCharsets.UTF_8)
        );
        
        boolean finished = process.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);
        
        if (!finished) {
            process.destroy();
            throw new Exception("Tiempo de ejecución excedido (máximo 5 segundos)");
        }
        
        String line;
        while ((line = reader.readLine()) != null) {
            // Filtrar el mensaje de JAVA_TOOL_OPTIONS
            if (!line.startsWith("Picked up JAVA_TOOL_OPTIONS:")) {
                output.append(line).append("\n");
            }
        }
        
        int exitCode = process.exitValue();
        reader.close();
        
        // Limpiar archivos temporales
        if (lenguaje.equalsIgnoreCase("java") && outputDir != null) {
            // Eliminar archivos .class y .java
            java.io.File[] files = outputDir.listFiles();
            if (files != null) {
                for (java.io.File file : files) {
                    file.delete();
                }
            }
            outputDir.delete();
        } else {
            tempFile.delete();
        }
        
        if (exitCode != 0 && output.length() > 0) {
            throw new Exception(output.toString().trim());
        }
        
        return output.toString().trim();
    }
}
