package com.slycipher.Slycipher.security;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.repository.UsuarioRepository;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;

@Component
public class LoginSuccessHandler implements AuthenticationSuccessHandler {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        // Actualizar último login
        String username = authentication.getName();
        Usuario usuario = usuarioRepository.findByUsername(username);
        
        if (usuario != null) {
            usuario.setUltimoLogin(LocalDateTime.now());
            usuarioRepository.save(usuario);
        }

        // Redirigir según el rol del usuario
        String redirectUrl = "/home";
        if (authentication.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"))) {
            redirectUrl = "/admin/dashboard";
        } else if (authentication.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_DEVELOPER"))) {
            redirectUrl = "/developer/dashboard";
        } else if (authentication.getAuthorities().stream()
            .anyMatch(a -> a.getAuthority().equals("ROLE_STUDENT"))) {
            redirectUrl = "/student/dashboard";
        }
        
        response.sendRedirect(redirectUrl);
    }
}
