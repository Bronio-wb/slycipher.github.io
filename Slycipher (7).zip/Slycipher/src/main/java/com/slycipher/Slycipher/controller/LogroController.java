package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Logro;
import com.slycipher.Slycipher.service.LogroService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logros")
@CrossOrigin(origins = "*")
public class LogroController {
    private final LogroService logroService;

    public LogroController(LogroService logroService) {
        this.logroService = logroService;
    }

    @GetMapping
    public ResponseEntity<List<Logro>> getAllLogros() {
        return ResponseEntity.ok(logroService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Logro> getLogroById(@PathVariable Long id) {
        return logroService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Logro> createLogro(@RequestBody Logro logro) {
        Logro savedLogro = logroService.save(logro);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedLogro);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Logro> updateLogro(@PathVariable Long id, @RequestBody Logro logro) {
        try {
            Logro updatedLogro = logroService.update(id, logro);
            return ResponseEntity.ok(updatedLogro);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLogro(@PathVariable Long id) {
        try {
            logroService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
