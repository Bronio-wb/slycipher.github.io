package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "inscripciones_cursos")
public class InscripcionCurso {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "inscripcion_id")
    private Integer inscripcionId;
    
    @Column(name = "usuario_id", nullable = false)
    private Integer usuarioId;
    
    @Column(name = "curso_id", nullable = false)
    private Integer cursoId;
    
    @Column(name = "fecha_inscripcion", nullable = false)
    private LocalDateTime fechaInscripcion;
    
    @Column(name = "estado", length = 20)
    private String estado; // activo, completado, abandonado
    
    @Column(name = "progreso")
    private Integer progreso; // Porcentaje de progreso 0-100
    
    @Column(name = "ultima_actividad")
    private LocalDateTime ultimaActividad;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", insertable = false, updatable = false)
    private Usuario usuario;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "curso_id", insertable = false, updatable = false)
    private Curso curso;
    
    // Constructores
    public InscripcionCurso() {
    }
    
    public InscripcionCurso(Integer usuarioId, Integer cursoId) {
        this.usuarioId = usuarioId;
        this.cursoId = cursoId;
        this.fechaInscripcion = LocalDateTime.now();
        this.estado = "activo";
        this.progreso = 0;
        this.ultimaActividad = LocalDateTime.now();
    }
    
    // Getters y Setters
    public Integer getInscripcionId() {
        return inscripcionId;
    }
    
    public void setInscripcionId(Integer inscripcionId) {
        this.inscripcionId = inscripcionId;
    }
    
    public Integer getUsuarioId() {
        return usuarioId;
    }
    
    public void setUsuarioId(Integer usuarioId) {
        this.usuarioId = usuarioId;
    }
    
    public Integer getCursoId() {
        return cursoId;
    }
    
    public void setCursoId(Integer cursoId) {
        this.cursoId = cursoId;
    }
    
    public LocalDateTime getFechaInscripcion() {
        return fechaInscripcion;
    }
    
    public void setFechaInscripcion(LocalDateTime fechaInscripcion) {
        this.fechaInscripcion = fechaInscripcion;
    }
    
    public String getEstado() {
        return estado;
    }
    
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public Integer getProgreso() {
        return progreso;
    }
    
    public void setProgreso(Integer progreso) {
        this.progreso = progreso;
    }
    
    public LocalDateTime getUltimaActividad() {
        return ultimaActividad;
    }
    
    public void setUltimaActividad(LocalDateTime ultimaActividad) {
        this.ultimaActividad = ultimaActividad;
    }
    
    public Usuario getUsuario() {
        return usuario;
    }
    
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }
    
    public Curso getCurso() {
        return curso;
    }
    
    public void setCurso(Curso curso) {
        this.curso = curso;
    }
}
