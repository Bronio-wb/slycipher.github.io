package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Leccion;
import com.slycipher.Slycipher.repository.LeccionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LeccionService {
    private final LeccionRepository leccionRepository;

    public LeccionService(LeccionRepository leccionRepository) {
        this.leccionRepository = leccionRepository;
    }

    public List<Leccion> findAll() {
        return leccionRepository.findAll();
    }

    public Optional<Leccion> findById(Long id) {
        return leccionRepository.findByIdWithCurso(id);
    }

    public List<Leccion> findByCursoId(Long cursoId) {
        return leccionRepository.findByCourseId(cursoId);
    }

    public Leccion save(Leccion leccion) {
        return leccionRepository.save(leccion);
    }

    public Leccion update(Long id, Leccion leccionDetails) {
        Leccion leccion = leccionRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Lección no encontrada con id: " + id));
        
        leccion.setTitulo(leccionDetails.getTitulo());
        leccion.setContenido(leccionDetails.getContenido());
        leccion.setOrden(leccionDetails.getOrden());
        leccion.setEstado(leccionDetails.getEstado());
        return leccionRepository.save(leccion);
    }

    public void deleteById(Long id) {
        if (!leccionRepository.existsById(id)) {
            throw new RuntimeException("Lección no encontrada con id: " + id);
        }
        leccionRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return leccionRepository.existsById(id);
    }

    // Aliases para controladores web
    public Leccion createLeccion(Leccion leccion) {
        return save(leccion);
    }

    public Leccion getLeccionById(Long id) {
        return findById(id).orElse(null);
    }

    public List<Leccion> getAllLecciones() {
        return findAll();
    }

    public Leccion updateLeccion(Long id, Leccion leccion) {
        return update(id, leccion);
    }

    public void deleteLeccion(Long id) {
        deleteById(id);
    }
}
