package com.slycipher.Slycipher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlycipherApplicationTests {

	@Test
	void contextLoads() {
	}

}
