package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.LogroUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LogroUsuarioRepository extends JpaRepository<LogroUsuario, Long> {
    List<LogroUsuario> findByUserId(Long userId);
    List<LogroUsuario> findByAchievementId(Long achievementId);
}
