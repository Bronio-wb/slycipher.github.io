package com.slycipher.Slycipher.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.model.Curso;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ReporteService {

    // Clase interna para encabezados y pies de página
    class HeaderFooter extends PdfPageEventHelper {
        private String usuarioGenerador;
        private String fechaGeneracion;
        private String tipoReporte;
        private String formato;
        private Image logo;

        public HeaderFooter(String usuarioGenerador, String fechaGeneracion, String tipoReporte, String formato) {
            this.usuarioGenerador = usuarioGenerador;
            this.fechaGeneracion = fechaGeneracion;
            this.tipoReporte = tipoReporte;
            this.formato = formato;
            
            // Intentar cargar logo
            try {
                ClassPathResource imgFile = new ClassPathResource("static/images/logo.png");
                if (imgFile.exists()) {
                    logo = Image.getInstance(imgFile.getURL());
                    logo.scaleToFit(50, 50);
                }
            } catch (Exception e) {
                logo = null;
            }
        }

        @Override
        public void onEndPage(PdfWriter writer, Document document) {
            try {
                PdfContentByte cb = writer.getDirectContent();
                
                // Footer
                com.itextpdf.text.Font footerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 8, com.itextpdf.text.Font.NORMAL, BaseColor.GRAY);
                
                // Footer izquierdo
                ColumnText.showTextAligned(cb, Element.ALIGN_LEFT,
                    new Phrase("Reporte generado por SLYCIPHER - Sistema de Gestión Educativa", footerFont),
                    document.left(), document.bottom() - 10, 0);
                
                // Footer derecho - número de página
                ColumnText.showTextAligned(cb, Element.ALIGN_RIGHT,
                    new Phrase(fechaGeneracion + " | Página " + writer.getPageNumber(), footerFont),
                    document.right(), document.bottom() - 10, 0);
                    
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public byte[] generarReporteUsuariosPDF(List<Usuario> usuarios, String fechaDesde, String fechaHasta) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4, 36, 36, 80, 50);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        // Obtener usuario actual
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        HeaderFooter event = new HeaderFooter(usuarioGenerador, fechaGeneracion, "Usuarios", "PDF");
        writer.setPageEvent(event);
        
        document.open();
        
        // ==================== ENCABEZADO CON LOGO ====================
        PdfPTable headerTable = new PdfPTable(2);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{1, 4});
        
        // Logo
        try {
            ClassPathResource imgFile = new ClassPathResource("static/images/logo.png");
            if (imgFile.exists()) {
                Image logo = Image.getInstance(imgFile.getURL());
                logo.scaleToFit(60, 60);
                PdfPCell logoCell = new PdfPCell(logo);
                logoCell.setBorder(Rectangle.NO_BORDER);
                logoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                logoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                headerTable.addCell(logoCell);
            } else {
                PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                emptyCell.setBorder(Rectangle.NO_BORDER);
                headerTable.addCell(emptyCell);
            }
        } catch (Exception e) {
            PdfPCell emptyCell = new PdfPCell(new Phrase(""));
            emptyCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(emptyCell);
        }
        
        // Título
        com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 20, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        Paragraph title = new Paragraph("SLYCIPHER - Reporte de Usuarios", titleFont);
        title.setAlignment(Element.ALIGN_LEFT);
        PdfPCell titleCell = new PdfPCell(title);
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        headerTable.addCell(titleCell);
        
        document.add(headerTable);
        document.add(new Paragraph(" "));
        
        // ==================== INFORMACIÓN DE GENERACIÓN ====================
        PdfPTable infoTable = new PdfPTable(4);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10);
        infoTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font infoLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD);
        com.itextpdf.text.Font infoValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        
        infoTable.addCell(createInfoCell("Generado por:", infoLabelFont));
        infoTable.addCell(createInfoCell(usuarioGenerador, infoValueFont));
        infoTable.addCell(createInfoCell("Fecha de generación:", infoLabelFont));
        infoTable.addCell(createInfoCell(fechaGeneracion, infoValueFont));
        
        infoTable.addCell(createInfoCell("Tipo de reporte:", infoLabelFont));
        infoTable.addCell(createInfoCell("Usuarios", infoValueFont));
        infoTable.addCell(createInfoCell("Formato:", infoLabelFont));
        infoTable.addCell(createInfoCell("PDF", infoValueFont));
        
        document.add(infoTable);
        
        // Filtros si existen
        if (fechaDesde != null || fechaHasta != null) {
            com.itextpdf.text.Font filterFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.ITALIC, BaseColor.DARK_GRAY);
            Paragraph filters = new Paragraph("Filtros: ", filterFont);
            if (fechaDesde != null) filters.add("Desde " + fechaDesde + " ");
            if (fechaHasta != null) filters.add("Hasta " + fechaHasta);
            filters.setSpacingAfter(10);
            document.add(filters);
        }
        
        // ==================== RESUMEN ESTADÍSTICO ====================
        document.add(new Paragraph(" "));
        com.itextpdf.text.Font sectionFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 14, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        Paragraph resumenTitle = new Paragraph("Resumen Estadístico", sectionFont);
        resumenTitle.setSpacingAfter(10);
        document.add(resumenTitle);
        
        // Línea separadora
        com.itextpdf.text.Font lineFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(37, 99, 235));
        Paragraph line = new Paragraph("_____________________________________________________________________________________", lineFont);
        line.setAlignment(Element.ALIGN_CENTER);
        document.add(line);
        document.add(new Paragraph(" "));
        
        // Calcular estadísticas
        long usuariosActivos = usuarios.stream().filter(Usuario::getActivo).count();
        long usuariosInactivos = usuarios.size() - usuariosActivos;
        double tasaActividad = usuarios.size() > 0 ? (usuariosActivos * 100.0 / usuarios.size()) : 0;
        
        PdfPTable statsTable = new PdfPTable(4);
        statsTable.setWidthPercentage(100);
        statsTable.setSpacingBefore(10);
        statsTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font statValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 24, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        com.itextpdf.text.Font statLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);
        
        statsTable.addCell(createStatCell(String.valueOf(usuarios.size()), "Total Usuarios", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(usuariosActivos), "Usuarios Activos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(usuariosInactivos), "Usuarios Inactivos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.format("%.1f%%", tasaActividad), "Tasa de Actividad", statValueFont, statLabelFont));
        
        document.add(statsTable);
        
        // ==================== DISTRIBUCIÓN POR ROLES ====================
        document.add(new Paragraph(" "));
        Paragraph rolesTitle = new Paragraph("Distribución por Roles", sectionFont);
        rolesTitle.setSpacingAfter(10);
        document.add(rolesTitle);
        
        com.itextpdf.text.Font lineFont2 = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(37, 99, 235));
        Paragraph line2 = new Paragraph("_____________________________________________________________________________________", lineFont2);
        line2.setAlignment(Element.ALIGN_CENTER);
        document.add(line2);
        document.add(new Paragraph(" "));
        
        // Agrupar por roles
        Map<String, Long> usuariosPorRol = usuarios.stream()
            .collect(Collectors.groupingBy(Usuario::getRol, Collectors.counting()));
        
        PdfPTable rolesTable = new PdfPTable(3);
        rolesTable.setWidthPercentage(80);
        rolesTable.setWidths(new float[]{3, 2, 2});
        rolesTable.setSpacingBefore(10);
        rolesTable.setSpacingAfter(15);
        rolesTable.setHorizontalAlignment(Element.ALIGN_CENTER);
        
        // Headers
        com.itextpdf.text.Font rolesHeaderFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        PdfPCell rolHeader = new PdfPCell(new Phrase("ROL", rolesHeaderFont));
        rolHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        rolHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        rolHeader.setPadding(8);
        rolesTable.addCell(rolHeader);
        
        PdfPCell cantidadHeader = new PdfPCell(new Phrase("CANTIDAD", rolesHeaderFont));
        cantidadHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        cantidadHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        cantidadHeader.setPadding(8);
        rolesTable.addCell(cantidadHeader);
        
        PdfPCell porcentajeHeader = new PdfPCell(new Phrase("PORCENTAJE", rolesHeaderFont));
        porcentajeHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        porcentajeHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        porcentajeHeader.setPadding(8);
        rolesTable.addCell(porcentajeHeader);
        
        // Datos de roles
        com.itextpdf.text.Font rolesDataFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        for (Map.Entry<String, Long> entry : usuariosPorRol.entrySet()) {
            double porcentaje = (entry.getValue() * 100.0 / usuarios.size());
            
            // Celda de rol con color según tipo
            BaseColor rolColor;
            if (entry.getKey().contains("ADMIN")) {
                rolColor = new BaseColor(147, 51, 234); // Purple
            } else if (entry.getKey().contains("DEVELOPER")) {
                rolColor = new BaseColor(251, 191, 36); // Yellow
            } else {
                rolColor = new BaseColor(59, 130, 246); // Blue
            }
            
            PdfPCell rolCell = new PdfPCell(new Phrase(entry.getKey(), rolesDataFont));
            rolCell.setBackgroundColor(new BaseColor(rolColor.getRed(), rolColor.getGreen(), rolColor.getBlue(), 50));
            rolCell.setPadding(6);
            rolesTable.addCell(rolCell);
            
            PdfPCell cantCell = new PdfPCell(new Phrase(String.valueOf(entry.getValue()), rolesDataFont));
            cantCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cantCell.setPadding(6);
            rolesTable.addCell(cantCell);
            
            PdfPCell porcCell = new PdfPCell(new Phrase(String.format("%.1f%%", porcentaje), rolesDataFont));
            porcCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            porcCell.setPadding(6);
            rolesTable.addCell(porcCell);
        }
        
        document.add(rolesTable);
        
        // ==================== DATOS DETALLADOS ====================
        if (document.getPageNumber() > 0) {
            document.newPage();
        }
        
        Paragraph datosTitle = new Paragraph("Datos Detallados", sectionFont);
        datosTitle.setSpacingAfter(10);
        document.add(datosTitle);
        
        com.itextpdf.text.Font lineFont3 = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(37, 99, 235));
        Paragraph line3 = new Paragraph("_____________________________________________________________________________________", lineFont3);
        line3.setAlignment(Element.ALIGN_CENTER);
        document.add(line3);
        document.add(new Paragraph(" "));
        
        // Tabla de datos
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{2, 2.5f, 1.5f, 1.2f, 1f, 1.8f, 1.8f});
        table.setSpacingBefore(10);
        
        // Headers
        com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 8, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        String[] headers = {"USUARIO", "EMAIL", "ROL", "ESTADO", "RACHA", "FECHA REGISTRO", "ÚLTIMO LOGIN"};
        
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
            cell.setBackgroundColor(new BaseColor(37, 99, 235));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(6);
            table.addCell(cell);
        }
        
        // Datos
        com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 7);
        for (Usuario usuario : usuarios) {
            // Usuario
            table.addCell(createDataCell(usuario.getUsername(), cellFont));
            
            // Email
            table.addCell(createDataCell(usuario.getEmail(), cellFont));
            
            // Rol con color
            BaseColor rolColor;
            if (usuario.getRol().contains("ADMIN")) {
                rolColor = new BaseColor(147, 51, 234);
            } else if (usuario.getRol().contains("DEVELOPER")) {
                rolColor = new BaseColor(251, 191, 36);
            } else {
                rolColor = new BaseColor(59, 130, 246);
            }
            
            PdfPCell rolCell = new PdfPCell(new Phrase(usuario.getRol(), cellFont));
            rolCell.setBackgroundColor(new BaseColor(rolColor.getRed(), rolColor.getGreen(), rolColor.getBlue(), 50));
            rolCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            rolCell.setPadding(4);
            table.addCell(rolCell);
            
            // Estado
            PdfPCell estadoCell = new PdfPCell(new Phrase(usuario.getActivo() ? "ACTIVO" : "INACTIVO", cellFont));
            estadoCell.setBackgroundColor(usuario.getActivo() ? new BaseColor(34, 197, 94, 50) : new BaseColor(239, 68, 68, 50));
            estadoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            estadoCell.setPadding(4);
            table.addCell(estadoCell);
            
            // Racha
            table.addCell(createDataCell(usuario.getRacha() != null ? String.valueOf(usuario.getRacha()) : "0", cellFont));
            
            // Fecha Registro
            table.addCell(createDataCell(usuario.getCreadoEn() != null ? 
                usuario.getCreadoEn().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "N/A", cellFont));
            
            // Último Login (no está en el modelo, mostrar "Nunca" por defecto)
            table.addCell(createDataCell("Nunca", cellFont));
        }
        
        document.add(table);
        
        document.close();
        return baos.toByteArray();
    }

    // Métodos auxiliares para crear celdas
    private PdfPCell createInfoCell(String text, com.itextpdf.text.Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPadding(3);
        return cell;
    }
    
    private PdfPCell createStatCell(String value, String label, com.itextpdf.text.Font valueFont, com.itextpdf.text.Font labelFont) {
        PdfPTable innerTable = new PdfPTable(1);
        innerTable.setWidthPercentage(100);
        
        PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);
        valueCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        valueCell.setPaddingBottom(5);
        innerTable.addCell(valueCell);
        
        PdfPCell labelCell = new PdfPCell(new Phrase(label, labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);
        labelCell.setHorizontalAlignment(Element.ALIGN_CENTER);
        innerTable.addCell(labelCell);
        
        PdfPCell outerCell = new PdfPCell(innerTable);
        outerCell.setBorder(Rectangle.BOX);
        outerCell.setBorderColor(BaseColor.LIGHT_GRAY);
        outerCell.setPadding(10);
        return outerCell;
    }
    
    private PdfPCell createDataCell(String text, com.itextpdf.text.Font font) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setPadding(4);
        return cell;
    }

    public byte[] generarReporteUsuariosExcel(List<Usuario> usuarios) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Reporte Usuarios");
        
        // Obtener usuario actual
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        int rowNum = 0;
        
        // ==================== TÍTULO ====================
        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("SLYCIPHER - Reporte de Usuarios");
        CellStyle titleStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font titleFont = workbook.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 16);
        titleFont.setColor(IndexedColors.BLUE.getIndex());
        titleStyle.setFont(titleFont);
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 6));
        
        rowNum++; // Línea vacía
        
        // ==================== INFORMACIÓN DE GENERACIÓN ====================
        CellStyle labelStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font labelFont = workbook.createFont();
        labelFont.setBold(true);
        labelStyle.setFont(labelFont);
        
        Row infoRow1 = sheet.createRow(rowNum++);
        Cell labelCell1 = infoRow1.createCell(0);
        labelCell1.setCellValue("Generado por:");
        labelCell1.setCellStyle(labelStyle);
        infoRow1.createCell(1).setCellValue(usuarioGenerador);
        
        Cell labelCell2 = infoRow1.createCell(3);
        labelCell2.setCellValue("Fecha de generación:");
        labelCell2.setCellStyle(labelStyle);
        infoRow1.createCell(4).setCellValue(fechaGeneracion);
        
        Row infoRow2 = sheet.createRow(rowNum++);
        Cell labelCell3 = infoRow2.createCell(0);
        labelCell3.setCellValue("Tipo de reporte:");
        labelCell3.setCellStyle(labelStyle);
        infoRow2.createCell(1).setCellValue("Usuarios");
        
        Cell labelCell4 = infoRow2.createCell(3);
        labelCell4.setCellValue("Formato:");
        labelCell4.setCellStyle(labelStyle);
        infoRow2.createCell(4).setCellValue("Excel");
        
        rowNum++; // Línea vacía
        
        // ==================== RESUMEN ESTADÍSTICO ====================
        Row seccionRow1 = sheet.createRow(rowNum++);
        Cell seccionCell1 = seccionRow1.createCell(0);
        seccionCell1.setCellValue("RESUMEN ESTADÍSTICO");
        CellStyle seccionStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font seccionFont = workbook.createFont();
        seccionFont.setBold(true);
        seccionFont.setFontHeightInPoints((short) 12);
        seccionFont.setColor(IndexedColors.BLUE.getIndex());
        seccionStyle.setFont(seccionFont);
        seccionCell1.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 6));
        
        // Calcular estadísticas
        long usuariosActivos = usuarios.stream().filter(Usuario::getActivo).count();
        long usuariosInactivos = usuarios.size() - usuariosActivos;
        double tasaActividad = usuarios.size() > 0 ? (usuariosActivos * 100.0 / usuarios.size()) : 0;
        
        Row statsRow = sheet.createRow(rowNum++);
        statsRow.createCell(0).setCellValue("Total Usuarios");
        statsRow.createCell(1).setCellValue(usuarios.size());
        statsRow.createCell(2).setCellValue("Usuarios Activos");
        statsRow.createCell(3).setCellValue(usuariosActivos);
        statsRow.createCell(4).setCellValue("Usuarios Inactivos");
        statsRow.createCell(5).setCellValue(usuariosInactivos);
        statsRow.createCell(6).setCellValue(String.format("Tasa: %.1f%%", tasaActividad));
        
        rowNum++; // Línea vacía
        
        // ==================== DISTRIBUCIÓN POR ROLES ====================
        Row seccionRow2 = sheet.createRow(rowNum++);
        Cell seccionCell2 = seccionRow2.createCell(0);
        seccionCell2.setCellValue("DISTRIBUCIÓN POR ROLES");
        seccionCell2.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 6));
        
        // Agrupar por roles
        Map<String, Long> usuariosPorRol = usuarios.stream()
            .collect(Collectors.groupingBy(Usuario::getRol, Collectors.counting()));
        
        // Headers de distribución
        Row rolesHeaderRow = sheet.createRow(rowNum++);
        CellStyle headerStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.BLUE.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        Cell rolHeaderCell = rolesHeaderRow.createCell(0);
        rolHeaderCell.setCellValue("ROL");
        rolHeaderCell.setCellStyle(headerStyle);
        
        Cell cantHeaderCell = rolesHeaderRow.createCell(1);
        cantHeaderCell.setCellValue("CANTIDAD");
        cantHeaderCell.setCellStyle(headerStyle);
        
        Cell porcHeaderCell = rolesHeaderRow.createCell(2);
        porcHeaderCell.setCellValue("PORCENTAJE");
        porcHeaderCell.setCellStyle(headerStyle);
        
        // Datos de roles
        for (Map.Entry<String, Long> entry : usuariosPorRol.entrySet()) {
            Row rolRow = sheet.createRow(rowNum++);
            rolRow.createCell(0).setCellValue(entry.getKey());
            rolRow.createCell(1).setCellValue(entry.getValue());
            rolRow.createCell(2).setCellValue(String.format("%.1f%%", entry.getValue() * 100.0 / usuarios.size()));
        }
        
        rowNum++; // Línea vacía
        
        // ==================== DATOS DETALLADOS ====================
        Row seccionRow3 = sheet.createRow(rowNum++);
        Cell seccionCell3 = seccionRow3.createCell(0);
        seccionCell3.setCellValue("DATOS DETALLADOS");
        seccionCell3.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 6));
        
        // Headers de datos
        Row dataHeaderRow = sheet.createRow(rowNum++);
        String[] columns = {"USUARIO", "EMAIL", "ROL", "ESTADO", "RACHA", "FECHA REGISTRO", "ÚLTIMO LOGIN"};
        for (int i = 0; i < columns.length; i++) {
            Cell cell = dataHeaderRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerStyle);
        }
        
        // Datos
        for (Usuario usuario : usuarios) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(usuario.getUsername());
            row.createCell(1).setCellValue(usuario.getEmail());
            row.createCell(2).setCellValue(usuario.getRol());
            row.createCell(3).setCellValue(usuario.getActivo() ? "ACTIVO" : "INACTIVO");
            row.createCell(4).setCellValue(usuario.getRacha() != null ? usuario.getRacha() : 0);
            row.createCell(5).setCellValue(usuario.getCreadoEn() != null ? 
                usuario.getCreadoEn().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "N/A");
            row.createCell(6).setCellValue("Nunca");
        }
        
        // Auto-size columns
        for (int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        // Footer
        rowNum++;
        Row footerRow = sheet.createRow(rowNum);
        Cell footerCell = footerRow.createCell(0);
        footerCell.setCellValue("Reporte generado por SLYCIPHER - Sistema de Gestión Educativa | " + fechaGeneracion);
        CellStyle footerStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font footerFont = workbook.createFont();
        footerFont.setItalic(true);
        footerFont.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        footerStyle.setFont(footerFont);
        footerCell.setCellStyle(footerStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum, rowNum, 0, 6));
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();
        return baos.toByteArray();
    }

    public byte[] generarReporteCursosPDF(List<Curso> cursos) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4.rotate(), 36, 36, 80, 50);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        // Obtener usuario actual
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        HeaderFooter event = new HeaderFooter(usuarioGenerador, fechaGeneracion, "Cursos", "PDF");
        writer.setPageEvent(event);
        
        document.open();
        
        // ==================== ENCABEZADO CON LOGO ====================
        PdfPTable headerTable = new PdfPTable(2);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{1, 4});
        
        // Logo
        try {
            ClassPathResource imgFile = new ClassPathResource("static/images/logo.png");
            if (imgFile.exists()) {
                Image logo = Image.getInstance(imgFile.getURL());
                logo.scaleToFit(60, 60);
                PdfPCell logoCell = new PdfPCell(logo);
                logoCell.setBorder(Rectangle.NO_BORDER);
                logoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                logoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                headerTable.addCell(logoCell);
            } else {
                PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                emptyCell.setBorder(Rectangle.NO_BORDER);
                headerTable.addCell(emptyCell);
            }
        } catch (Exception e) {
            PdfPCell emptyCell = new PdfPCell(new Phrase(""));
            emptyCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(emptyCell);
        }
        
        // Título
        com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 20, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        Paragraph title = new Paragraph("SLYCIPHER - Reporte de Cursos", titleFont);
        title.setAlignment(Element.ALIGN_LEFT);
        PdfPCell titleCell = new PdfPCell(title);
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        headerTable.addCell(titleCell);
        
        document.add(headerTable);
        document.add(new Paragraph(" "));
        
        // ==================== INFORMACIÓN DE GENERACIÓN ====================
        PdfPTable infoTable = new PdfPTable(4);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10);
        infoTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font infoLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD);
        com.itextpdf.text.Font infoValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        
        infoTable.addCell(createInfoCell("Generado por:", infoLabelFont));
        infoTable.addCell(createInfoCell(usuarioGenerador, infoValueFont));
        infoTable.addCell(createInfoCell("Fecha de generación:", infoLabelFont));
        infoTable.addCell(createInfoCell(fechaGeneracion, infoValueFont));
        
        infoTable.addCell(createInfoCell("Tipo de reporte:", infoLabelFont));
        infoTable.addCell(createInfoCell("Cursos", infoValueFont));
        infoTable.addCell(createInfoCell("Formato:", infoLabelFont));
        infoTable.addCell(createInfoCell("PDF", infoValueFont));
        
        document.add(infoTable);
        
        // ==================== RESUMEN ESTADÍSTICO ====================
        document.add(new Paragraph(" "));
        com.itextpdf.text.Font sectionFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 14, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        Paragraph resumenTitle = new Paragraph("Resumen Estadístico", sectionFont);
        resumenTitle.setSpacingAfter(10);
        document.add(resumenTitle);
        
        // Línea separadora
        com.itextpdf.text.Font lineFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(37, 99, 235));
        Paragraph line = new Paragraph("___________________________________________________________________________________________________________________________________________", lineFont);
        line.setAlignment(Element.ALIGN_CENTER);
        document.add(line);
        document.add(new Paragraph(" "));
        
        // Calcular estadísticas
        long cursosAprobados = cursos.stream().filter(c -> "aprobada".equals(c.getEstado())).count();
        long cursosPendientes = cursos.stream().filter(c -> "pendiente".equals(c.getEstado())).count();
        long cursosRechazados = cursos.stream().filter(c -> "rechazada".equals(c.getEstado())).count();
        long cursosVisibles = cursos.stream().filter(c -> c.getVisible() != null && c.getVisible()).count();
        
        PdfPTable statsTable = new PdfPTable(5);
        statsTable.setWidthPercentage(100);
        statsTable.setSpacingBefore(10);
        statsTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font statValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 24, com.itextpdf.text.Font.BOLD, new BaseColor(37, 99, 235));
        com.itextpdf.text.Font statLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);
        
        statsTable.addCell(createStatCell(String.valueOf(cursos.size()), "Total Cursos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(cursosAprobados), "Cursos Aprobados", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(cursosPendientes), "Cursos Pendientes", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(cursosRechazados), "Cursos Rechazados", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(cursosVisibles), "Cursos Visibles", statValueFont, statLabelFont));
        
        document.add(statsTable);
        
        // ==================== DISTRIBUCIÓN POR NIVEL ====================
        document.add(new Paragraph(" "));
        Paragraph nivelesTitle = new Paragraph("Distribución por Nivel", sectionFont);
        nivelesTitle.setSpacingAfter(10);
        document.add(nivelesTitle);
        
        com.itextpdf.text.Font lineFont2 = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(37, 99, 235));
        Paragraph line2 = new Paragraph("___________________________________________________________________________________________________________________________________________", lineFont2);
        line2.setAlignment(Element.ALIGN_CENTER);
        document.add(line2);
        document.add(new Paragraph(" "));
        
        // Agrupar por niveles
        Map<String, Long> cursosPorNivel = cursos.stream()
            .collect(Collectors.groupingBy(Curso::getNivel, Collectors.counting()));
        
        PdfPTable nivelesTable = new PdfPTable(3);
        nivelesTable.setWidthPercentage(80);
        nivelesTable.setWidths(new float[]{3, 2, 2});
        nivelesTable.setSpacingBefore(10);
        nivelesTable.setSpacingAfter(15);
        nivelesTable.setHorizontalAlignment(Element.ALIGN_CENTER);
        
        // Headers
        com.itextpdf.text.Font nivelesHeaderFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        PdfPCell nivelHeader = new PdfPCell(new Phrase("NIVEL", nivelesHeaderFont));
        nivelHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        nivelHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        nivelHeader.setPadding(8);
        nivelesTable.addCell(nivelHeader);
        
        PdfPCell cantidadHeader = new PdfPCell(new Phrase("CANTIDAD", nivelesHeaderFont));
        cantidadHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        cantidadHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        cantidadHeader.setPadding(8);
        nivelesTable.addCell(cantidadHeader);
        
        PdfPCell porcentajeHeader = new PdfPCell(new Phrase("PORCENTAJE", nivelesHeaderFont));
        porcentajeHeader.setBackgroundColor(new BaseColor(37, 99, 235));
        porcentajeHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        porcentajeHeader.setPadding(8);
        nivelesTable.addCell(porcentajeHeader);
        
        // Datos de niveles
        com.itextpdf.text.Font nivelesDataFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        for (Map.Entry<String, Long> entry : cursosPorNivel.entrySet()) {
            double porcentaje = (entry.getValue() * 100.0 / cursos.size());
            
            // Celda de nivel con color según tipo
            BaseColor nivelColor;
            if ("BEGINNER".equalsIgnoreCase(entry.getKey())) {
                nivelColor = new BaseColor(34, 197, 94); // Green
            } else if ("INTERMEDIATE".equalsIgnoreCase(entry.getKey())) {
                nivelColor = new BaseColor(251, 191, 36); // Yellow
            } else {
                nivelColor = new BaseColor(239, 68, 68); // Red
            }
            
            PdfPCell nivelCell = new PdfPCell(new Phrase(entry.getKey(), nivelesDataFont));
            nivelCell.setBackgroundColor(new BaseColor(nivelColor.getRed(), nivelColor.getGreen(), nivelColor.getBlue(), 50));
            nivelCell.setPadding(6);
            nivelesTable.addCell(nivelCell);
            
            PdfPCell cantCell = new PdfPCell(new Phrase(String.valueOf(entry.getValue()), nivelesDataFont));
            cantCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cantCell.setPadding(6);
            nivelesTable.addCell(cantCell);
            
            PdfPCell porcCell = new PdfPCell(new Phrase(String.format("%.1f%%", porcentaje), nivelesDataFont));
            porcCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            porcCell.setPadding(6);
            nivelesTable.addCell(porcCell);
        }
        
        document.add(nivelesTable);
        
        // ==================== DATOS DETALLADOS ====================
        if (document.getPageNumber() > 0) {
            document.newPage();
        }
        
        Paragraph datosTitle = new Paragraph("Datos Detallados", sectionFont);
        datosTitle.setSpacingAfter(10);
        document.add(datosTitle);
        
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100);
        table.setSpacingBefore(10f);
        
        com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        String[] headers = {"Título", "Descripción", "Nivel", "Precio", "Estado", "Visibilidad"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
            cell.setBackgroundColor(new BaseColor(37, 99, 235));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(8);
            table.addCell(cell);
        }
        
        com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        for (Curso curso : cursos) {
            table.addCell(new Phrase(curso.getTitulo(), cellFont));
            table.addCell(new Phrase(curso.getDescripcion(), cellFont));
            table.addCell(new Phrase(curso.getNivel(), cellFont));
            table.addCell(new Phrase("$" + curso.getPrecio(), cellFont));
            
            // Columna Estado de Aprobación
            String estadoTexto = "";
            BaseColor estadoColor = BaseColor.BLACK;
            if ("aprobada".equals(curso.getEstado())) {
                estadoTexto = "✓ Aprobado";
                estadoColor = new BaseColor(34, 197, 94); // Verde
            } else if ("pendiente".equals(curso.getEstado())) {
                estadoTexto = "⏳ Pendiente";
                estadoColor = new BaseColor(234, 179, 8); // Amarillo
            } else {
                estadoTexto = "✗ Rechazado";
                estadoColor = new BaseColor(239, 68, 68); // Rojo
            }
            com.itextpdf.text.Font estadoCursoFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD, estadoColor);
            table.addCell(new Phrase(estadoTexto, estadoCursoFont));
            
            // Columna Visibilidad
            String visibleTexto = "";
            BaseColor visibleColor = BaseColor.BLACK;
            if (curso.getVisible() != null && curso.getVisible()) {
                visibleTexto = "👁 Visible";
                visibleColor = new BaseColor(59, 130, 246); // Azul
            } else {
                visibleTexto = "🚫 Oculto";
                visibleColor = new BaseColor(107, 114, 128); // Gris
            }
            com.itextpdf.text.Font visibleCursoFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD, visibleColor);
            table.addCell(new Phrase(visibleTexto, visibleCursoFont));
        }
        
        document.add(table);
        
        com.itextpdf.text.Font totalFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 12, com.itextpdf.text.Font.BOLD);
        Paragraph total = new Paragraph("Total de cursos: " + cursos.size(), totalFont);
        total.setSpacingBefore(10);
        document.add(total);
        
        document.close();
        return baos.toByteArray();
    }

    public byte[] generarReporteCursosExcel(List<Curso> cursos) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Cursos");
        
        CellStyle headerStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.GREEN.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        // Estilos para estados
        CellStyle aprobadoStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font aprobadoFont = workbook.createFont();
        aprobadoFont.setBold(true);
        aprobadoFont.setColor(IndexedColors.GREEN.getIndex());
        aprobadoStyle.setFont(aprobadoFont);
        
        CellStyle pendienteStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font pendienteFont = workbook.createFont();
        pendienteFont.setBold(true);
        pendienteFont.setColor(IndexedColors.ORANGE.getIndex());
        pendienteStyle.setFont(pendienteFont);
        
        CellStyle rechazadoStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font rechazadoFont = workbook.createFont();
        rechazadoFont.setBold(true);
        rechazadoFont.setColor(IndexedColors.RED.getIndex());
        rechazadoStyle.setFont(rechazadoFont);
        
        CellStyle visibleStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font visibleFont = workbook.createFont();
        visibleFont.setBold(true);
        visibleFont.setColor(IndexedColors.BLUE.getIndex());
        visibleStyle.setFont(visibleFont);
        
        CellStyle ocultoStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font ocultoFont = workbook.createFont();
        ocultoFont.setBold(true);
        ocultoFont.setColor(IndexedColors.GREY_50_PERCENT.getIndex());
        ocultoStyle.setFont(ocultoFont);
        
        Row headerRow = sheet.createRow(0);
        String[] columns = {"Título", "Descripción", "Nivel", "Lenguaje ID", "Precio", "Estado", "Visibilidad", "Fecha Creación"};
        for (int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerStyle);
        }
        
        int rowNum = 1;
        for (Curso curso : cursos) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(curso.getTitulo());
            row.createCell(1).setCellValue(curso.getDescripcion());
            row.createCell(2).setCellValue(curso.getNivel());
            row.createCell(3).setCellValue(curso.getLanguageId() != null ? curso.getLanguageId().toString() : "N/A");
            row.createCell(4).setCellValue(curso.getPrecio() != null ? curso.getPrecio().doubleValue() : 0.0);
            
            // Estado de aprobación
            Cell estadoCell = row.createCell(5);
            if ("aprobada".equals(curso.getEstado())) {
                estadoCell.setCellValue("✓ Aprobado");
                estadoCell.setCellStyle(aprobadoStyle);
            } else if ("pendiente".equals(curso.getEstado())) {
                estadoCell.setCellValue("⏳ Pendiente");
                estadoCell.setCellStyle(pendienteStyle);
            } else {
                estadoCell.setCellValue("✗ Rechazado");
                estadoCell.setCellStyle(rechazadoStyle);
            }
            
            // Visibilidad
            Cell visibleCell = row.createCell(6);
            if (curso.getVisible() != null && curso.getVisible()) {
                visibleCell.setCellValue("👁 Visible");
                visibleCell.setCellStyle(visibleStyle);
            } else {
                visibleCell.setCellValue("🚫 Oculto");
                visibleCell.setCellStyle(ocultoStyle);
            }
            
            row.createCell(7).setCellValue(curso.getFechaCreacion() != null ? 
                curso.getFechaCreacion().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) : "N/A");
        }
        
        for (int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();
        return baos.toByteArray();
    }

    // ==================== REPORTES DE PROGRESO ====================
    
    public byte[] generarReporteProgresoPDF(List<Usuario> usuarios, List<Curso> cursos, String fechaDesde, String fechaHasta) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4, 36, 36, 80, 50);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        HeaderFooter event = new HeaderFooter(usuarioGenerador, fechaGeneracion, "Progreso", "PDF");
        writer.setPageEvent(event);
        
        document.open();
        
        // Encabezado con logo
        PdfPTable headerTable = new PdfPTable(2);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{1, 4});
        
        try {
            ClassPathResource imgFile = new ClassPathResource("static/images/logo.png");
            if (imgFile.exists()) {
                Image logo = Image.getInstance(imgFile.getURL());
                logo.scaleToFit(60, 60);
                PdfPCell logoCell = new PdfPCell(logo);
                logoCell.setBorder(Rectangle.NO_BORDER);
                logoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                logoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                headerTable.addCell(logoCell);
            } else {
                PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                emptyCell.setBorder(Rectangle.NO_BORDER);
                headerTable.addCell(emptyCell);
            }
        } catch (Exception e) {
            PdfPCell emptyCell = new PdfPCell(new Phrase(""));
            emptyCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(emptyCell);
        }
        
        com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 20, com.itextpdf.text.Font.BOLD, new BaseColor(139, 92, 246));
        Paragraph title = new Paragraph("SLYCIPHER - Reporte de Progreso", titleFont);
        title.setAlignment(Element.ALIGN_LEFT);
        PdfPCell titleCell = new PdfPCell(title);
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        headerTable.addCell(titleCell);
        
        document.add(headerTable);
        document.add(new Paragraph(" "));
        
        // Información de generación
        PdfPTable infoTable = new PdfPTable(4);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10);
        infoTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font infoLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD);
        com.itextpdf.text.Font infoValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        
        infoTable.addCell(createInfoCell("Generado por:", infoLabelFont));
        infoTable.addCell(createInfoCell(usuarioGenerador, infoValueFont));
        infoTable.addCell(createInfoCell("Fecha de generación:", infoLabelFont));
        infoTable.addCell(createInfoCell(fechaGeneracion, infoValueFont));
        
        infoTable.addCell(createInfoCell("Tipo de reporte:", infoLabelFont));
        infoTable.addCell(createInfoCell("Progreso", infoValueFont));
        infoTable.addCell(createInfoCell("Formato:", infoLabelFont));
        infoTable.addCell(createInfoCell("PDF", infoValueFont));
        
        document.add(infoTable);
        
        // Resumen de progreso
        com.itextpdf.text.Font sectionFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 14, com.itextpdf.text.Font.BOLD, new BaseColor(139, 92, 246));
        Paragraph resumenTitle = new Paragraph("Resumen de Progreso", sectionFont);
        resumenTitle.setSpacingAfter(10);
        document.add(resumenTitle);
        
        com.itextpdf.text.Font lineFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(139, 92, 246));
        Paragraph line = new Paragraph("_____________________________________________________________________________________", lineFont);
        line.setAlignment(Element.ALIGN_CENTER);
        document.add(line);
        document.add(new Paragraph(" "));
        
        // Estadísticas clave
        long totalUsuarios = usuarios.size();
        long totalCursos = cursos.size();
        long totalActivos = usuarios.stream().filter(Usuario::getActivo).count();
        double promedioRacha = usuarios.stream()
            .filter(u -> u.getRacha() != null)
            .mapToInt(Usuario::getRacha)
            .average()
            .orElse(0.0);
        
        PdfPTable statsTable = new PdfPTable(4);
        statsTable.setWidthPercentage(100);
        statsTable.setSpacingBefore(10);
        statsTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font statValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 24, com.itextpdf.text.Font.BOLD, new BaseColor(139, 92, 246));
        com.itextpdf.text.Font statLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);
        
        statsTable.addCell(createStatCell(String.valueOf(totalUsuarios), "Total Usuarios", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(totalCursos), "Total Cursos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(totalActivos), "Usuarios Activos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.format("%.1f", promedioRacha), "Racha Promedio", statValueFont, statLabelFont));
        
        document.add(statsTable);
        
        // Top usuarios por racha
        document.add(new Paragraph(" "));
        Paragraph topTitle = new Paragraph("Top 10 Usuarios por Racha", sectionFont);
        topTitle.setSpacingAfter(10);
        document.add(topTitle);
        
        List<Usuario> topUsuarios = usuarios.stream()
            .filter(u -> u.getRacha() != null && u.getRacha() > 0)
            .sorted((u1, u2) -> Integer.compare(u2.getRacha(), u1.getRacha()))
            .limit(10)
            .collect(Collectors.toList());
        
        PdfPTable topTable = new PdfPTable(4);
        topTable.setWidthPercentage(80);
        topTable.setHorizontalAlignment(Element.ALIGN_CENTER);
        topTable.setSpacingBefore(10);
        
        com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        String[] headers = {"Posición", "Usuario", "Email", "Racha"};
        for (String header : headers) {
            PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
            cell.setBackgroundColor(new BaseColor(139, 92, 246));
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(6);
            topTable.addCell(cell);
        }
        
        com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        int posicion = 1;
        for (Usuario usuario : topUsuarios) {
            topTable.addCell(createDataCell(String.valueOf(posicion++), cellFont));
            topTable.addCell(createDataCell(usuario.getUsername(), cellFont));
            topTable.addCell(createDataCell(usuario.getEmail(), cellFont));
            
            PdfPCell rachaCell = new PdfPCell(new Phrase("🔥 " + usuario.getRacha() + " días", cellFont));
            rachaCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            rachaCell.setPadding(4);
            topTable.addCell(rachaCell);
        }
        
        document.add(topTable);
        
        document.close();
        return baos.toByteArray();
    }
    
    public byte[] generarReporteProgresoExcel(List<Usuario> usuarios, List<Curso> cursos) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Reporte Progreso");
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        int rowNum = 0;
        
        // Título
        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("SLYCIPHER - Reporte de Progreso");
        CellStyle titleStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font titleFont = workbook.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 16);
        titleFont.setColor(IndexedColors.VIOLET.getIndex());
        titleStyle.setFont(titleFont);
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 3));
        
        rowNum++;
        
        // Info generación
        CellStyle labelStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font labelFont = workbook.createFont();
        labelFont.setBold(true);
        labelStyle.setFont(labelFont);
        
        Row infoRow1 = sheet.createRow(rowNum++);
        Cell labelCell1 = infoRow1.createCell(0);
        labelCell1.setCellValue("Generado por:");
        labelCell1.setCellStyle(labelStyle);
        infoRow1.createCell(1).setCellValue(usuarioGenerador);
        
        Row infoRow2 = sheet.createRow(rowNum++);
        Cell labelCell2 = infoRow2.createCell(0);
        labelCell2.setCellValue("Fecha:");
        labelCell2.setCellStyle(labelStyle);
        infoRow2.createCell(1).setCellValue(fechaGeneracion);
        
        rowNum++;
        
        // Estadísticas
        Row statsHeaderRow = sheet.createRow(rowNum++);
        Cell statsCell = statsHeaderRow.createCell(0);
        statsCell.setCellValue("ESTADÍSTICAS DE PROGRESO");
        CellStyle seccionStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font seccionFont = workbook.createFont();
        seccionFont.setBold(true);
        seccionFont.setFontHeightInPoints((short) 12);
        seccionFont.setColor(IndexedColors.VIOLET.getIndex());
        seccionStyle.setFont(seccionFont);
        statsCell.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        Row statsRow = sheet.createRow(rowNum++);
        statsRow.createCell(0).setCellValue("Total Usuarios: " + usuarios.size());
        statsRow.createCell(1).setCellValue("Total Cursos: " + cursos.size());
        statsRow.createCell(2).setCellValue("Usuarios Activos: " + usuarios.stream().filter(Usuario::getActivo).count());
        
        rowNum++;
        
        // Top usuarios
        Row topHeaderRow = sheet.createRow(rowNum++);
        Cell topCell = topHeaderRow.createCell(0);
        topCell.setCellValue("TOP 10 USUARIOS POR RACHA");
        topCell.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        CellStyle headerStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        headerStyle.setFont(headerFont);
        headerStyle.setFillForegroundColor(IndexedColors.VIOLET.getIndex());
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        
        Row headerRow = sheet.createRow(rowNum++);
        String[] columns = {"Posición", "Usuario", "Email", "Racha"};
        for (int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerStyle);
        }
        
        List<Usuario> topUsuarios = usuarios.stream()
            .filter(u -> u.getRacha() != null && u.getRacha() > 0)
            .sorted((u1, u2) -> Integer.compare(u2.getRacha(), u1.getRacha()))
            .limit(10)
            .collect(Collectors.toList());
        
        int posicion = 1;
        for (Usuario usuario : topUsuarios) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(posicion++);
            row.createCell(1).setCellValue(usuario.getUsername());
            row.createCell(2).setCellValue(usuario.getEmail());
            row.createCell(3).setCellValue(usuario.getRacha() + " días");
        }
        
        for (int i = 0; i < 4; i++) {
            sheet.autoSizeColumn(i);
        }
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();
        return baos.toByteArray();
    }
    
    // ==================== REPORTES GENERALES ====================
    
    public byte[] generarReporteGeneralPDF(List<Usuario> usuarios, List<Curso> cursos, String fechaDesde, String fechaHasta) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4, 36, 36, 80, 50);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        PdfWriter writer = PdfWriter.getInstance(document, baos);
        HeaderFooter event = new HeaderFooter(usuarioGenerador, fechaGeneracion, "General", "PDF");
        writer.setPageEvent(event);
        
        document.open();
        
        // Encabezado con logo
        PdfPTable headerTable = new PdfPTable(2);
        headerTable.setWidthPercentage(100);
        headerTable.setWidths(new float[]{1, 4});
        
        try {
            ClassPathResource imgFile = new ClassPathResource("static/images/logo.png");
            if (imgFile.exists()) {
                Image logo = Image.getInstance(imgFile.getURL());
                logo.scaleToFit(60, 60);
                PdfPCell logoCell = new PdfPCell(logo);
                logoCell.setBorder(Rectangle.NO_BORDER);
                logoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                logoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                headerTable.addCell(logoCell);
            } else {
                PdfPCell emptyCell = new PdfPCell(new Phrase(""));
                emptyCell.setBorder(Rectangle.NO_BORDER);
                headerTable.addCell(emptyCell);
            }
        } catch (Exception e) {
            PdfPCell emptyCell = new PdfPCell(new Phrase(""));
            emptyCell.setBorder(Rectangle.NO_BORDER);
            headerTable.addCell(emptyCell);
        }
        
        com.itextpdf.text.Font titleFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 20, com.itextpdf.text.Font.BOLD, new BaseColor(249, 115, 22));
        Paragraph title = new Paragraph("SLYCIPHER - Reporte General", titleFont);
        title.setAlignment(Element.ALIGN_LEFT);
        PdfPCell titleCell = new PdfPCell(title);
        titleCell.setBorder(Rectangle.NO_BORDER);
        titleCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        headerTable.addCell(titleCell);
        
        document.add(headerTable);
        document.add(new Paragraph(" "));
        
        // Información de generación
        PdfPTable infoTable = new PdfPTable(4);
        infoTable.setWidthPercentage(100);
        infoTable.setSpacingBefore(10);
        infoTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font infoLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9, com.itextpdf.text.Font.BOLD);
        com.itextpdf.text.Font infoValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        
        infoTable.addCell(createInfoCell("Generado por:", infoLabelFont));
        infoTable.addCell(createInfoCell(usuarioGenerador, infoValueFont));
        infoTable.addCell(createInfoCell("Fecha de generación:", infoLabelFont));
        infoTable.addCell(createInfoCell(fechaGeneracion, infoValueFont));
        
        infoTable.addCell(createInfoCell("Tipo de reporte:", infoLabelFont));
        infoTable.addCell(createInfoCell("General - Resumen Ejecutivo", infoValueFont));
        infoTable.addCell(createInfoCell("Formato:", infoLabelFont));
        infoTable.addCell(createInfoCell("PDF", infoValueFont));
        
        document.add(infoTable);
        
        // Resumen Ejecutivo
        com.itextpdf.text.Font sectionFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 14, com.itextpdf.text.Font.BOLD, new BaseColor(249, 115, 22));
        Paragraph resumenTitle = new Paragraph("Resumen Ejecutivo", sectionFont);
        resumenTitle.setSpacingAfter(10);
        document.add(resumenTitle);
        
        com.itextpdf.text.Font lineFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 1, com.itextpdf.text.Font.NORMAL, new BaseColor(249, 115, 22));
        Paragraph line = new Paragraph("_____________________________________________________________________________________", lineFont);
        line.setAlignment(Element.ALIGN_CENTER);
        document.add(line);
        document.add(new Paragraph(" "));
        
        // Métricas clave de la plataforma
        Map<String, Long> usuariosPorRol = usuarios.stream()
            .collect(Collectors.groupingBy(Usuario::getRol, Collectors.counting()));
        
        long totalUsuarios = usuarios.size();
        long usuariosActivos = usuarios.stream().filter(Usuario::getActivo).count();
        long totalCursos = cursos.size();
        long cursosActivos = cursos.stream()
            .filter(c -> "aprobada".equals(c.getEstado()) && c.getVisible() != null && c.getVisible())
            .count();
        
        PdfPTable statsTable = new PdfPTable(4);
        statsTable.setWidthPercentage(100);
        statsTable.setSpacingBefore(10);
        statsTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font statValueFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 24, com.itextpdf.text.Font.BOLD, new BaseColor(249, 115, 22));
        com.itextpdf.text.Font statLabelFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.NORMAL, BaseColor.DARK_GRAY);
        
        statsTable.addCell(createStatCell(String.valueOf(totalUsuarios), "Total Usuarios", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(usuariosActivos), "Usuarios Activos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(totalCursos), "Total Cursos", statValueFont, statLabelFont));
        statsTable.addCell(createStatCell(String.valueOf(cursosActivos), "Cursos Activos", statValueFont, statLabelFont));
        
        document.add(statsTable);
        
        // Distribución de usuarios por rol
        document.add(new Paragraph(" "));
        Paragraph rolesTitle = new Paragraph("Distribución de Usuarios", sectionFont);
        rolesTitle.setSpacingAfter(10);
        document.add(rolesTitle);
        
        PdfPTable rolesTable = new PdfPTable(2);
        rolesTable.setWidthPercentage(60);
        rolesTable.setHorizontalAlignment(Element.ALIGN_CENTER);
        rolesTable.setSpacingBefore(10);
        rolesTable.setSpacingAfter(15);
        
        com.itextpdf.text.Font headerFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10, com.itextpdf.text.Font.BOLD, BaseColor.WHITE);
        PdfPCell rolHeader = new PdfPCell(new Phrase("ROL", headerFont));
        rolHeader.setBackgroundColor(new BaseColor(249, 115, 22));
        rolHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        rolHeader.setPadding(8);
        rolesTable.addCell(rolHeader);
        
        PdfPCell cantHeader = new PdfPCell(new Phrase("CANTIDAD", headerFont));
        cantHeader.setBackgroundColor(new BaseColor(249, 115, 22));
        cantHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        cantHeader.setPadding(8);
        rolesTable.addCell(cantHeader);
        
        com.itextpdf.text.Font cellFont = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 9);
        for (Map.Entry<String, Long> entry : usuariosPorRol.entrySet()) {
            rolesTable.addCell(createDataCell(entry.getKey(), cellFont));
            rolesTable.addCell(createDataCell(String.valueOf(entry.getValue()), cellFont));
        }
        
        document.add(rolesTable);
        
        // Distribución de cursos por nivel
        document.add(new Paragraph(" "));
        Paragraph cursosTitle = new Paragraph("Distribución de Cursos por Nivel", sectionFont);
        cursosTitle.setSpacingAfter(10);
        document.add(cursosTitle);
        
        Map<String, Long> cursosPorNivel = cursos.stream()
            .collect(Collectors.groupingBy(Curso::getNivel, Collectors.counting()));
        
        PdfPTable nivelesTable = new PdfPTable(2);
        nivelesTable.setWidthPercentage(60);
        nivelesTable.setHorizontalAlignment(Element.ALIGN_CENTER);
        nivelesTable.setSpacingBefore(10);
        
        PdfPCell nivelHeader = new PdfPCell(new Phrase("NIVEL", headerFont));
        nivelHeader.setBackgroundColor(new BaseColor(249, 115, 22));
        nivelHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        nivelHeader.setPadding(8);
        nivelesTable.addCell(nivelHeader);
        
        PdfPCell cantNivelHeader = new PdfPCell(new Phrase("CANTIDAD", headerFont));
        cantNivelHeader.setBackgroundColor(new BaseColor(249, 115, 22));
        cantNivelHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        cantNivelHeader.setPadding(8);
        nivelesTable.addCell(cantNivelHeader);
        
        for (Map.Entry<String, Long> entry : cursosPorNivel.entrySet()) {
            nivelesTable.addCell(createDataCell(entry.getKey(), cellFont));
            nivelesTable.addCell(createDataCell(String.valueOf(entry.getValue()), cellFont));
        }
        
        document.add(nivelesTable);
        
        document.close();
        return baos.toByteArray();
    }
    
    public byte[] generarReporteGeneralExcel(List<Usuario> usuarios, List<Curso> cursos) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Reporte General");
        
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String usuarioGenerador = auth != null ? auth.getName() : "Sistema";
        String fechaGeneracion = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        
        int rowNum = 0;
        
        // Título
        Row titleRow = sheet.createRow(rowNum++);
        Cell titleCell = titleRow.createCell(0);
        titleCell.setCellValue("SLYCIPHER - Reporte General - Resumen Ejecutivo");
        CellStyle titleStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font titleFont = workbook.createFont();
        titleFont.setBold(true);
        titleFont.setFontHeightInPoints((short) 16);
        titleFont.setColor(IndexedColors.ORANGE.getIndex());
        titleStyle.setFont(titleFont);
        titleCell.setCellStyle(titleStyle);
        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 3));
        
        rowNum++;
        
        // Info generación
        CellStyle labelStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font labelFont = workbook.createFont();
        labelFont.setBold(true);
        labelStyle.setFont(labelFont);
        
        Row infoRow1 = sheet.createRow(rowNum++);
        Cell labelCell1 = infoRow1.createCell(0);
        labelCell1.setCellValue("Generado por:");
        labelCell1.setCellStyle(labelStyle);
        infoRow1.createCell(1).setCellValue(usuarioGenerador);
        
        Row infoRow2 = sheet.createRow(rowNum++);
        Cell labelCell2 = infoRow2.createCell(0);
        labelCell2.setCellValue("Fecha:");
        labelCell2.setCellStyle(labelStyle);
        infoRow2.createCell(1).setCellValue(fechaGeneracion);
        
        rowNum++;
        
        // Métricas principales
        Row metricsHeaderRow = sheet.createRow(rowNum++);
        Cell metricsCell = metricsHeaderRow.createCell(0);
        metricsCell.setCellValue("MÉTRICAS PRINCIPALES");
        CellStyle seccionStyle = workbook.createCellStyle();
        org.apache.poi.ss.usermodel.Font seccionFont = workbook.createFont();
        seccionFont.setBold(true);
        seccionFont.setFontHeightInPoints((short) 12);
        seccionFont.setColor(IndexedColors.ORANGE.getIndex());
        seccionStyle.setFont(seccionFont);
        metricsCell.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 3));
        
        Row metricsRow = sheet.createRow(rowNum++);
        metricsRow.createCell(0).setCellValue("Total Usuarios");
        metricsRow.createCell(1).setCellValue(usuarios.size());
        metricsRow.createCell(2).setCellValue("Total Cursos");
        metricsRow.createCell(3).setCellValue(cursos.size());
        
        rowNum++;
        
        // Distribución por roles
        Row rolesHeaderRow = sheet.createRow(rowNum++);
        Cell rolesCell = rolesHeaderRow.createCell(0);
        rolesCell.setCellValue("DISTRIBUCIÓN DE USUARIOS POR ROL");
        rolesCell.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 1));
        
        Map<String, Long> usuariosPorRol = usuarios.stream()
            .collect(Collectors.groupingBy(Usuario::getRol, Collectors.counting()));
        
        for (Map.Entry<String, Long> entry : usuariosPorRol.entrySet()) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(entry.getKey());
            row.createCell(1).setCellValue(entry.getValue());
        }
        
        rowNum++;
        
        // Distribución de cursos por nivel
        Row cursosHeaderRow = sheet.createRow(rowNum++);
        Cell cursosCell = cursosHeaderRow.createCell(0);
        cursosCell.setCellValue("DISTRIBUCIÓN DE CURSOS POR NIVEL");
        cursosCell.setCellStyle(seccionStyle);
        sheet.addMergedRegion(new CellRangeAddress(rowNum - 1, rowNum - 1, 0, 1));
        
        Map<String, Long> cursosPorNivel = cursos.stream()
            .collect(Collectors.groupingBy(Curso::getNivel, Collectors.counting()));
        
        for (Map.Entry<String, Long> entry : cursosPorNivel.entrySet()) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(entry.getKey());
            row.createCell(1).setCellValue(entry.getValue());
        }
        
        for (int i = 0; i < 4; i++) {
            sheet.autoSizeColumn(i);
        }
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        workbook.write(baos);
        workbook.close();
        return baos.toByteArray();
    }
}
