package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.util.PasswordValidator;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping
public class AuthController {
    private final UsuarioService usuarioService;

    private final PasswordEncoder passwordEncoder;

    public AuthController(UsuarioService usuarioService, PasswordEncoder passwordEncoder) {
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/")
    public String index() {
        return "redirect:/home";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "register";
    }

    @PostMapping("/register")
    public String registerSubmit(@ModelAttribute Usuario usuario, Model model) {
        try {
            // Validar contraseña
            List<String> passwordErrors = PasswordValidator.validate(usuario.getPasswordHash());
            if (!passwordErrors.isEmpty()) {
                model.addAttribute("errors", passwordErrors);
                model.addAttribute("usuario", usuario);
                return "register";
            }
            
            // Verificar si el email ya existe
            if (usuarioService.findByEmail(usuario.getEmail()) != null) {
                model.addAttribute("error", "El email ya está registrado");
                model.addAttribute("usuario", usuario);
                return "register";
            }
            
            // Verificar si el username ya existe
            if (usuarioService.findByUsername(usuario.getUsername()) != null) {
                model.addAttribute("error", "El nombre de usuario ya está en uso");
                model.addAttribute("usuario", usuario);
                return "register";
            }
            
            // Hashear la contraseña antes de guardar
            if (usuario.getPasswordHash() != null && !usuario.getPasswordHash().isEmpty()) {
                String hashed = passwordEncoder.encode(usuario.getPasswordHash());
                usuario.setPasswordHash(hashed);
            }
            
            // Generar username a partir del email si no existe
            if (usuario.getUsername() == null || usuario.getUsername().isEmpty()) {
                usuario.setUsername(usuario.getEmail().split("@")[0]);
            }
            
            // Establecer rol por defecto
            if (usuario.getRol() == null || usuario.getRol().isEmpty()) {
                usuario.setRol("STUDENT");
            }
            
            // Establecer fecha de creación
            usuario.setCreadoEn(java.time.LocalDateTime.now());
            usuario.setActivo(true);
            
            usuarioService.save(usuario);
            return "redirect:/login?registered=true";
        } catch (Exception e) {
            model.addAttribute("error", "Error al registrar usuario: " + e.getMessage());
            model.addAttribute("usuario", usuario);
            return "register";
        }
    }
    
    @GetMapping("/setup-users")
    @ResponseBody
    public String setupUsers() {
        try {
            // Admin1 - Juan Lopez
            if (usuarioService.findByEmail("admin1@example.com") == null) {
                Usuario admin1 = new Usuario();
                admin1.setUsername("juanlopez");
                admin1.setNombre("Juan");
                admin1.setApellido("Lopez");
                admin1.setEmail("admin1@example.com");
                admin1.setPasswordHash(passwordEncoder.encode("Adminsly123!"));
                admin1.setRol("ADMIN");
                admin1.setCreadoEn(java.time.LocalDateTime.now());
                admin1.setActivo(true);
                usuarioService.save(admin1);
            }
            
            // Developer1
            if (usuarioService.findByEmail("dev1@example.com") == null) {
                Usuario dev1 = new Usuario();
                dev1.setUsername("developer1");
                dev1.setNombre("Carlos");
                dev1.setApellido("Desarrollador");
                dev1.setEmail("dev1@example.com");
                dev1.setPasswordHash(passwordEncoder.encode("Devsly123!"));
                dev1.setRol("DEVELOPER");
                dev1.setCreadoEn(java.time.LocalDateTime.now());
                dev1.setActivo(true);
                usuarioService.save(dev1);
            }
            
            // Student1
            if (usuarioService.findByEmail("est1@example.com") == null) {
                Usuario est1 = new Usuario();
                est1.setUsername("estudiante1");
                est1.setNombre("Ana");
                est1.setApellido("Estudiante");
                est1.setEmail("est1@example.com");
                est1.setPasswordHash(passwordEncoder.encode("Estsly123*"));
                est1.setRol("STUDENT");
                est1.setCreadoEn(java.time.LocalDateTime.now());
                est1.setActivo(true);
                usuarioService.save(est1);
            }
            
            return "Usuarios creados exitosamente!<br>" +
                   "Admin1: admin1@example.com / Adminsly123!<br>" +
                   "Developer1: dev1@example.com / Devsly123!<br>" +
                   "Student1: est1@example.com / Estsly123*<br>" +
                   "<a href='/login'>Ir al login</a>";
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}
