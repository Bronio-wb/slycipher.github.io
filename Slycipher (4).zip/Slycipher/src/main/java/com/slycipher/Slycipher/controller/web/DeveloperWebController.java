package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Categoria;
import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Desafio;
import com.slycipher.Slycipher.model.Lenguaje;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.service.CursoService;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.LeccionService;
import com.slycipher.Slycipher.service.DesafioService;
import com.slycipher.Slycipher.service.CategoriaService;
import com.slycipher.Slycipher.service.LenguajeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/developer")
public class DeveloperWebController {

    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private LeccionService leccionService;
    
    @Autowired
    private DesafioService desafioService;
    
    @Autowired
    private CategoriaService categoriaService;
    
    @Autowired
    private LenguajeService lenguajeService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("misCursos", misCursos.size());
        model.addAttribute("totalLecciones", leccionService.getAllLecciones().size());
        model.addAttribute("totalDesafios", desafioService.getAllDesafios().size());
        model.addAttribute("pendientes", 1);
        
        // Cursos recientes (últimos 5) - filtrar nulls y ordenar
        List<Curso> cursosRecientes = misCursos.stream()
            .filter(c -> c.getFechaCreacion() != null)
            .sorted((c1, c2) -> c2.getFechaCreacion().compareTo(c1.getFechaCreacion()))
            .limit(5)
            .collect(Collectors.toList());
        
        model.addAttribute("cursosRecientes", cursosRecientes);
        
        return "developer/dashboard";
    }
    
    @GetMapping("/cursos")
    public String cursos(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener todos los cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("cursos", misCursos);
        
        return "developer/cursos";
    }
    
    @GetMapping("/crear-curso")
    public String crearCursoForm(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", new Curso());
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("lenguajes", lenguajeService.findAll());
        
        return "developer/crear-curso";
    }
    
    @PostMapping("/crear-curso")
    public String crearCurso(@RequestParam("titulo") String titulo,
                            @RequestParam("descripcion") String descripcion,
                            @RequestParam("categoryId") Long categoryId,
                            @RequestParam("languageId") Long languageId,
                            @RequestParam("nivel") String nivel,
                            @RequestParam(value = "duracion", required = false) String duracion,
                            @RequestParam("precio") String precio,
                            @RequestParam(value = "requisitos", required = false) String requisitos,
                            @RequestParam(value = "estado", required = false, defaultValue = "false") Boolean estado,
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {
        try {
            Usuario developer = usuarioService.getUserByUsername(authentication.getName());
            
            Curso curso = new Curso();
            curso.setTitulo(titulo);
            curso.setDescripcion(descripcion);
            curso.setNivel(nivel);
            curso.setDuracionEstimada(duracion != null && !duracion.isEmpty() ? duracion : null);
            curso.setPrecio(new BigDecimal(precio));
            curso.setRequisitos(requisitos);
            curso.setEstado("pendiente");
            curso.setVisible(estado != null && estado ? true : false);
            curso.setCreadoPor(developer.getUserId());
            curso.setFechaCreacion(LocalDateTime.now());
            
            // Asignar IDs directamente
            curso.setCategoryId(categoryId);
            curso.setLanguageId(languageId);
            
            cursoService.createCurso(curso);
            redirectAttributes.addFlashAttribute("success", "Curso creado exitosamente");
            return "redirect:/developer/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear curso: " + e.getMessage());
            return "redirect:/developer/crear-curso";
        }
    }
    
    @PostMapping("/cursos/{id}/toggle")
    public String toggleCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/developer/cursos";
            }
            
            // Manejar null como false
            Boolean currentVisible = curso.getVisible();
            if (currentVisible == null) {
                currentVisible = false;
            }
            
            curso.setVisible(!currentVisible);
            cursoService.updateCurso(id, curso);
            
            redirectAttributes.addFlashAttribute("success", 
                curso.getVisible() ? "Curso activado exitosamente" : "Curso desactivado exitosamente");
            return "redirect:/developer/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar estado del curso: " + e.getMessage());
            return "redirect:/developer/cursos";
        }
    }
    
    @PostMapping("/cursos/{id}/eliminar")
    public String eliminarCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/developer/cursos";
            }
            
            cursoService.deleteCurso(id);
            redirectAttributes.addFlashAttribute("success", "Curso eliminado exitosamente");
            return "redirect:/developer/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar curso: " + e.getMessage());
            return "redirect:/developer/cursos";
        }
    }
    
    @GetMapping("/cursos/{id}/lecciones")
    public String verLecciones(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/developer/cursos";
        }
        
        // Cargar relaciones necesarias
        String categoriaNombre = "";
        String lenguajeNombre = "";
        
        if (curso.getCategoryId() != null) {
            Categoria categoria = categoriaService.findById(curso.getCategoryId()).orElse(null);
            if (categoria != null) {
                categoriaNombre = categoria.getNombre();
            }
        }
        
        if (curso.getLanguageId() != null) {
            Lenguaje lenguaje = lenguajeService.findById(curso.getLanguageId()).orElse(null);
            if (lenguaje != null) {
                lenguajeNombre = lenguaje.getNombre();
            }
        }
        
        // Cargar lecciones del curso desde el servicio (evita LazyInitializationException)
        List<com.slycipher.Slycipher.model.Leccion> lecciones = leccionService.findByCursoId(id);
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", curso);
        model.addAttribute("categoriaNombre", categoriaNombre);
        model.addAttribute("lenguajeNombre", lenguajeNombre);
        model.addAttribute("lecciones", lecciones);
        
        return "developer/curso-lecciones";
    }
    
    @GetMapping("/cursos/{id}/ver")
    public String verCurso(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/developer/cursos";
        }
        
        // Cargar relaciones necesarias
        String categoriaNombre = "";
        String lenguajeNombre = "";
        
        if (curso.getCategoryId() != null) {
            Categoria categoria = categoriaService.findById(curso.getCategoryId()).orElse(null);
            if (categoria != null) {
                categoriaNombre = categoria.getNombre();
            }
        }
        
        if (curso.getLanguageId() != null) {
            Lenguaje lenguaje = lenguajeService.findById(curso.getLanguageId()).orElse(null);
            if (lenguaje != null) {
                lenguajeNombre = lenguaje.getNombre();
            }
        }
        
        // Cargar lecciones del curso
        List<com.slycipher.Slycipher.model.Leccion> lecciones = leccionService.findByCursoId(id);
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", curso);
        model.addAttribute("categoriaNombre", categoriaNombre);
        model.addAttribute("lenguajeNombre", lenguajeNombre);
        model.addAttribute("lecciones", lecciones);
        model.addAttribute("totalLecciones", lecciones.size());
        
        return "developer/ver-curso";
    }
    
    @GetMapping("/cursos/{id}/editar")
    public String editarCursoForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/developer/cursos";
        }
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", curso);
        model.addAttribute("categorias", categoriaService.findAll());
        model.addAttribute("lenguajes", lenguajeService.findAll());
        
        return "developer/editar-curso";
    }
    
    @PostMapping("/cursos/{id}/editar")
    public String editarCurso(@PathVariable Long id,
                              @RequestParam String titulo,
                              @RequestParam String descripcion,
                              @RequestParam Long categoryId,
                              @RequestParam Long languageId,
                              @RequestParam String nivel,
                              @RequestParam(required = false) String duracion,
                              @RequestParam String precio,
                              @RequestParam(required = false) String requisitos,
                              @RequestParam(defaultValue = "false") Boolean estado,
                              RedirectAttributes redirectAttributes,
                              Authentication authentication) {
        try {
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/developer/cursos";
            }
            
            curso.setTitulo(titulo);
            curso.setDescripcion(descripcion);
            curso.setCategoryId(categoryId);
            curso.setLanguageId(languageId);
            curso.setNivel(nivel);
            curso.setDuracionEstimada(duracion);
            curso.setPrecio(new BigDecimal(precio));
            curso.setRequisitos(requisitos);
            curso.setVisible(estado != null && estado ? true : false);
            
            cursoService.updateCurso(id, curso);
            redirectAttributes.addFlashAttribute("success", "Curso actualizado exitosamente");
            return "redirect:/developer/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar curso: " + e.getMessage());
            return "redirect:/developer/cursos/{id}/editar";
        }
    }
    
    @GetMapping("/cursos/{id}/lecciones/crear")
    public String crearLeccionForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/developer/cursos";
        }
        
        // Cargar categoría y lenguaje
        String categoriaNombre = "";
        String lenguajeNombre = "";
        
        if (curso.getCategoryId() != null) {
            Categoria categoria = categoriaService.findById(curso.getCategoryId()).orElse(null);
            if (categoria != null) {
                categoriaNombre = categoria.getNombre();
            }
        }
        
        if (curso.getLanguageId() != null) {
            Lenguaje lenguaje = lenguajeService.findById(curso.getLanguageId()).orElse(null);
            if (lenguaje != null) {
                lenguajeNombre = lenguaje.getNombre();
            }
        }
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", curso);
        model.addAttribute("categoriaNombre", categoriaNombre);
        model.addAttribute("lenguajeNombre", lenguajeNombre);
        model.addAttribute("leccion", new com.slycipher.Slycipher.model.Leccion());
        
        return "developer/crear-leccion";
    }
    
    @PostMapping("/cursos/{id}/lecciones/crear")
    public String crearLeccion(@PathVariable Long id,
                              @RequestParam(required = false) String titulo,
                              @RequestParam(required = false) String contenido,
                              @RequestParam(required = false) String codigoEjemplo,
                              @RequestParam(required = false) Integer orden,
                              @RequestParam(required = false) Boolean estado,
                              RedirectAttributes redirectAttributes,
                              Model model,
                              Authentication authentication) {
        try {
            // Validaciones
            if (titulo == null || titulo.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "El título es obligatorio");
                return "redirect:/developer/cursos/" + id + "/lecciones/crear";
            }
            
            if (contenido == null || contenido.trim().isEmpty()) {
                redirectAttributes.addFlashAttribute("error", "El contenido es obligatorio");
                return "redirect:/developer/cursos/" + id + "/lecciones/crear";
            }
            
            if (orden == null || orden < 1) {
                redirectAttributes.addFlashAttribute("error", "El orden debe ser un número mayor a 0");
                return "redirect:/developer/cursos/" + id + "/lecciones/crear";
            }
            
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/developer/cursos";
            }
            
            com.slycipher.Slycipher.model.Leccion leccion = new com.slycipher.Slycipher.model.Leccion();
            leccion.setCourseId(id);
            leccion.setTitulo(titulo.trim());
            leccion.setContenido(contenido.trim());
            leccion.setCodigoEjemplo(codigoEjemplo != null ? codigoEjemplo.trim() : null);
            leccion.setOrden(orden);
            leccion.setEstado("pendiente");
            leccion.setVisible(estado != null && estado ? true : false);
            
            leccionService.save(leccion);
            redirectAttributes.addFlashAttribute("success", "Lección creada exitosamente");
            return "redirect:/developer/cursos/" + id + "/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear lección: " + e.getMessage());
            return "redirect:/developer/cursos/" + id + "/lecciones/crear";
        }
    }
    
    @GetMapping("/lecciones/{id}/editar")
    public String editarLeccionForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null) {
            return "redirect:/developer/cursos";
        }
        
        Curso curso = cursoService.getCursoById(leccion.getCourseId());
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("curso", curso);
        model.addAttribute("leccion", leccion);
        
        return "developer/editar-leccion";
    }
    
    @PostMapping("/lecciones/{id}/editar")
    public String editarLeccion(@PathVariable Long id,
                               @RequestParam String titulo,
                               @RequestParam String contenido,
                               @RequestParam(required = false) String codigoEjemplo,
                               @RequestParam Integer orden,
                               @RequestParam(required = false) Boolean estado,
                               RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/developer/cursos";
            }
            
            Long cursoId = leccion.getCourseId();
            
            leccion.setTitulo(titulo);
            leccion.setContenido(contenido);
            leccion.setCodigoEjemplo(codigoEjemplo != null ? codigoEjemplo.trim() : null);
            leccion.setOrden(orden);
            leccion.setVisible(estado != null && estado ? true : false);
            
            leccionService.save(leccion);
            redirectAttributes.addFlashAttribute("success", "Lección actualizada exitosamente");
            return "redirect:/developer/cursos/" + cursoId + "/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar lección: " + e.getMessage());
            return "redirect:/developer/lecciones/" + id + "/editar";
        }
    }
    
    @PostMapping("/lecciones/{id}/eliminar")
    public String eliminarLeccion(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/developer/cursos";
            }
            
            Long cursoId = leccion.getCourseId();
            
            leccionService.deleteById(id);
            redirectAttributes.addFlashAttribute("success", "Lección eliminada exitosamente");
            return "redirect:/developer/cursos/" + cursoId + "/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar lección: " + e.getMessage());
            return "redirect:/developer/cursos";
        }
    }
    
    @GetMapping("/desafios")
    public String desafios(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        // Obtener todos los desafíos
        List<Desafio> todosDesafios = desafioService.getAllDesafios();
        
        // Agrupar desafíos por curso
        java.util.Map<Long, List<Desafio>> desafiosPorCurso = new java.util.HashMap<>();
        for (Curso curso : misCursos) {
            List<Desafio> desafiosCurso = todosDesafios.stream()
                .filter(d -> d.getCourseId() != null && d.getCourseId().equals(curso.getCourseId()))
                .collect(Collectors.toList());
            desafiosPorCurso.put(curso.getCourseId(), desafiosCurso);
        }
        
        // Calcular estadísticas
        long totalFacil = todosDesafios.stream().filter(d -> "Fácil".equals(d.getDificultad())).count();
        long totalMedio = todosDesafios.stream().filter(d -> "Medio".equals(d.getDificultad())).count();
        long totalDificil = todosDesafios.stream().filter(d -> "Difícil".equals(d.getDificultad())).count();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("cursos", misCursos);
        model.addAttribute("desafiosPorCurso", desafiosPorCurso);
        model.addAttribute("totalDesafios", todosDesafios.size());
        model.addAttribute("totalFacil", totalFacil);
        model.addAttribute("totalMedio", totalMedio);
        model.addAttribute("totalDificil", totalDificil);
        
        return "developer/desafios";
    }
    
    @GetMapping("/desafios/crear")
    public String crearDesafioForm(@RequestParam(required = false) Long cursoId, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        // Obtener lenguajes
        List<Lenguaje> lenguajes = lenguajeService.findAll();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("cursos", misCursos);
        model.addAttribute("lenguajes", lenguajes);
        model.addAttribute("cursoId", cursoId);
        model.addAttribute("desafio", new Desafio());
        
        return "developer/crear-desafio";
    }
    
    @PostMapping("/desafios/crear")
    public String crearDesafio(@ModelAttribute Desafio desafio, RedirectAttributes redirectAttributes) {
        try {
            desafioService.save(desafio);
            redirectAttributes.addFlashAttribute("success", "Desafío creado exitosamente");
            return "redirect:/developer/desafios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear desafío: " + e.getMessage());
            return "redirect:/developer/desafios/crear";
        }
    }
    
    @GetMapping("/desafios/{id}/ver")
    public String verDesafio(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        Desafio desafio = desafioService.findById(id).orElse(null);
        
        if (desafio == null) {
            return "redirect:/developer/desafios";
        }
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        
        return "developer/ver-desafio";
    }
    
    @GetMapping("/desafios/{id}/editar")
    public String editarDesafioForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        Desafio desafio = desafioService.findById(id).orElse(null);
        
        if (desafio == null) {
            return "redirect:/developer/desafios";
        }
        
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        List<Lenguaje> lenguajes = lenguajeService.findAll();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        model.addAttribute("cursos", misCursos);
        model.addAttribute("lenguajes", lenguajes);
        
        return "developer/editar-desafio";
    }
    
    @PostMapping("/desafios/{id}/editar")
    public String editarDesafio(@PathVariable Long id, @ModelAttribute Desafio desafio, RedirectAttributes redirectAttributes) {
        try {
            desafio.setChallengeId(id);
            desafioService.save(desafio);
            redirectAttributes.addFlashAttribute("success", "Desafío actualizado exitosamente");
            return "redirect:/developer/desafios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar desafío: " + e.getMessage());
            return "redirect:/developer/desafios/" + id + "/editar";
        }
    }
    
    @PostMapping("/desafios/{id}/eliminar")
    public String eliminarDesafio(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            desafioService.deleteById(id);
            redirectAttributes.addFlashAttribute("success", "Desafío eliminado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar desafío: " + e.getMessage());
        }
        return "redirect:/developer/desafios";
    }
    
    @GetMapping("/estadisticas")
    public String estadisticas(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        // Obtener desafíos del desarrollador
        List<Desafio> misDesafios = desafioService.getAllDesafios();
        
        // Calcular estadísticas básicas
        long totalCursos = misCursos.size();
        long totalDesafios = misDesafios.size();
        long cursosActivos = misCursos.stream().filter(c -> c.getVisible() != null && c.getVisible()).count();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("totalCursos", totalCursos);
        model.addAttribute("totalDesafios", totalDesafios);
        model.addAttribute("cursosActivos", cursosActivos);
        
        return "developer/estadisticas";
    }
}
