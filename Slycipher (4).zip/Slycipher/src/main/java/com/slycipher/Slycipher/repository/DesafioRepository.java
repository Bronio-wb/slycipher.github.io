package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Desafio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DesafioRepository extends JpaRepository<Desafio, Long> {
    List<Desafio> findByCourseId(Long courseId);
    List<Desafio> findByLanguageId(Long languageId);
    
    @Modifying
    @Query("DELETE FROM Desafio d WHERE d.courseId = :cursoId")
    void deleteByCursoId(@Param("cursoId") Long cursoId);
}
