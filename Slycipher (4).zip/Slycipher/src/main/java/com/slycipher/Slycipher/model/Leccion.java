package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lecciones")
public class Leccion {
    @Id
    @Column(name = "lesson_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long lessonId;

    @Column(name = "course_id")
    private Long courseId;

    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String contenido;

    @Column(name = "codigo_ejemplo", columnDefinition = "TEXT")
    private String codigoEjemplo;

    private Integer orden;
    private String estado;
    private Boolean visible;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", insertable = false, updatable = false)
    private Curso curso;

    @OneToMany(mappedBy = "leccion", fetch = FetchType.LAZY)
    private List<ProgresoUsuario> progresos = new ArrayList<>();

    // getters/setters
    public Long getLessonId() { return lessonId; }
    public void setLessonId(Long lessonId) { this.lessonId = lessonId; }
    
    // Alias para compatibilidad con templates
    public Long getLeccionId() { return lessonId; }
    public void setLeccionId(Long leccionId) { this.lessonId = leccionId; }
    
    public Long getCourseId() { return courseId; }
    public void setCourseId(Long courseId) { this.courseId = courseId; }
    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }
    public String getContenido() { return contenido; }
    public void setContenido(String contenido) { this.contenido = contenido; }
    public String getCodigoEjemplo() { return codigoEjemplo; }
    public void setCodigoEjemplo(String codigoEjemplo) { this.codigoEjemplo = codigoEjemplo; }
    public Integer getOrden() { return orden; }
    public void setOrden(Integer orden) { this.orden = orden; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Boolean getVisible() { return visible; }
    public void setVisible(Boolean visible) { this.visible = visible; }
    public Curso getCurso() { return curso; }
    public void setCurso(Curso curso) { this.curso = curso; }
    public List<ProgresoUsuario> getProgresos() { return progresos; }
    public void setProgresos(List<ProgresoUsuario> progresos) { this.progresos = progresos; }
}
