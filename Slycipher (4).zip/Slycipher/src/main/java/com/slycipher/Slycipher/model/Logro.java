package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "logros")
public class Logro {
    @Id
    @Column(name = "achievement_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long achievementId;

    private String nombre;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    private String icono;

    @Column(name = "puntos_requeridos")
    private Integer puntosRequeridos;

    private String tipo;
    private Boolean activo;

    @Column(name = "fecha_creacion")
    private LocalDateTime fechaCreacion;

    @OneToMany(mappedBy = "logro", fetch = FetchType.LAZY)
    private List<LogroUsuario> logrosUsuarios = new ArrayList<>();

    // getters/setters
    public Long getAchievementId() { return achievementId; }
    public void setAchievementId(Long achievementId) { this.achievementId = achievementId; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public String getIcono() { return icono; }
    public void setIcono(String icono) { this.icono = icono; }
    public Integer getPuntosRequeridos() { return puntosRequeridos; }
    public void setPuntosRequeridos(Integer puntosRequeridos) { this.puntosRequeridos = puntosRequeridos; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public Boolean getActivo() { return activo; }
    public void setActivo(Boolean activo) { this.activo = activo; }
    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }
    public List<LogroUsuario> getLogrosUsuarios() { return logrosUsuarios; }
    public void setLogrosUsuarios(List<LogroUsuario> logrosUsuarios) { this.logrosUsuarios = logrosUsuarios; }
}
