package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Leccion;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.model.Desafio;
import com.slycipher.Slycipher.service.CursoService;
import com.slycipher.Slycipher.service.LeccionService;
import com.slycipher.Slycipher.service.ProgresoUsuarioService;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.DesafioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentWebController {

    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private LeccionService leccionService;
    
    @Autowired
    private ProgresoUsuarioService progresoUsuarioService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private DesafioService desafioService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener solo cursos aprobados y visibles (máximo 6 para el dashboard)
        List<Curso> cursosDisponibles = cursoService.getApprovedAndVisibleCursos();
        model.addAttribute("cursosDisponibles", cursosDisponibles.stream().limit(6).collect(java.util.stream.Collectors.toList()));
        
        // Obtener progreso del estudiante
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        model.addAttribute("progresosRecientes", progresos.stream().limit(5).collect(java.util.stream.Collectors.toList()));
        
        // Estadísticas del estudiante
        model.addAttribute("cursosInscritos", 0); // TODO: Implementar cuando haya inscripciones
        model.addAttribute("logros", progresos.size());
        model.addAttribute("puntos", 0); // TODO: Implementar desafíos
        
        return "student/dashboard";
    }
    
    @GetMapping("/cursos")
    public String cursos(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        
        // Obtener solo cursos aprobados y visibles
        List<Curso> cursosDisponibles = cursoService.getApprovedAndVisibleCursos();
        model.addAttribute("cursos", cursosDisponibles);
        
        return "student/cursos";
    }
    
    @GetMapping("/cursos/{id}")
    public String verCurso(@PathVariable Long id, Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        
        Curso curso = cursoService.getCursoById(id);
        if (curso == null || !"aprobada".equals(curso.getEstado()) || !Boolean.TRUE.equals(curso.getVisible())) {
            return "redirect:/student/cursos";
        }
        
        model.addAttribute("curso", curso);
        return "student/ver-curso";
    }
    
    @PostMapping("/cursos/{id}/inscribir")
    public String inscribirseCurso(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        Curso curso = cursoService.getCursoById(id);
        if (curso == null || !"aprobada".equals(curso.getEstado()) || !Boolean.TRUE.equals(curso.getVisible())) {
            redirectAttributes.addFlashAttribute("error", "El curso no está disponible");
            return "redirect:/student/cursos";
        }
        
        // TODO: Implementar lógica de inscripción en base de datos
        redirectAttributes.addFlashAttribute("success", "Te has inscrito exitosamente al curso: " + curso.getTitulo());
        return "redirect:/student/cursos/" + id;
    }
    
    @GetMapping("/lecciones/{id}")
    public String verLeccion(@PathVariable Long id, Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        
        Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null || !Boolean.TRUE.equals(leccion.getVisible())) {
            return "redirect:/student/cursos";
        }
        
        // Obtener todas las lecciones del curso ordenadas
        List<Leccion> todasLecciones = leccionService.findByCursoId(leccion.getCourseId())
            .stream()
            .filter(l -> Boolean.TRUE.equals(l.getVisible()))
            .sorted((l1, l2) -> {
                Integer orden1 = l1.getOrden() != null ? l1.getOrden() : 0;
                Integer orden2 = l2.getOrden() != null ? l2.getOrden() : 0;
                return orden1.compareTo(orden2);
            })
            .collect(java.util.stream.Collectors.toList());
        
        // Encontrar índice de la lección actual
        int currentIndex = -1;
        for (int i = 0; i < todasLecciones.size(); i++) {
            if (todasLecciones.get(i).getLeccionId().equals(id)) {
                currentIndex = i;
                break;
            }
        }
        
        // Determinar lección anterior y siguiente
        Leccion leccionAnterior = null;
        Leccion leccionSiguiente = null;
        
        if (currentIndex > 0) {
            leccionAnterior = todasLecciones.get(currentIndex - 1);
        }
        
        if (currentIndex >= 0 && currentIndex < todasLecciones.size() - 1) {
            leccionSiguiente = todasLecciones.get(currentIndex + 1);
        }
        
        model.addAttribute("leccion", leccion);
        model.addAttribute("leccionAnterior", leccionAnterior);
        model.addAttribute("leccionSiguiente", leccionSiguiente);
        
        // Obtener el lenguaje del curso de forma segura
        String lenguaje = "python"; // Por defecto
        try {
            Curso curso = cursoService.findByIdWithDetails(leccion.getCourseId()).orElse(null);
            if (curso != null && curso.getLenguaje() != null) {
                lenguaje = curso.getLenguaje().getNombre().toLowerCase();
            }
        } catch (Exception e) {
            // Si hay error, usar Python por defecto
            lenguaje = "python";
        }
        model.addAttribute("lenguaje", lenguaje);
        
        // Verificar si la lección ya está completada
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario != null) {
            boolean completada = progresoUsuarioService.isLeccionCompletada(usuario.getUserId(), id);
            model.addAttribute("leccionCompletada", completada);
        } else {
            model.addAttribute("leccionCompletada", false);
        }
        
        return "student/ver-leccion";
    }
    
    @PostMapping("/lecciones/{id}/completar")
    public String completarLeccion(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null) {
            redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
            return "redirect:/student/cursos";
        }
        
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
            return "redirect:/student/lecciones/" + id;
        }
        
        try {
            progresoUsuarioService.marcarLeccionCompletada(usuario.getUserId(), id);
            redirectAttributes.addFlashAttribute("success", "¡Lección marcada como completada!");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al marcar la lección como completada");
        }
        
        return "redirect:/student/lecciones/" + id;
    }
    
    @GetMapping("/progreso")
    public String miProgreso(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener lecciones completadas
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        model.addAttribute("progresos", progresos);
        
        return "student/progreso";
    }
    
    @GetMapping("/logros")
    public String logros(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener lecciones completadas para calcular logros
        List<com.slycipher.Slycipher.model.ProgresoUsuario> progresos = progresoUsuarioService.findByUsuarioId(usuario.getUserId());
        model.addAttribute("leccionesCompletadas", progresos.size());
        
        return "student/logros";
    }
    
    @GetMapping("/desafios")
    public String desafios(Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        
        // Obtener todos los desafíos disponibles
        List<Desafio> desafios = desafioService.getAllDesafios();
        model.addAttribute("desafios", desafios);
        model.addAttribute("desafiosDisponibles", desafios.size());
        model.addAttribute("desafiosCompletados", 0); // TODO: Implementar cuando haya seguimiento de desafíos completados
        
        return "student/desafios";
    }
    
    @GetMapping("/desafios/{id}")
    public String verDesafio(@PathVariable Long id, Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        Desafio desafio = desafioService.getDesafioById(id);
        if (desafio == null) {
            return "redirect:/student/desafios";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        
        return "student/ver-desafio";
    }
    
    @GetMapping("/desafios/{id}/intentar")
    public String intentarDesafio(@PathVariable Long id, Authentication authentication, Model model) {
        Usuario usuario = usuarioService.findByUsername(authentication.getName()).orElse(null);
        if (usuario == null) {
            return "redirect:/login";
        }
        
        Desafio desafio = desafioService.getDesafioById(id);
        if (desafio == null) {
            return "redirect:/student/desafios";
        }
        
        model.addAttribute("username", usuario.getUsername());
        model.addAttribute("racha", usuario.getRacha() != null ? usuario.getRacha() : 0);
        model.addAttribute("desafio", desafio);
        
        return "student/intentar-desafio";
    }
    
    @PostMapping("/desafios/ejecutar")
    @org.springframework.web.bind.annotation.ResponseBody
    public java.util.Map<String, String> ejecutarCodigo(@org.springframework.web.bind.annotation.RequestBody java.util.Map<String, String> request) {
        String codigo = request.get("codigo");
        java.util.Map<String, String> response = new java.util.HashMap<>();
        
        if (codigo == null || codigo.trim().isEmpty()) {
            response.put("error", "No se proporcionó código para ejecutar");
            return response;
        }
        
        try {
            // Crear un archivo temporal con el código
            java.io.File tempFile = java.io.File.createTempFile("codigo_", ".py");
            tempFile.deleteOnExit();
            
            java.io.FileWriter writer = new java.io.FileWriter(tempFile);
            writer.write(codigo);
            writer.close();
            
            // Ejecutar el código Python
            ProcessBuilder processBuilder = new ProcessBuilder("python", tempFile.getAbsolutePath());
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();
            
            // Capturar la salida con timeout de 5 segundos
            StringBuilder output = new StringBuilder();
            java.io.BufferedReader reader = new java.io.BufferedReader(
                new java.io.InputStreamReader(process.getInputStream())
            );
            
            // Esperar máximo 5 segundos
            boolean finished = process.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);
            
            if (!finished) {
                process.destroy();
                response.put("error", "Tiempo de ejecución excedido (máximo 5 segundos)");
                return response;
            }
            
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            
            int exitCode = process.exitValue();
            if (exitCode != 0 && output.length() > 0) {
                response.put("error", output.toString().trim());
            } else {
                response.put("salida", output.toString().trim());
            }
            
            reader.close();
            tempFile.delete();
            
        } catch (java.io.IOException e) {
            response.put("error", "Error de E/S: Python no está instalado o no está en el PATH del sistema");
        } catch (InterruptedException e) {
            response.put("error", "La ejecución fue interrumpida");
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            response.put("error", "Error inesperado: " + e.getMessage());
        }
        
        return response;
    }
}
