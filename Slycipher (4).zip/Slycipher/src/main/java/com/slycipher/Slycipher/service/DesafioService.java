package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Desafio;
import com.slycipher.Slycipher.repository.DesafioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DesafioService {
    private final DesafioRepository desafioRepository;

    public DesafioService(DesafioRepository desafioRepository) {
        this.desafioRepository = desafioRepository;
    }

    public List<Desafio> findAll() { return desafioRepository.findAll(); }
    public List<Desafio> findByCourseId(Long courseId) { return desafioRepository.findByCourseId(courseId); }
    public Optional<Desafio> findById(Long id) { return desafioRepository.findById(id); }
    public Desafio save(Desafio d) { return desafioRepository.save(d); }
    public Optional<Desafio> update(Long id, Desafio desafioDetails) {
        return desafioRepository.findById(id)
                .map(desafio -> {
                    desafio.setCourseId(desafioDetails.getCourseId());
                    desafio.setTitulo(desafioDetails.getTitulo());
                    desafio.setDescripcion(desafioDetails.getDescripcion());
                    desafio.setDificultad(desafioDetails.getDificultad());
                    desafio.setSolucion(desafioDetails.getSolucion());
                    desafio.setLanguageId(desafioDetails.getLanguageId());
                    return desafioRepository.save(desafio);
                });
    }
    public void deleteById(Long id) { desafioRepository.deleteById(id); }

    // Aliases para controladores web
    public Desafio createDesafio(Desafio desafio) {
        return save(desafio);
    }

    public Desafio getDesafioById(Long id) {
        return findById(id).orElse(null);
    }

    public List<Desafio> getAllDesafios() {
        return findAll();
    }

    public Desafio updateDesafio(Long id, Desafio desafio) {
        return update(id, desafio).orElse(null);
    }

    public void deleteDesafio(Long id) {
        deleteById(id);
    }
}
