package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.DesafioUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DesafioUsuarioRepository extends JpaRepository<DesafioUsuario, Long> {
    List<DesafioUsuario> findByUserId(Long userId);
    List<DesafioUsuario> findByChallengeId(Long challengeId);
}
