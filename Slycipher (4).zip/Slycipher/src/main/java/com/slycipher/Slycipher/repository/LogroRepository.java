package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Logro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LogroRepository extends JpaRepository<Logro, Long> {
}
