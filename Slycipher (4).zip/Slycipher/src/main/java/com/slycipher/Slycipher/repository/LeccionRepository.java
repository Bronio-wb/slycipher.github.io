package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Leccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LeccionRepository extends JpaRepository<Leccion, Long> {
    List<Leccion> findByCourseId(Long courseId);
    
    @Query("SELECT l FROM Leccion l LEFT JOIN FETCH l.curso WHERE l.lessonId = :id")
    Optional<Leccion> findByIdWithCurso(@Param("id") Long id);
    
    @Modifying
    @Query("DELETE FROM Leccion l WHERE l.courseId = :cursoId")
    void deleteByCursoId(@Param("cursoId") Long cursoId);
}
