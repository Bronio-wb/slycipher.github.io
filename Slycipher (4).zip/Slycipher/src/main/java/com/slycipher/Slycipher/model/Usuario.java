package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @Column(name = "user_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    private String username;
    private String nombre;
    private String apellido;
    private String email;

    @Column(name = "password_hash")
    private String passwordHash;

    @Column(name = "fecha_nacimiento")
    private LocalDateTime fechaNacimiento;

    private String rol;
    private Boolean activo;
    private Integer racha;

    @Column(name = "creado_en")
    private LocalDateTime creadoEn;

    @OneToMany(mappedBy = "creador", fetch = FetchType.LAZY)
    private List<Curso> cursosCreados = new ArrayList<>();

    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<DesafioUsuario> enviosDesafios = new ArrayList<>();

    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<ProgresoUsuario> progresos = new ArrayList<>();

    @OneToMany(mappedBy = "usuario", fetch = FetchType.LAZY)
    private List<LogroUsuario> logrosUsuarios = new ArrayList<>();

    // Getters / Setters
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getApellido() { return apellido; }
    public void setApellido(String apellido) { this.apellido = apellido; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public LocalDateTime getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDateTime fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
    public Boolean getActivo() { return activo; }
    public void setActivo(Boolean activo) { this.activo = activo; }
    public Integer getRacha() { return racha; }
    public void setRacha(Integer racha) { this.racha = racha; }
    public LocalDateTime getCreadoEn() { return creadoEn; }
    public void setCreadoEn(LocalDateTime creadoEn) { this.creadoEn = creadoEn; }
    public List<Curso> getCursosCreados() { return cursosCreados; }
    public void setCursosCreados(List<Curso> cursosCreados) { this.cursosCreados = cursosCreados; }
    public List<DesafioUsuario> getEnviosDesafios() { return enviosDesafios; }
    public void setEnviosDesafios(List<DesafioUsuario> enviosDesafios) { this.enviosDesafios = enviosDesafios; }
    public List<ProgresoUsuario> getProgresos() { return progresos; }
    public void setProgresos(List<ProgresoUsuario> progresos) { this.progresos = progresos; }
    public List<LogroUsuario> getLogrosUsuarios() { return logrosUsuarios; }
    public void setLogrosUsuarios(List<LogroUsuario> logrosUsuarios) { this.logrosUsuarios = logrosUsuarios; }
}
