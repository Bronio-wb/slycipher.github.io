package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface CursoRepository extends JpaRepository<Curso, Long> {
    
    @Query("SELECT c FROM Curso c LEFT JOIN FETCH c.categoria LEFT JOIN FETCH c.lenguaje LEFT JOIN FETCH c.creador")
    List<Curso> findAllWithDetails();
    
    @Query("SELECT c FROM Curso c LEFT JOIN FETCH c.categoria LEFT JOIN FETCH c.lenguaje LEFT JOIN FETCH c.creador WHERE c.estado = 'aprobada' AND c.visible = true")
    List<Curso> findApprovedAndVisible();
    
    @Query("SELECT DISTINCT c FROM Curso c " +
           "LEFT JOIN FETCH c.categoria " +
           "LEFT JOIN FETCH c.lenguaje " +
           "LEFT JOIN FETCH c.creador " +
           "WHERE c.courseId = :id")
    Optional<Curso> findByIdWithDetails(@Param("id") Long id);
    
    @Query("SELECT DISTINCT c FROM Curso c " +
           "LEFT JOIN FETCH c.lecciones " +
           "WHERE c.courseId = :id")
    Optional<Curso> findByIdWithLecciones(@Param("id") Long id);
    
    @Query("SELECT DISTINCT c FROM Curso c " +
           "LEFT JOIN FETCH c.desafios " +
           "WHERE c.courseId = :id")
    Optional<Curso> findByIdWithDesafios(@Param("id") Long id);
}
