-- Crear tabla de inscripciones a cursos
CREATE TABLE IF NOT EXISTS inscripciones_cursos (
    inscripcion_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT NOT NULL,
    curso_id BIGINT NOT NULL,
    fecha_inscripcion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado VARCHAR(20) DEFAULT 'activo',
    progreso INT DEFAULT 0,
    ultima_actividad DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(user_id) ON DELETE CASCADE,
    FOREIGN KEY (curso_id) REFERENCES cursos(course_id) ON DELETE CASCADE,
    UNIQUE KEY unique_inscripcion (usuario_id, curso_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Índices para mejorar el rendimiento
CREATE INDEX idx_usuario_inscripciones ON inscripciones_cursos(usuario_id);
CREATE INDEX idx_curso_inscripciones ON inscripciones_cursos(curso_id);
CREATE INDEX idx_estado_inscripciones ON inscripciones_cursos(estado);
