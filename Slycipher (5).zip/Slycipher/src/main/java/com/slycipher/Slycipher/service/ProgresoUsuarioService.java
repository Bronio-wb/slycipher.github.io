package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.ProgresoUsuario;
import com.slycipher.Slycipher.repository.ProgresoUsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class ProgresoUsuarioService {
    private final ProgresoUsuarioRepository progresoUsuarioRepository;

    public ProgresoUsuarioService(ProgresoUsuarioRepository progresoUsuarioRepository) {
        this.progresoUsuarioRepository = progresoUsuarioRepository;
    }

    public List<ProgresoUsuario> findAll() {
        return progresoUsuarioRepository.findAll();
    }

    public Optional<ProgresoUsuario> findById(Long id) {
        return progresoUsuarioRepository.findById(id);
    }

    public List<ProgresoUsuario> findByUsuarioId(Long usuarioId) {
        return progresoUsuarioRepository.findByUserId(usuarioId);
    }

    public List<ProgresoUsuario> findByLeccionId(Long leccionId) {
        return progresoUsuarioRepository.findByLessonId(leccionId);
    }

    public ProgresoUsuario save(ProgresoUsuario progresoUsuario) {
        return progresoUsuarioRepository.save(progresoUsuario);
    }

    public ProgresoUsuario update(Long id, ProgresoUsuario progresoDetails) {
        ProgresoUsuario progreso = progresoUsuarioRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Progreso no encontrado con id: " + id));
        
        progreso.setUserId(progresoDetails.getUserId());
        progreso.setLessonId(progresoDetails.getLessonId());
        progreso.setEstado(progresoDetails.getEstado());
        progreso.setPuntaje(progresoDetails.getPuntaje());
        progreso.setCompletadoEn(progresoDetails.getCompletadoEn());
        return progresoUsuarioRepository.save(progreso);
    }

    public void deleteById(Long id) {
        if (!progresoUsuarioRepository.existsById(id)) {
            throw new RuntimeException("Progreso no encontrado con id: " + id);
        }
        progresoUsuarioRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return progresoUsuarioRepository.existsById(id);
    }

    // Aliases para controladores web
    public List<ProgresoUsuario> getAllProgresosUsuario() {
        return findAll();
    }

    public ProgresoUsuario createProgresoUsuario(ProgresoUsuario progreso) {
        return save(progreso);
    }

    public ProgresoUsuario updateProgresoUsuario(Long id, ProgresoUsuario progreso) {
        return update(id, progreso);
    }
    
    public ProgresoUsuario marcarLeccionCompletada(Long userId, Long lessonId) {
        // Verificar si ya está completada
        Optional<ProgresoUsuario> existe = progresoUsuarioRepository
            .findByUserIdAndLessonId(userId, lessonId);
        
        if (existe.isPresent()) {
            return existe.get();
        }
        
        // Crear nuevo registro
        ProgresoUsuario progreso = new ProgresoUsuario();
        progreso.setUserId(userId);
        progreso.setLessonId(lessonId);
        progreso.setEstado("completado");
        progreso.setCompletadoEn(LocalDateTime.now());
        progreso.setPuntaje(100);
        
        return progresoUsuarioRepository.save(progreso);
    }
    
    public boolean isLeccionCompletada(Long userId, Long lessonId) {
        Optional<ProgresoUsuario> progreso = progresoUsuarioRepository
            .findByUserIdAndLessonId(userId, lessonId);
        return progreso.isPresent() && "completado".equals(progreso.get().getEstado());
    }
    
}

