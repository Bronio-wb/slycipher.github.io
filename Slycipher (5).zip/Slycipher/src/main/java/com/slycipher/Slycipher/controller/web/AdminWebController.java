package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Lenguaje;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.CursoService;
import com.slycipher.Slycipher.service.CategoriaService;
import com.slycipher.Slycipher.service.ReporteService;
import com.slycipher.Slycipher.repository.LenguajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class AdminWebController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private CategoriaService categoriaService;
    
    @Autowired
    private LenguajeRepository lenguajeRepository;
    
    @Autowired
    private ReporteService reporteService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private com.slycipher.Slycipher.service.LeccionService leccionService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        List<Usuario> todosUsuarios = usuarioService.getAllUsuarios();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("totalUsuarios", todosUsuarios.size());
        model.addAttribute("totalCursos", cursoService.getAllCursos().size());
        model.addAttribute("usuariosActivos", todosUsuarios.stream().filter(u -> u.getActivo() != null && u.getActivo()).count());
        model.addAttribute("cursosActivos", cursoService.getAllCursos().size());
        
        // Conteo por roles para la gráfica
        model.addAttribute("countAdmin", todosUsuarios.stream().filter(u -> "ADMIN".equals(u.getRol())).count());
        model.addAttribute("countDeveloper", todosUsuarios.stream().filter(u -> "DEVELOPER".equals(u.getRol())).count());
        model.addAttribute("countStudent", todosUsuarios.stream().filter(u -> "STUDENT".equals(u.getRol())).count());
        
        // Usuarios recientes (últimos 5) - filtrar nulls y ordenar
        model.addAttribute("usuariosRecientes", todosUsuarios.stream()
            .filter(u -> u.getCreadoEn() != null)
            .sorted((u1, u2) -> u2.getCreadoEn().compareTo(u1.getCreadoEn()))
            .limit(5)
            .collect(Collectors.toList()));
        
        return "admin/dashboard";
    }

    @GetMapping("/usuarios")
    public String usuarios(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuarios", usuarioService.getAllUsuarios());
        return "admin/usuarios";
    }

    @GetMapping("/estadisticas")
    public String estadisticas(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        
        // Obtener todos los cursos y lenguajes
        List<Curso> todosCursos = cursoService.getAllCursos();
        List<Lenguaje> todosLenguajes = lenguajeRepository.findAll();
        List<Usuario> todosUsuarios = usuarioService.getAllUsuarios();
        
        // Contar cursos por lenguaje
        Map<String, Long> cursosPorLenguaje = todosCursos.stream()
            .filter(c -> c.getLanguageId() != null)
            .collect(Collectors.groupingBy(
                c -> {
                    Optional<Lenguaje> lenguaje = todosLenguajes.stream()
                        .filter(l -> l.getLanguageId().equals(c.getLanguageId()))
                        .findFirst();
                    return lenguaje.map(Lenguaje::getNombre).orElse("Sin lenguaje");
                },
                Collectors.counting()
            ));
        
        // Contar usuarios registrados por mes
        Map<String, Long> usuariosPorMes = todosUsuarios.stream()
            .filter(u -> u.getCreadoEn() != null)
            .collect(Collectors.groupingBy(
                u -> {
                    LocalDateTime fecha = u.getCreadoEn();
                    String[] meses = {"", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
                                     "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};
                    return meses[fecha.getMonthValue()] + " " + fecha.getYear();
                },
                Collectors.counting()
            ));
        
        // Pasar datos al modelo
        model.addAttribute("totalCategorias", 0); // No tenemos categorías aún
        model.addAttribute("totalLenguajes", todosLenguajes.size());
        model.addAttribute("registrosDelMes", todosUsuarios.stream()
            .filter(u -> u.getCreadoEn() != null && 
                   u.getCreadoEn().getMonth() == LocalDateTime.now().getMonth())
            .count());
        model.addAttribute("totalCursos", todosCursos.size());
        model.addAttribute("cursosPorLenguaje", cursosPorLenguaje);
        model.addAttribute("usuariosPorMes", usuariosPorMes);
        
        return "admin/estadisticas";
    }

    @GetMapping("/reportes")
    public String reportes(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        return "admin/reportes";
    }
    
    @GetMapping("/reportes/descargar")
    public ResponseEntity<byte[]> descargarReporte(
            @RequestParam("tipoReporte") String tipoReporte,
            @RequestParam("formato") String formato,
            @RequestParam(value = "rol", required = false) String rol,
            @RequestParam(value = "activo", required = false) String activo,
            @RequestParam(value = "fechaDesde", required = false) String fechaDesde,
            @RequestParam(value = "fechaHasta", required = false) String fechaHasta,
            @RequestParam(value = "nivel", required = false) String nivel,
            @RequestParam(value = "lenguajeId", required = false) Long lenguajeId) {
        
        try {
            byte[] reporteBytes;
            String filename;
            String contentType;
            
            if ("usuarios".equals(tipoReporte)) {
                List<Usuario> usuarios = usuarioService.getAllUsuarios().stream()
                    .filter(u -> rol == null || rol.isEmpty() || rol.equals(u.getRol()))
                    .filter(u -> activo == null || activo.isEmpty() || 
                            (activo.equals("true") && u.getActivo() != null && u.getActivo()) ||
                            (activo.equals("false") && (u.getActivo() == null || !u.getActivo())))
                    .filter(u -> {
                        if (fechaDesde == null || fechaDesde.isEmpty() || u.getCreadoEn() == null) return true;
                        LocalDateTime desde = LocalDateTime.parse(fechaDesde + "T00:00:00");
                        return u.getCreadoEn().isAfter(desde) || u.getCreadoEn().isEqual(desde);
                    })
                    .filter(u -> {
                        if (fechaHasta == null || fechaHasta.isEmpty() || u.getCreadoEn() == null) return true;
                        LocalDateTime hasta = LocalDateTime.parse(fechaHasta + "T23:59:59");
                        return u.getCreadoEn().isBefore(hasta) || u.getCreadoEn().isEqual(hasta);
                    })
                    .collect(Collectors.toList());
                
                if ("pdf".equals(formato)) {
                    reporteBytes = reporteService.generarReporteUsuariosPDF(usuarios, fechaDesde, fechaHasta);
                    filename = "reporte_usuarios_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
                    contentType = "application/pdf";
                } else {
                    reporteBytes = reporteService.generarReporteUsuariosExcel(usuarios);
                    filename = "reporte_usuarios_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xlsx";
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
                
            } else if ("cursos".equals(tipoReporte)) {
                List<Curso> cursos = cursoService.getAllCursos().stream()
                    .filter(c -> nivel == null || nivel.isEmpty() || nivel.equals(c.getNivel()))
                    .filter(c -> lenguajeId == null || lenguajeId.equals(c.getLanguageId()))
                    .filter(c -> {
                        if (fechaDesde == null || fechaDesde.isEmpty() || c.getFechaCreacion() == null) return true;
                        LocalDateTime desde = LocalDateTime.parse(fechaDesde + "T00:00:00");
                        return c.getFechaCreacion().isAfter(desde) || c.getFechaCreacion().isEqual(desde);
                    })
                    .filter(c -> {
                        if (fechaHasta == null || fechaHasta.isEmpty() || c.getFechaCreacion() == null) return true;
                        LocalDateTime hasta = LocalDateTime.parse(fechaHasta + "T23:59:59");
                        return c.getFechaCreacion().isBefore(hasta) || c.getFechaCreacion().isEqual(hasta);
                    })
                    .collect(Collectors.toList());
                
                if ("pdf".equals(formato)) {
                    reporteBytes = reporteService.generarReporteCursosPDF(cursos);
                    filename = "reporte_cursos_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
                    contentType = "application/pdf";
                } else {
                    reporteBytes = reporteService.generarReporteCursosExcel(cursos);
                    filename = "reporte_cursos_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xlsx";
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
            } else if ("progreso".equals(tipoReporte)) {
                // Reporte de Progreso - Combina datos de usuarios y cursos
                List<Usuario> usuarios = usuarioService.getAllUsuarios();
                List<Curso> cursos = cursoService.getAllCursos();
                
                if ("pdf".equals(formato)) {
                    reporteBytes = reporteService.generarReporteProgresoPDF(usuarios, cursos, fechaDesde, fechaHasta);
                    filename = "reporte_progreso_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
                    contentType = "application/pdf";
                } else {
                    reporteBytes = reporteService.generarReporteProgresoExcel(usuarios, cursos);
                    filename = "reporte_progreso_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xlsx";
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
            } else if ("general".equals(tipoReporte)) {
                // Reporte General - Resumen ejecutivo de toda la plataforma
                List<Usuario> usuarios = usuarioService.getAllUsuarios();
                List<Curso> cursos = cursoService.getAllCursos();
                
                if ("pdf".equals(formato)) {
                    reporteBytes = reporteService.generarReporteGeneralPDF(usuarios, cursos, fechaDesde, fechaHasta);
                    filename = "reporte_general_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".pdf";
                    contentType = "application/pdf";
                } else {
                    reporteBytes = reporteService.generarReporteGeneralExcel(usuarios, cursos);
                    filename = "reporte_general_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".xlsx";
                    contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                }
            } else {
                return ResponseEntity.badRequest().build();
            }
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.parseMediaType(contentType));
            headers.setContentDispositionFormData("attachment", filename);
            
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(reporteBytes);
                    
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.internalServerError().build();
        }
    }
    
    @GetMapping("/usuarios/crear")
    public String crearUsuarioForm(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuario", new Usuario());
        return "admin/crear-usuario";
    }

    @PostMapping("/usuarios/crear")
    public String crearUsuario(@ModelAttribute Usuario usuario, RedirectAttributes redirectAttributes) {
        try {
            // Verificar si el usuario ya existe
            if (usuarioService.getUserByUsername(usuario.getUsername()) != null) {
                redirectAttributes.addFlashAttribute("error", "El username ya existe");
                return "redirect:/admin/usuarios/crear";
            }
            
            // Encriptar password
            usuario.setPasswordHash(passwordEncoder.encode(usuario.getPasswordHash()));
            usuario.setCreadoEn(LocalDateTime.now());
            usuario.setActivo(true);
            
            usuarioService.createUsuario(usuario);
            redirectAttributes.addFlashAttribute("success", "Usuario creado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/crear";
        }
    }

    @GetMapping("/usuarios/{id}/editar")
    public String editarUsuarioForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario usuario = usuarioService.getUsuarioById(id);
        if (usuario == null) {
            return "redirect:/admin/usuarios";
        }
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuario", usuario);
        return "admin/editar-usuario";
    }

    @PostMapping("/usuarios/{id}/editar")
    public String editarUsuario(@PathVariable Long id, @ModelAttribute Usuario usuario, 
                                @RequestParam(required = false) String newPassword,
                                RedirectAttributes redirectAttributes) {
        try {
            Usuario existente = usuarioService.getUsuarioById(id);
            if (existente == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // Actualizar campos
            existente.setNombre(usuario.getNombre());
            existente.setApellido(usuario.getApellido());
            existente.setEmail(usuario.getEmail());
            existente.setRol(usuario.getRol());
            existente.setFechaNacimiento(usuario.getFechaNacimiento());
            existente.setRacha(usuario.getRacha());
            
            // Cambiar password solo si se proporcionó uno nuevo
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                existente.setPasswordHash(passwordEncoder.encode(newPassword));
            }
            
            usuarioService.updateUsuario(id, existente);
            redirectAttributes.addFlashAttribute("success", "Usuario actualizado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/" + id + "/editar";
        }
    }

    @PostMapping("/usuarios/{id}/toggle")
    public String toggleUsuario(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            if (usuario == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // Toggle activo
            usuario.setActivo(usuario.getActivo() == null || !usuario.getActivo());
            usuarioService.updateUsuario(id, usuario);
            
            redirectAttributes.addFlashAttribute("success", 
                "Usuario " + (usuario.getActivo() ? "activado" : "desactivado") + " exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar estado: " + e.getMessage());
            return "redirect:/admin/usuarios";
        }
    }

    @PostMapping("/usuarios/{id}/eliminar")
    public String eliminarUsuario(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            if (usuario == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // No permitir eliminar el usuario actual
            if (usuario.getUsername().equals(authentication.getName())) {
                redirectAttributes.addFlashAttribute("error", "No puedes eliminar tu propio usuario");
                return "redirect:/admin/usuarios";
            }
            
            usuarioService.deleteUsuario(id);
            redirectAttributes.addFlashAttribute("success", "Usuario eliminado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios";
        }
    }

    @GetMapping("/cursos")
    public String cursos(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        List<Curso> todosCursos = cursoService.getAllCursos();
        
        // Contar por estados
        long pendientes = todosCursos.stream().filter(c -> "pendiente".equals(c.getEstado())).count();
        long aprobados = todosCursos.stream().filter(c -> "aprobada".equals(c.getEstado())).count();
        long rechazados = todosCursos.stream().filter(c -> "rechazada".equals(c.getEstado())).count();
        
        model.addAttribute("cursos", todosCursos);
        model.addAttribute("totalCursos", todosCursos.size());
        model.addAttribute("cursosPendientes", pendientes);
        model.addAttribute("cursosAprobados", aprobados);
        model.addAttribute("cursosRechazados", rechazados);
        model.addAttribute("categorias", categoriaService.findAll());
        return "admin/cursos";
    }

    @GetMapping("/cursos/crear")
    public String crearCursoForm(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("curso", new com.slycipher.Slycipher.model.Curso());
        return "admin/crear-curso";
    }

    @PostMapping("/cursos/crear")
    public String crearCurso(@ModelAttribute com.slycipher.Slycipher.model.Curso curso, 
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {
        try {
            // Obtener el usuario actual
            Usuario usuario = usuarioService.getUserByUsername(authentication.getName());
            curso.setCreadoPor(usuario.getUserId());
            curso.setFechaCreacion(LocalDateTime.now());
            curso.setEstado("pendiente");
            curso.setVisible(false);
            
            cursoService.createCurso(curso);
            redirectAttributes.addFlashAttribute("success", "Curso creado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear curso: " + e.getMessage());
            return "redirect:/admin/cursos/crear";
        }
    }

    @GetMapping("/cursos/{id}")
    public String verCurso(@PathVariable Long id, Model model, Authentication authentication) {
        com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/admin/cursos";
        }
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("curso", curso);
        
        // Obtener lecciones del curso
        List<com.slycipher.Slycipher.model.Leccion> lecciones = leccionService.findByCursoId(id);
        model.addAttribute("lecciones", lecciones);
        model.addAttribute("totalLecciones", lecciones.size());
        
        return "admin/ver-curso";
    }

    @GetMapping("/cursos/{id}/editar")
    public String editarCursoForm(@PathVariable Long id, Model model, Authentication authentication) {
        com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/admin/cursos";
        }
        model.addAttribute("username", authentication.getName());
        model.addAttribute("curso", curso);
        return "admin/editar-curso";
    }

    @PostMapping("/cursos/{id}/editar")
    public String editarCurso(@PathVariable Long id, 
                             @ModelAttribute com.slycipher.Slycipher.model.Curso curso,
                             RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Curso existente = cursoService.getCursoById(id);
            if (existente == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            existente.setTitulo(curso.getTitulo());
            existente.setDescripcion(curso.getDescripcion());
            existente.setNivel(curso.getNivel());
            existente.setEstado(curso.getEstado());
            existente.setPrecio(curso.getPrecio());
            existente.setDuracionEstimada(curso.getDuracionEstimada());
            existente.setRequisitos(curso.getRequisitos());
            
            cursoService.updateCurso(id, existente);
            redirectAttributes.addFlashAttribute("success", "Curso actualizado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar curso: " + e.getMessage());
            return "redirect:/admin/cursos/" + id + "/editar";
        }
    }

    @PostMapping("/cursos/{id}/eliminar")
    public String eliminarCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            cursoService.deleteCurso(id);
            redirectAttributes.addFlashAttribute("success", "Curso eliminado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar curso: " + e.getMessage());
            return "redirect:/admin/cursos";
        }
    }

    @PostMapping("/cursos/{id}/toggle-estado")
    public String toggleEstadoCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            curso.setVisible(!curso.getVisible());
            cursoService.save(curso);
            
            String mensaje = curso.getVisible() ? "Curso activado (visible)" : "Curso desactivado (oculto)";
            redirectAttributes.addFlashAttribute("success", mensaje);
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar visibilidad del curso: " + e.getMessage());
            return "redirect:/admin/cursos";
        }
    }
    
    @PostMapping("/cursos/{id}/aprobar")
    public String aprobarCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            curso.setEstado("aprobada");
            cursoService.save(curso);
            
            redirectAttributes.addFlashAttribute("success", "Curso aprobado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al aprobar curso: " + e.getMessage());
            return "redirect:/admin/cursos";
        }
    }
    
    @PostMapping("/cursos/{id}/rechazar")
    public String rechazarCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            curso.setEstado("rechazada");
            cursoService.save(curso);
            
            redirectAttributes.addFlashAttribute("success", "Curso rechazado");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al rechazar curso: " + e.getMessage());
            return "redirect:/admin/cursos";
        }
    }
    
    // ============ GESTIÓN DE LECCIONES ============
    
    @GetMapping("/lecciones/{id}")
    public String verLeccion(@PathVariable Long id, Model model, Authentication authentication) {
        com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
        if (leccion == null) {
            return "redirect:/admin/lecciones";
        }
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("leccion", leccion);
        
        // Obtener el curso asociado
        Curso curso = cursoService.getCursoById(leccion.getCourseId());
        model.addAttribute("curso", curso);
        
        return "admin/ver-leccion";
    }
    
    @GetMapping("/lecciones")
    public String lecciones(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        
        // Obtener todas las lecciones
        List<com.slycipher.Slycipher.model.Leccion> todasLecciones = leccionService.findAll();
        
        // Cargar información de los cursos
        Map<Long, Curso> cursosMap = new HashMap<>();
        for (com.slycipher.Slycipher.model.Leccion leccion : todasLecciones) {
            if (!cursosMap.containsKey(leccion.getCourseId())) {
                Curso curso = cursoService.getCursoById(leccion.getCourseId());
                if (curso != null) {
                    cursosMap.put(leccion.getCourseId(), curso);
                }
            }
        }
        
        // Contar por estados
        long pendientes = todasLecciones.stream().filter(l -> "pendiente".equals(l.getEstado())).count();
        long aprobadas = todasLecciones.stream().filter(l -> "aprobada".equals(l.getEstado())).count();
        long rechazadas = todasLecciones.stream().filter(l -> "rechazada".equals(l.getEstado())).count();
        
        model.addAttribute("lecciones", todasLecciones);
        model.addAttribute("cursosMap", cursosMap);
        model.addAttribute("totalLecciones", todasLecciones.size());
        model.addAttribute("leccionesPendientes", pendientes);
        model.addAttribute("leccionesAprobadas", aprobadas);
        model.addAttribute("leccionesRechazadas", rechazadas);
        
        return "admin/lecciones";
    }
    
    @PostMapping("/lecciones/{id}/aprobar")
    public String aprobarLeccion(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/admin/lecciones";
            }
            
            leccion.setEstado("aprobada");
            leccionService.save(leccion);
            
            redirectAttributes.addFlashAttribute("success", "Lección aprobada exitosamente");
            return "redirect:/admin/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al aprobar lección: " + e.getMessage());
            return "redirect:/admin/lecciones";
        }
    }
    
    @PostMapping("/lecciones/{id}/rechazar")
    public String rechazarLeccion(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/admin/lecciones";
            }
            
            leccion.setEstado("rechazada");
            leccionService.save(leccion);
            
            redirectAttributes.addFlashAttribute("success", "Lección rechazada");
            return "redirect:/admin/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al rechazar lección: " + e.getMessage());
            return "redirect:/admin/lecciones";
        }
    }
    
    @PostMapping("/lecciones/{id}/toggle-visible")
    public String toggleVisibleLeccion(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/admin/lecciones";
            }
            
            leccion.setVisible(!leccion.getVisible());
            leccionService.save(leccion);
            
            String mensaje = leccion.getVisible() ? "Lección activada (visible)" : "Lección desactivada (oculta)";
            redirectAttributes.addFlashAttribute("success", mensaje);
            return "redirect:/admin/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar visibilidad: " + e.getMessage());
            return "redirect:/admin/lecciones";
        }
    }
    
    @PostMapping("/lecciones/{id}/eliminar")
    public String eliminarLeccion(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Leccion leccion = leccionService.findById(id).orElse(null);
            if (leccion == null) {
                redirectAttributes.addFlashAttribute("error", "Lección no encontrada");
                return "redirect:/admin/lecciones";
            }
            
            Long cursoId = leccion.getCourseId();
            leccionService.deleteById(id);
            redirectAttributes.addFlashAttribute("success", "Lección eliminada exitosamente");
            
            // Si vino desde la vista del curso, redirigir allí
            if (cursoId != null) {
                return "redirect:/admin/cursos/" + cursoId;
            }
            return "redirect:/admin/lecciones";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar lección: " + e.getMessage());
            return "redirect:/admin/lecciones";
        }
    }
}
