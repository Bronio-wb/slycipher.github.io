package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Lenguaje;
import com.slycipher.Slycipher.service.LenguajeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lenguajes")
@CrossOrigin(origins = "*")
public class LenguajeController {
    private final LenguajeService lenguajeService;

    public LenguajeController(LenguajeService lenguajeService) {
        this.lenguajeService = lenguajeService;
    }

    @GetMapping
    public ResponseEntity<List<Lenguaje>> getAllLenguajes() {
        return ResponseEntity.ok(lenguajeService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lenguaje> getLenguajeById(@PathVariable Long id) {
        return lenguajeService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Lenguaje> createLenguaje(@RequestBody Lenguaje lenguaje) {
        Lenguaje savedLenguaje = lenguajeService.save(lenguaje);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedLenguaje);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Lenguaje> updateLenguaje(@PathVariable Long id, @RequestBody Lenguaje lenguaje) {
        try {
            Lenguaje updatedLenguaje = lenguajeService.update(id, lenguaje);
            return ResponseEntity.ok(updatedLenguaje);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLenguaje(@PathVariable Long id) {
        try {
            lenguajeService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
