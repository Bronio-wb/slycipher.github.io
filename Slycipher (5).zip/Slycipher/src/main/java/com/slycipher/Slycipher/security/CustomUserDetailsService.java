package com.slycipher.Slycipher.security;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.repository.UsuarioRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    private final UsuarioRepository usuarioRepository;

    public CustomUserDetailsService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseGet(() -> {
                    Usuario u = usuarioRepository.findByUsername(username);
                    if (u == null) throw new UsernameNotFoundException("Usuario no encontrado: " + username);
                    return u;
                });

        if (usuario.getActivo() != null && !usuario.getActivo()) {
            throw new UsernameNotFoundException("Usuario deshabilitado: " + username);
        }

        String rol = usuario.getRol() != null ? usuario.getRol() : "USER";

        return User.builder()
                .username(usuario.getUsername())
                .password(usuario.getPasswordHash())
                .authorities(Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + rol)))
                .build();
    }
}