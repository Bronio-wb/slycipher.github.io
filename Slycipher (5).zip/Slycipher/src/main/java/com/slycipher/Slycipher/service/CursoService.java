package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.repository.CursoRepository;
import com.slycipher.Slycipher.repository.LeccionRepository;
import com.slycipher.Slycipher.repository.DesafioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public class CursoService {
    private final CursoRepository cursoRepository;
    private final LeccionRepository leccionRepository;
    private final DesafioRepository desafioRepository;

    public CursoService(CursoRepository cursoRepository, LeccionRepository leccionRepository, DesafioRepository desafioRepository) {
        this.cursoRepository = cursoRepository;
        this.leccionRepository = leccionRepository;
        this.desafioRepository = desafioRepository;
    }

    public List<Curso> findAll() {
        return cursoRepository.findAll();
    }

    public Optional<Curso> findById(Long id) {
        return cursoRepository.findById(id);
    }
    
    @Transactional(readOnly = true)
    public Optional<Curso> findByIdWithDetails(Long id) {
        return cursoRepository.findByIdWithDetails(id);
    }

    public Curso save(Curso curso) {
        return cursoRepository.save(curso);
    }

    public void deleteById(Long id) {
        cursoRepository.deleteById(id);
    }

    // Aliases para controladores web
    @Transactional(readOnly = true)
    public Curso getCursoById(Long id) {
        Optional<Curso> cursoOpt = cursoRepository.findByIdWithDetails(id);
        if (cursoOpt.isPresent()) {
            Curso curso = cursoOpt.get();
            // Inicializar las colecciones lazy dentro de la transacción
            curso.getLecciones().size();
            curso.getDesafios().size();
            return curso;
        }
        return null;
    }

    public List<Curso> getAllCursos() {
        return cursoRepository.findAllWithDetails();
    }

    public Curso createCurso(Curso curso) {
        return save(curso);
    }

    public Curso updateCurso(Long id, Curso curso) {
        return cursoRepository.findById(id)
            .map(existing -> {
                existing.setTitulo(curso.getTitulo());
                existing.setDescripcion(curso.getDescripcion());
                existing.setNivel(curso.getNivel());
                existing.setLanguageId(curso.getLanguageId());
                existing.setCategoryId(curso.getCategoryId());
                existing.setVisible(curso.getVisible());
                existing.setEstado(curso.getEstado());
                return save(existing);
            }).orElse(null);
    }

    @Transactional
    public void deleteCurso(Long id) {
        // Primero eliminar todas las lecciones asociadas al curso
        leccionRepository.deleteByCursoId(id);
        // Luego eliminar todos los desafíos asociados al curso
        desafioRepository.deleteByCursoId(id);
        // Finalmente eliminar el curso
        deleteById(id);
    }
    
    public List<Curso> getApprovedAndVisibleCursos() {
        return cursoRepository.findApprovedAndVisible();
    }
}
