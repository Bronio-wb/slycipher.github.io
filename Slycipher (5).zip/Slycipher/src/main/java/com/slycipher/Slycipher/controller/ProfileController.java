package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.dto.ChangePasswordRequest;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.util.PasswordValidator;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/profile")
public class ProfileController {
    
    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;

    public ProfileController(UsuarioService usuarioService, PasswordEncoder passwordEncoder) {
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String showProfile(Authentication authentication, Model model) {
        String username = authentication.getName();
        Usuario usuario = usuarioService.getUserByUsername(username);
        
        if (usuario == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("usuario", usuario);
        model.addAttribute("username", username);
        model.addAttribute("rol", usuario.getRol());
        model.addAttribute("changePasswordRequest", new ChangePasswordRequest());
        return "profile";
    }

    @PostMapping("/change-password")
    public String changePassword(@ModelAttribute ChangePasswordRequest request, 
                                Authentication authentication, 
                                RedirectAttributes redirectAttributes,
                                Model model) {
        try {
            String username = authentication.getName();
            Usuario usuario = usuarioService.getUserByUsername(username);
            
            if (usuario == null) {
                return "redirect:/login";
            }
            
            // Validar que los campos no estén vacíos
            if (request.getCurrentPassword() == null || request.getCurrentPassword().trim().isEmpty()) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "La contraseña actual es requerida");
                return "profile";
            }
            
            if (request.getNewPassword() == null || request.getNewPassword().trim().isEmpty()) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "La nueva contraseña es requerida");
                return "profile";
            }
            
            if (request.getConfirmPassword() == null || request.getConfirmPassword().trim().isEmpty()) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "La confirmación de contraseña es requerida");
                return "profile";
            }
            
            // Verificar que la contraseña actual sea correcta
            if (!passwordEncoder.matches(request.getCurrentPassword(), usuario.getPasswordHash())) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "La contraseña actual es incorrecta");
                return "profile";
            }
            
            // Verificar que las contraseñas nuevas coincidan
            if (!request.getNewPassword().equals(request.getConfirmPassword())) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "Las contraseñas nuevas no coinciden");
                return "profile";
            }
            
            // Validar que la nueva contraseña cumpla los requisitos
            List<String> passwordErrors = PasswordValidator.validate(request.getNewPassword());
            if (!passwordErrors.isEmpty()) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("errors", passwordErrors);
                return "profile";
            }
            
            // Verificar que la nueva contraseña sea diferente a la actual
            if (passwordEncoder.matches(request.getNewPassword(), usuario.getPasswordHash())) {
                model.addAttribute("usuario", usuario);
                model.addAttribute("changePasswordRequest", request);
                model.addAttribute("error", "La nueva contraseña debe ser diferente a la actual");
                return "profile";
            }
            
            // Actualizar la contraseña
            usuario.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
            usuarioService.save(usuario);
            
            redirectAttributes.addFlashAttribute("success", "Contraseña actualizada exitosamente");
            return "redirect:/profile";
            
        } catch (Exception e) {
            model.addAttribute("error", "Error al cambiar la contraseña: " + e.getMessage());
            return "profile";
        }
    }
}
