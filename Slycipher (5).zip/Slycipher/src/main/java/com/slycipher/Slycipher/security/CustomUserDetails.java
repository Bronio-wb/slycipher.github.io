package com.slycipher.Slycipher.security;

import com.slycipher.Slycipher.model.Usuario;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;

public class CustomUserDetails implements UserDetails {
    private final Usuario usuario;

    public CustomUserDetails(Usuario usuario) { this.usuario = usuario; }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        String role = usuario.getRol() != null ? usuario.getRol() : "estudiante";
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()));
    }

    @Override
    public String getPassword() { return usuario.getPasswordHash(); }

    @Override
    public String getUsername() { return usuario.getUsername(); }

    @Override
    public boolean isAccountNonExpired() { return true; }

    @Override
    public boolean isAccountNonLocked() { return true; }

    @Override
    public boolean isCredentialsNonExpired() { return true; }

    @Override
    public boolean isEnabled() { return usuario.getActivo() == null ? true : usuario.getActivo(); }
}
