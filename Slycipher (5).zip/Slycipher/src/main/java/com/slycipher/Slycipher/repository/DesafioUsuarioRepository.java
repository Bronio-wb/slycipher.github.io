package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.DesafioUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DesafioUsuarioRepository extends JpaRepository<DesafioUsuario, Long> {
    List<DesafioUsuario> findByUserId(Long userId);
    List<DesafioUsuario> findByChallengeId(Long challengeId);
    
    // Verificar si un usuario completó un desafío (estado = 'aprobado')
    boolean existsByUserIdAndChallengeIdAndEstado(Long userId, Long challengeId, String estado);
    
    // Contar desafíos completados por usuario
    long countByUserIdAndEstado(Long userId, String estado);
    
    // Contar total de desafíos por estado (para dashboard de desarrollador)
    long countByEstado(String estado);
    
    // Buscar desafíos por estado ordenados por fecha de envío
    List<DesafioUsuario> findByEstadoOrderByEnviadoEnDesc(String estado);
}
