package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import jakarta.persistence.FetchType;

@Entity
@Table(name = "logros_usuarios")
public class LogroUsuario {
    @Id
    @Column(name = "user_achievement_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userAchievementId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "achievement_id")
    private Long achievementId;

    @Column(name = "desbloqueado_en")
    private LocalDateTime desbloqueadoEn;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", insertable = false, updatable = false)
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "achievement_id", insertable = false, updatable = false)
    private Logro logro;

    // getters/setters
    public Long getUserAchievementId() { return userAchievementId; }
    public void setUserAchievementId(Long userAchievementId) { this.userAchievementId = userAchievementId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getAchievementId() { return achievementId; }
    public void setAchievementId(Long achievementId) { this.achievementId = achievementId; }
    public LocalDateTime getDesbloqueadoEn() { return desbloqueadoEn; }
    public void setDesbloqueadoEn(LocalDateTime desbloqueadoEn) { this.desbloqueadoEn = desbloqueadoEn; }
    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }
    public Logro getLogro() { return logro; }
    public void setLogro(Logro logro) { this.logro = logro; }
}
