package com.slycipher.Slycipher.util;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class PasswordValidator {
    
    private static final int MIN_LENGTH = 8;
    private static final int MAX_LENGTH = 20;
    private static final Pattern MAYUSCULA_PATTERN = Pattern.compile("[A-Z]");
    private static final Pattern MINUSCULA_PATTERN = Pattern.compile("[a-z]");
    private static final Pattern NUMERO_PATTERN = Pattern.compile("[0-9]");
    private static final Pattern SIMBOLO_PATTERN = Pattern.compile("[^A-Za-z0-9]");
    
    /**
     * Valida que la contraseña cumpla con todos los requisitos
     * @param password La contraseña a validar
     * @return Lista de errores (vacía si la contraseña es válida)
     */
    public static List<String> validate(String password) {
        List<String> errors = new ArrayList<>();
        
        if (password == null || password.isEmpty()) {
            errors.add("La contraseña es requerida");
            return errors;
        }
        
        // Validar longitud
        if (password.length() < MIN_LENGTH || password.length() > MAX_LENGTH) {
            errors.add("La contraseña debe tener entre 8 y 20 caracteres");
        }
        
        // Validar mayúscula
        if (!MAYUSCULA_PATTERN.matcher(password).find()) {
            errors.add("La contraseña debe contener al menos una letra mayúscula");
        }
        
        // Validar minúscula
        if (!MINUSCULA_PATTERN.matcher(password).find()) {
            errors.add("La contraseña debe contener al menos una letra minúscula");
        }
        
        // Validar número
        if (!NUMERO_PATTERN.matcher(password).find()) {
            errors.add("La contraseña debe contener al menos un número");
        }
        
        // Validar símbolo
        if (!SIMBOLO_PATTERN.matcher(password).find()) {
            errors.add("La contraseña debe contener al menos un símbolo");
        }
        
        return errors;
    }
    
    /**
     * Verifica si la contraseña es válida
     * @param password La contraseña a validar
     * @return true si es válida, false en caso contrario
     */
    public static boolean isValid(String password) {
        return validate(password).isEmpty();
    }
}
