package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.LogroUsuario;
import com.slycipher.Slycipher.repository.LogroUsuarioRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LogroUsuarioService {
    private final LogroUsuarioRepository logroUsuarioRepository;

    public LogroUsuarioService(LogroUsuarioRepository logroUsuarioRepository) {
        this.logroUsuarioRepository = logroUsuarioRepository;
    }

    public List<LogroUsuario> findAll() {
        return logroUsuarioRepository.findAll();
    }

    public Optional<LogroUsuario> findById(Long id) {
        return logroUsuarioRepository.findById(id);
    }

    public List<LogroUsuario> findByUsuarioId(Long usuarioId) {
        return logroUsuarioRepository.findByUserId(usuarioId);
    }

    public LogroUsuario save(LogroUsuario logroUsuario) {
        if (logroUsuario.getDesbloqueadoEn() == null) {
            logroUsuario.setDesbloqueadoEn(LocalDateTime.now());
        }
        return logroUsuarioRepository.save(logroUsuario);
    }

    public void deleteById(Long id) {
        if (!logroUsuarioRepository.existsById(id)) {
            throw new RuntimeException("Logro de usuario no encontrado con id: " + id);
        }
        logroUsuarioRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return logroUsuarioRepository.existsById(id);
    }
}
