package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Desafio;
import com.slycipher.Slycipher.service.DesafioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/desafios")
@CrossOrigin(origins = "*")
public class DesafioController {
    private final DesafioService desafioService;

    public DesafioController(DesafioService desafioService) {
        this.desafioService = desafioService;
    }

    @GetMapping
    public ResponseEntity<List<Desafio>> getAllDesafios() {
        return ResponseEntity.ok(desafioService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Desafio> getDesafioById(@PathVariable Long id) {
        return desafioService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Desafio> createDesafio(@RequestBody Desafio desafio) {
        Desafio savedDesafio = desafioService.save(desafio);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedDesafio);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Desafio> updateDesafio(@PathVariable Long id, @RequestBody Desafio desafio) {
        return desafioService.update(id, desafio)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteDesafio(@PathVariable Long id) {
        try {
            desafioService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
