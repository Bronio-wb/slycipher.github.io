package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.service.CursoService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/cursos")
public class CursoController {
    private final CursoService cursoService;

    public CursoController(CursoService cursoService) {
        this.cursoService = cursoService;
    }

    @GetMapping
    public String list(Model model) {
        List<Curso> cursos = cursoService.findAll();
        model.addAttribute("cursos", cursos);
        return "cursos/list";
    }

    @GetMapping("/{id}")
    public String show(@PathVariable Long id, Model model) {
        Curso curso = cursoService.findById(id).orElse(null);
        model.addAttribute("curso", curso);
        return "cursos/show";
    }
}
