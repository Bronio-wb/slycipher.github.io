package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.InscripcionCurso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface InscripcionCursoRepository extends JpaRepository<InscripcionCurso, Integer> {
    
    // Buscar inscripción específica de un usuario en un curso
    Optional<InscripcionCurso> findByUsuarioIdAndCursoId(Integer usuarioId, Integer cursoId);
    
    // Verificar si un usuario está inscrito en un curso
    boolean existsByUsuarioIdAndCursoId(Integer usuarioId, Integer cursoId);
    
    // Obtener todas las inscripciones de un usuario
    List<InscripcionCurso> findByUsuarioId(Integer usuarioId);
    
    // Obtener todas las inscripciones activas de un usuario
    List<InscripcionCurso> findByUsuarioIdAndEstado(Integer usuarioId, String estado);
    
    // Obtener todos los estudiantes inscritos en un curso
    List<InscripcionCurso> findByCursoId(Integer cursoId);
    
    // Contar inscripciones de un curso
    long countByCursoId(Integer cursoId);
    
    // Contar inscripciones activas de un usuario
    long countByUsuarioIdAndEstado(Integer usuarioId, String estado);
    
    // Obtener inscripciones recientes de un usuario
    @Query("SELECT i FROM InscripcionCurso i WHERE i.usuarioId = :usuarioId ORDER BY i.fechaInscripcion DESC")
    List<InscripcionCurso> findRecentInscripcionesByUsuarioId(@Param("usuarioId") Integer usuarioId);
}
