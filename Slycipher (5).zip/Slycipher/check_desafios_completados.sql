-- Verificar desafíos completados por el usuario student
USE msqlslycipherr;

-- Ver todos los registros en desafio_usuarios
SELECT * FROM desafio_usuarios;

-- Ver desafíos completados (aprobados) del usuario student (user_id = 3)
SELECT 
    du.submission_id, 
    du.user_id, 
    du.challenge_id, 
    du.estado, 
    du.puntaje, 
    du.evaluado_en,
    u.username,
    d.titulo as desafio_titulo
FROM desafio_usuarios du
LEFT JOIN usuarios u ON du.user_id = u.user_id
LEFT JOIN desafios d ON du.challenge_id = d.challenge_id
WHERE du.user_id = 3 AND du.estado = 'aprobado';

-- Insertar un desafío completado de prueba si no existe
INSERT IGNORE INTO desafio_usuarios (user_id, challenge_id, solucion_enviada, estado, puntaje, enviado_en, evaluado_en)
VALUES (3, 3, 'def es_par_o_impar(numero):\n    if numero % 2 == 0:\n        return f"El número {numero} es par"\n    else:\n        return f"El número {numero} es impar"', 'aprobado', 100, NOW(), NOW());
