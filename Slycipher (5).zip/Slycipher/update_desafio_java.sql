-- Cambiar el desafío del círculo a lenguaje Java
USE msqlslycipherr;

-- Primero ver los lenguajes disponibles
SELECT * FROM lenguajes;

-- Ver el desafío actual
SELECT d.challenge_id, d.titulo, d.language_id, l.nombre as lenguaje_actual 
FROM desafios d 
LEFT JOIN lenguajes l ON d.language_id = l.language_id 
WHERE d.titulo LIKE '%círculo%' OR d.titulo LIKE '%circulo%';

-- Actualizar el desafío a Java (language_id = 1 si Java está con id 1)
-- Primero verificamos el ID de Java
SELECT language_id, nombre FROM lenguajes WHERE nombre = 'Java';

-- Actualizar todos los desafíos que contengan "círculo" o "circulo" en el título a Java
UPDATE desafios 
SET language_id = (SELECT language_id FROM lenguajes WHERE nombre = 'Java' LIMIT 1)
WHERE titulo LIKE '%círculo%' OR titulo LIKE '%circulo%';

-- Verificar que se actualizó correctamente
SELECT d.challenge_id, d.titulo, d.language_id, l.nombre as lenguaje_nuevo 
FROM desafios d 
LEFT JOIN lenguajes l ON d.language_id = l.language_id 
WHERE d.titulo LIKE '%círculo%' OR d.titulo LIKE '%circulo%';
