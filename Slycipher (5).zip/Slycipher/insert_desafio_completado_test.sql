-- Script para insertar un desafío completado de prueba
USE msqlslycipherr;

-- Primero ver qué user_id tiene el estudiante 'student'
SELECT user_id, username FROM usuarios WHERE username = 'student';

-- Ver desafíos disponibles
SELECT challenge_id, titulo FROM desafios;

-- Insertar un desafío completado para el usuario student (asumiendo user_id = 3, challenge_id = 3)
-- Si ya existe, no hará nada por el IGNORE
INSERT IGNORE INTO desafio_usuarios (user_id, challenge_id, solucion_enviada, estado, puntaje, enviado_en, evaluado_en)
VALUES 
(3, 3, 'def es_par_o_impar(numero):\n    if numero % 2 == 0:\n        return f"El número {numero} es par"\n    else:\n        return f"El número {numero} es impar"\n\nresultado = es_par_o_impar(7)\nprint(resultado)', 'aprobado', 100, '2025-12-08 14:30:00', '2025-12-08 14:35:00');

-- Verificar que se insertó
SELECT * FROM desafio_usuarios WHERE user_id = 3;
