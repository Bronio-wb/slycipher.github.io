package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Lenguaje;
import com.slycipher.Slycipher.repository.LenguajeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LenguajeService {
    private final LenguajeRepository lenguajeRepository;

    public LenguajeService(LenguajeRepository lenguajeRepository) {
        this.lenguajeRepository = lenguajeRepository;
    }

    public List<Lenguaje> findAll() {
        return lenguajeRepository.findAll();
    }

    public Optional<Lenguaje> findById(Long id) {
        return lenguajeRepository.findById(id);
    }

    public Lenguaje save(Lenguaje lenguaje) {
        return lenguajeRepository.save(lenguaje);
    }

    public Lenguaje update(Long id, Lenguaje lenguajeDetails) {
        Lenguaje lenguaje = lenguajeRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Lenguaje no encontrado con id: " + id));
        
        lenguaje.setNombre(lenguajeDetails.getNombre());
        lenguaje.setDescripcion(lenguajeDetails.getDescripcion());
        return lenguajeRepository.save(lenguaje);
    }

    public void deleteById(Long id) {
        if (!lenguajeRepository.existsById(id)) {
            throw new RuntimeException("Lenguaje no encontrado con id: " + id);
        }
        lenguajeRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return lenguajeRepository.existsById(id);
    }
}
