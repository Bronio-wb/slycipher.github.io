package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentWebController {

    @Autowired
    private CursoService cursoService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("cursosDisponibles", cursoService.getAllCursos());
        return "student/dashboard";
    }
}
