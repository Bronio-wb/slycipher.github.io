package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.service.CursoService;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.LeccionService;
import com.slycipher.Slycipher.service.DesafioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/developer")
public class DeveloperWebController {

    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private LeccionService leccionService;
    
    @Autowired
    private DesafioService desafioService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        Usuario developer = usuarioService.getUserByUsername(authentication.getName());
        
        // Obtener cursos del desarrollador
        List<Curso> misCursos = cursoService.getAllCursos().stream()
            .filter(c -> c.getCreadoPor() != null && c.getCreadoPor().equals(developer.getUserId()))
            .collect(Collectors.toList());
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("racha", developer.getRacha() != null ? developer.getRacha() : 0);
        model.addAttribute("misCursos", misCursos.size());
        model.addAttribute("misLecciones", leccionService.getAllLecciones().size());
        model.addAttribute("misDesafios", desafioService.getAllDesafios().size());
        model.addAttribute("leccionesPendientes", 0);
        
        // Cursos recientes (últimos 5) - filtrar nulls y ordenar
        List<Curso> cursosRecientes = misCursos.stream()
            .filter(c -> c.getFechaCreacion() != null)
            .sorted((c1, c2) -> c2.getFechaCreacion().compareTo(c1.getFechaCreacion()))
            .limit(5)
            .collect(Collectors.toList());
        
        model.addAttribute("cursosRecientes", cursosRecientes);
        
        return "developer/dashboard";
    }
}
