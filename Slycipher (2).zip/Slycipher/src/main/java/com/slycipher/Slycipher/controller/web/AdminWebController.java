package com.slycipher.Slycipher.controller.web;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.service.UsuarioService;
import com.slycipher.Slycipher.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
public class AdminWebController {

    @Autowired
    private UsuarioService usuarioService;
    
    @Autowired
    private CursoService cursoService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication authentication) {
        List<Usuario> todosUsuarios = usuarioService.getAllUsuarios();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("totalUsuarios", todosUsuarios.size());
        model.addAttribute("totalCursos", cursoService.getAllCursos().size());
        model.addAttribute("usuariosActivos", todosUsuarios.stream().filter(u -> u.getActivo() != null && u.getActivo()).count());
        model.addAttribute("cursosActivos", cursoService.getAllCursos().size());
        
        // Conteo por roles para la gráfica
        model.addAttribute("countAdmin", todosUsuarios.stream().filter(u -> "ADMIN".equals(u.getRol())).count());
        model.addAttribute("countDeveloper", todosUsuarios.stream().filter(u -> "DEVELOPER".equals(u.getRol())).count());
        model.addAttribute("countStudent", todosUsuarios.stream().filter(u -> "STUDENT".equals(u.getRol())).count());
        
        // Usuarios recientes (últimos 5) - filtrar nulls y ordenar
        model.addAttribute("usuariosRecientes", todosUsuarios.stream()
            .filter(u -> u.getCreadoEn() != null)
            .sorted((u1, u2) -> u2.getCreadoEn().compareTo(u1.getCreadoEn()))
            .limit(5)
            .collect(Collectors.toList()));
        
        return "admin/dashboard";
    }

    @GetMapping("/usuarios")
    public String usuarios(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuarios", usuarioService.getAllUsuarios());
        return "admin/usuarios";
    }
    
    @GetMapping("/estadisticas")
    public String estadisticas(Model model, Authentication authentication) {
        List<Usuario> todosUsuarios = usuarioService.getAllUsuarios();
        
        model.addAttribute("username", authentication.getName());
        model.addAttribute("totalUsuarios", todosUsuarios.size());
        model.addAttribute("totalCursos", cursoService.getAllCursos().size());
        model.addAttribute("usuariosActivos", todosUsuarios.stream().filter(u -> u.getActivo() != null && u.getActivo()).count());
        model.addAttribute("cursosActivos", cursoService.getAllCursos().size());
        
        // Conteo por roles
        model.addAttribute("countAdmin", todosUsuarios.stream().filter(u -> "ADMIN".equals(u.getRol())).count());
        model.addAttribute("countDeveloper", todosUsuarios.stream().filter(u -> "DEVELOPER".equals(u.getRol())).count());
        model.addAttribute("countStudent", todosUsuarios.stream().filter(u -> "STUDENT".equals(u.getRol())).count());
        
        return "admin/estadisticas";
    }
    
    @GetMapping("/reportes")
    public String reportes(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        return "admin/reportes";
    }

    @GetMapping("/usuarios/crear")
    public String crearUsuarioForm(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuario", new Usuario());
        return "admin/crear-usuario";
    }

    @PostMapping("/usuarios/crear")
    public String crearUsuario(@ModelAttribute Usuario usuario, RedirectAttributes redirectAttributes) {
        try {
            // Verificar si el usuario ya existe
            if (usuarioService.getUserByUsername(usuario.getUsername()) != null) {
                redirectAttributes.addFlashAttribute("error", "El username ya existe");
                return "redirect:/admin/usuarios/crear";
            }
            
            // Encriptar password
            usuario.setPasswordHash(passwordEncoder.encode(usuario.getPasswordHash()));
            usuario.setCreadoEn(LocalDateTime.now());
            usuario.setActivo(true);
            
            usuarioService.createUsuario(usuario);
            redirectAttributes.addFlashAttribute("success", "Usuario creado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/crear";
        }
    }

    @GetMapping("/usuarios/{id}/editar")
    public String editarUsuarioForm(@PathVariable Long id, Model model, Authentication authentication) {
        Usuario usuario = usuarioService.getUsuarioById(id);
        if (usuario == null) {
            return "redirect:/admin/usuarios";
        }
        model.addAttribute("username", authentication.getName());
        model.addAttribute("usuario", usuario);
        return "admin/editar-usuario";
    }

    @PostMapping("/usuarios/{id}/editar")
    public String editarUsuario(@PathVariable Long id, @ModelAttribute Usuario usuario, 
                                @RequestParam(required = false) String newPassword,
                                RedirectAttributes redirectAttributes) {
        try {
            Usuario existente = usuarioService.getUsuarioById(id);
            if (existente == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // Actualizar campos
            existente.setNombre(usuario.getNombre());
            existente.setApellido(usuario.getApellido());
            existente.setEmail(usuario.getEmail());
            existente.setRol(usuario.getRol());
            existente.setFechaNacimiento(usuario.getFechaNacimiento());
            existente.setRacha(usuario.getRacha());
            
            // Cambiar password solo si se proporcionó uno nuevo
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                existente.setPasswordHash(passwordEncoder.encode(newPassword));
            }
            
            usuarioService.updateUsuario(id, existente);
            redirectAttributes.addFlashAttribute("success", "Usuario actualizado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios/" + id + "/editar";
        }
    }

    @PostMapping("/usuarios/{id}/toggle")
    public String toggleUsuario(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            if (usuario == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // Toggle activo
            usuario.setActivo(usuario.getActivo() == null || !usuario.getActivo());
            usuarioService.updateUsuario(id, usuario);
            
            redirectAttributes.addFlashAttribute("success", 
                "Usuario " + (usuario.getActivo() ? "activado" : "desactivado") + " exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al cambiar estado: " + e.getMessage());
            return "redirect:/admin/usuarios";
        }
    }

    @PostMapping("/usuarios/{id}/eliminar")
    public String eliminarUsuario(@PathVariable Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        try {
            Usuario usuario = usuarioService.getUsuarioById(id);
            if (usuario == null) {
                redirectAttributes.addFlashAttribute("error", "Usuario no encontrado");
                return "redirect:/admin/usuarios";
            }
            
            // No permitir eliminar el usuario actual
            if (usuario.getUsername().equals(authentication.getName())) {
                redirectAttributes.addFlashAttribute("error", "No puedes eliminar tu propio usuario");
                return "redirect:/admin/usuarios";
            }
            
            usuarioService.deleteUsuario(id);
            redirectAttributes.addFlashAttribute("success", "Usuario eliminado exitosamente");
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar usuario: " + e.getMessage());
            return "redirect:/admin/usuarios";
        }
    }

    @GetMapping("/cursos")
    public String cursos(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("cursos", cursoService.getAllCursos());
        return "admin/cursos";
    }

    @GetMapping("/cursos/crear")
    public String crearCursoForm(Model model, Authentication authentication) {
        model.addAttribute("username", authentication.getName());
        model.addAttribute("curso", new com.slycipher.Slycipher.model.Curso());
        return "admin/crear-curso";
    }

    @PostMapping("/cursos/crear")
    public String crearCurso(@ModelAttribute com.slycipher.Slycipher.model.Curso curso, 
                            Authentication authentication,
                            RedirectAttributes redirectAttributes) {
        try {
            // Obtener el usuario actual
            Usuario usuario = usuarioService.getUserByUsername(authentication.getName());
            curso.setCreadoPor(usuario.getUserId());
            curso.setFechaCreacion(LocalDateTime.now());
            curso.setEstado(false); // false = borrador, true = publicado
            
            cursoService.createCurso(curso);
            redirectAttributes.addFlashAttribute("success", "Curso creado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al crear curso: " + e.getMessage());
            return "redirect:/admin/cursos/crear";
        }
    }

    @GetMapping("/cursos/{id}/editar")
    public String editarCursoForm(@PathVariable Long id, Model model, Authentication authentication) {
        com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
        if (curso == null) {
            return "redirect:/admin/cursos";
        }
        model.addAttribute("username", authentication.getName());
        model.addAttribute("curso", curso);
        return "admin/editar-curso";
    }

    @PostMapping("/cursos/{id}/editar")
    public String editarCurso(@PathVariable Long id, 
                             @ModelAttribute com.slycipher.Slycipher.model.Curso curso,
                             RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Curso existente = cursoService.getCursoById(id);
            if (existente == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            existente.setTitulo(curso.getTitulo());
            existente.setDescripcion(curso.getDescripcion());
            existente.setNivel(curso.getNivel());
            existente.setEstado(curso.getEstado());
            existente.setPrecio(curso.getPrecio());
            existente.setDuracionEstimada(curso.getDuracionEstimada());
            existente.setRequisitos(curso.getRequisitos());
            
            cursoService.updateCurso(id, existente);
            redirectAttributes.addFlashAttribute("success", "Curso actualizado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al actualizar curso: " + e.getMessage());
            return "redirect:/admin/cursos/" + id + "/editar";
        }
    }

    @PostMapping("/cursos/{id}/eliminar")
    public String eliminarCurso(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            com.slycipher.Slycipher.model.Curso curso = cursoService.getCursoById(id);
            if (curso == null) {
                redirectAttributes.addFlashAttribute("error", "Curso no encontrado");
                return "redirect:/admin/cursos";
            }
            
            cursoService.deleteCurso(id);
            redirectAttributes.addFlashAttribute("success", "Curso eliminado exitosamente");
            return "redirect:/admin/cursos";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar curso: " + e.getMessage());
            return "redirect:/admin/cursos";
        }
    }
}
