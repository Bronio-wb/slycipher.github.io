package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.Leccion;
import com.slycipher.Slycipher.service.LeccionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lecciones")
@CrossOrigin(origins = "*")
public class LeccionController {
    private final LeccionService leccionService;

    public LeccionController(LeccionService leccionService) {
        this.leccionService = leccionService;
    }

    @GetMapping
    public ResponseEntity<List<Leccion>> getAllLecciones() {
        return ResponseEntity.ok(leccionService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Leccion> getLeccionById(@PathVariable Long id) {
        return leccionService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/curso/{cursoId}")
    public ResponseEntity<List<Leccion>> getLeccionesByCurso(@PathVariable Long cursoId) {
        return ResponseEntity.ok(leccionService.findByCursoId(cursoId));
    }

    @PostMapping
    public ResponseEntity<Leccion> createLeccion(@RequestBody Leccion leccion) {
        Leccion savedLeccion = leccionService.save(leccion);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedLeccion);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Leccion> updateLeccion(@PathVariable Long id, @RequestBody Leccion leccion) {
        try {
            Leccion updatedLeccion = leccionService.update(id, leccion);
            return ResponseEntity.ok(updatedLeccion);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeccion(@PathVariable Long id) {
        try {
            leccionService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
