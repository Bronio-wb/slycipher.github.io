package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Leccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LeccionRepository extends JpaRepository<Leccion, Long> {
    List<Leccion> findByCourseId(Long courseId);
}
