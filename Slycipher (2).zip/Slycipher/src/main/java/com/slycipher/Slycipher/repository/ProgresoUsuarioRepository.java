package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.ProgresoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProgresoUsuarioRepository extends JpaRepository<ProgresoUsuario, Long> {
    List<ProgresoUsuario> findByUserId(Long userId);
    List<ProgresoUsuario> findByLessonId(Long lessonId);
}
