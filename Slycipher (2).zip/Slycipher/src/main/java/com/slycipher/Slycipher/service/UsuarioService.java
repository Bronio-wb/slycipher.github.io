package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Usuario;
import com.slycipher.Slycipher.repository.UsuarioRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {
    private final UsuarioRepository usuarioRepository;

    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    public List<Usuario> findAll() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> findById(Long id) {
        return usuarioRepository.findById(id);
    }

    public Usuario save(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public void deleteById(Long id) {
        usuarioRepository.deleteById(id);
    }

    // Alias para controladores web
    public List<Usuario> getAllUsuarios() {
        return findAll();
    }
    
    // Buscar usuario por username
    public Usuario getUserByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }
    
    // Buscar usuario por email
    public Usuario findByEmail(String email) {
        return usuarioRepository.findByEmail(email).orElse(null);
    }
    
    // CRUD Methods para AdminWebController
    public Usuario createUsuario(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }
    
    public Usuario getUsuarioById(Long id) {
        return usuarioRepository.findById(id).orElse(null);
    }
    
    public Usuario updateUsuario(Long id, Usuario usuario) {
        if (usuarioRepository.existsById(id)) {
            usuario.setUserId(id);
            return usuarioRepository.save(usuario);
        }
        return null;
    }
    
    public void deleteUsuario(Long id) {
        usuarioRepository.deleteById(id);
    }
}
