package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.LogroUsuario;
import com.slycipher.Slycipher.service.LogroUsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logros-usuarios")
@CrossOrigin(origins = "*")
public class LogroUsuarioController {
    private final LogroUsuarioService logroUsuarioService;

    public LogroUsuarioController(LogroUsuarioService logroUsuarioService) {
        this.logroUsuarioService = logroUsuarioService;
    }

    @GetMapping
    public ResponseEntity<List<LogroUsuario>> getAllLogrosUsuarios() {
        return ResponseEntity.ok(logroUsuarioService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<LogroUsuario> getLogroUsuarioById(@PathVariable Long id) {
        return logroUsuarioService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<LogroUsuario>> getLogrosUsuarioByUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(logroUsuarioService.findByUsuarioId(usuarioId));
    }

    @PostMapping
    public ResponseEntity<LogroUsuario> createLogroUsuario(@RequestBody LogroUsuario logroUsuario) {
        LogroUsuario savedLogroUsuario = logroUsuarioService.save(logroUsuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedLogroUsuario);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLogroUsuario(@PathVariable Long id) {
        try {
            logroUsuarioService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
