package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Logro;
import com.slycipher.Slycipher.repository.LogroRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LogroService {
    private final LogroRepository logroRepository;

    public LogroService(LogroRepository logroRepository) {
        this.logroRepository = logroRepository;
    }

    public List<Logro> findAll() {
        return logroRepository.findAll();
    }

    public Optional<Logro> findById(Long id) {
        return logroRepository.findById(id);
    }

    public Logro save(Logro logro) {
        return logroRepository.save(logro);
    }

    public Logro update(Long id, Logro logroDetails) {
        Logro logro = logroRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Logro no encontrado con id: " + id));
        
        logro.setNombre(logroDetails.getNombre());
        logro.setDescripcion(logroDetails.getDescripcion());
        logro.setIcono(logroDetails.getIcono());
        logro.setPuntosRequeridos(logroDetails.getPuntosRequeridos());
        return logroRepository.save(logro);
    }

    public void deleteById(Long id) {
        if (!logroRepository.existsById(id)) {
            throw new RuntimeException("Logro no encontrado con id: " + id);
        }
        logroRepository.deleteById(id);
    }

    public boolean existsById(Long id) {
        return logroRepository.existsById(id);
    }
}
