package com.slycipher.Slycipher.repository;

import com.slycipher.Slycipher.model.Desafio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DesafioRepository extends JpaRepository<Desafio, Long> {
    List<Desafio> findByCourseId(Long courseId);
    List<Desafio> findByLanguageId(Long languageId);
}
