package com.slycipher.Slycipher.service;

import com.slycipher.Slycipher.model.Curso;
import com.slycipher.Slycipher.repository.CursoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CursoService {
    private final CursoRepository cursoRepository;

    public CursoService(CursoRepository cursoRepository) {
        this.cursoRepository = cursoRepository;
    }

    public List<Curso> findAll() {
        return cursoRepository.findAll();
    }

    public Optional<Curso> findById(Long id) {
        return cursoRepository.findById(id);
    }

    public Curso save(Curso curso) {
        return cursoRepository.save(curso);
    }

    public void deleteById(Long id) {
        cursoRepository.deleteById(id);
    }

    // Aliases para controladores web
    public Curso getCursoById(Long id) {
        return findById(id).orElse(null);
    }

    public List<Curso> getAllCursos() {
        return findAll();
    }

    public Curso createCurso(Curso curso) {
        return save(curso);
    }

    public Curso updateCurso(Long id, Curso curso) {
        return cursoRepository.findById(id)
            .map(existing -> {
                existing.setTitulo(curso.getTitulo());
                existing.setDescripcion(curso.getDescripcion());
                existing.setNivel(curso.getNivel());
                existing.setLanguageId(curso.getLanguageId());
                existing.setCategoryId(curso.getCategoryId());
                return save(existing);
            }).orElse(null);
    }

    public void deleteCurso(Long id) {
        deleteById(id);
    }
}
