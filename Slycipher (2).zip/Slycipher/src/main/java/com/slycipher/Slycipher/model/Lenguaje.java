package com.slycipher.Slycipher.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lenguajes")
public class Lenguaje {
    @Id
    @Column(name = "language_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long languageId;

    private String nombre;
    private String descripcion;

    public Long getLanguageId() { return languageId; }
    public void setLanguageId(Long languageId) { this.languageId = languageId; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    @OneToMany(mappedBy = "lenguaje", fetch = FetchType.LAZY)
    private List<Curso> cursos = new ArrayList<>();

    @OneToMany(mappedBy = "lenguaje", fetch = FetchType.LAZY)
    private List<Desafio> desafios = new ArrayList<>();

    public List<Curso> getCursos() { return cursos; }
    public void setCursos(List<Curso> cursos) { this.cursos = cursos; }
    public List<Desafio> getDesafios() { return desafios; }
    public void setDesafios(List<Desafio> desafios) { this.desafios = desafios; }
}
