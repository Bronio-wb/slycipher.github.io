package com.slycipher.Slycipher.controller;

import com.slycipher.Slycipher.model.ProgresoUsuario;
import com.slycipher.Slycipher.service.ProgresoUsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/progresos")
@CrossOrigin(origins = "*")
public class ProgresoUsuarioController {
    private final ProgresoUsuarioService progresoUsuarioService;

    public ProgresoUsuarioController(ProgresoUsuarioService progresoUsuarioService) {
        this.progresoUsuarioService = progresoUsuarioService;
    }

    @GetMapping
    public ResponseEntity<List<ProgresoUsuario>> getAllProgresos() {
        return ResponseEntity.ok(progresoUsuarioService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProgresoUsuario> getProgresoById(@PathVariable Long id) {
        return progresoUsuarioService.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<ProgresoUsuario>> getProgresosByUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(progresoUsuarioService.findByUsuarioId(usuarioId));
    }

    @GetMapping("/leccion/{leccionId}")
    public ResponseEntity<List<ProgresoUsuario>> getProgresosByLeccion(@PathVariable Long leccionId) {
        return ResponseEntity.ok(progresoUsuarioService.findByLeccionId(leccionId));
    }

    @PostMapping
    public ResponseEntity<ProgresoUsuario> createProgreso(@RequestBody ProgresoUsuario progreso) {
        ProgresoUsuario savedProgreso = progresoUsuarioService.save(progreso);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedProgreso);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProgresoUsuario> updateProgreso(@PathVariable Long id, @RequestBody ProgresoUsuario progreso) {
        try {
            ProgresoUsuario updatedProgreso = progresoUsuarioService.update(id, progreso);
            return ResponseEntity.ok(updatedProgreso);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProgreso(@PathVariable Long id) {
        try {
            progresoUsuarioService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
