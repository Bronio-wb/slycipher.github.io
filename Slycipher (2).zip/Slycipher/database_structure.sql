-- =============================================
-- Base de Datos: msqlslycipherr
-- SlyCipher - Plataforma de Aprendizaje de Programación
-- =============================================

-- Esta es la estructura de referencia de la base de datos
-- Si ya tienes la base de datos de Laravel, NO es necesario ejecutar este script

-- =============================================
-- Tabla: usuarios
-- =============================================
CREATE TABLE IF NOT EXISTS `usuarios` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `rol` enum('estudiante','instructor','admin') DEFAULT 'estudiante',
  `activo` tinyint(1) DEFAULT '1',
  `racha` int DEFAULT '0',
  `creado_en` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: lenguajes
-- =============================================
CREATE TABLE IF NOT EXISTS `lenguajes` (
  `language_id` bigint NOT NULL AUTO_INCREMENT,
  `nombre_lenguaje` varchar(50) NOT NULL,
  `descripcion` text,
  `icono` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`language_id`),
  UNIQUE KEY `nombre_lenguaje` (`nombre_lenguaje`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: categorias
-- =============================================
CREATE TABLE IF NOT EXISTS `categorias` (
  `category_id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: cursos
-- =============================================
CREATE TABLE IF NOT EXISTS `cursos` (
  `course_id` bigint NOT NULL AUTO_INCREMENT,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text,
  `nivel` enum('Principiante','Intermedio','Avanzado') NOT NULL,
  `language_id` bigint NOT NULL,
  `category_id` bigint NOT NULL,
  `creado_por` bigint NOT NULL,
  `estado` tinyint(1) DEFAULT '1',
  `duracion_estimada` int DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT '0.00',
  `requisitos` text,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`course_id`),
  KEY `language_id` (`language_id`),
  KEY `category_id` (`category_id`),
  KEY `creado_por` (`creado_por`),
  CONSTRAINT `cursos_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `lenguajes` (`language_id`),
  CONSTRAINT `cursos_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categorias` (`category_id`),
  CONSTRAINT `cursos_ibfk_3` FOREIGN KEY (`creado_por`) REFERENCES `usuarios` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: lecciones
-- =============================================
CREATE TABLE IF NOT EXISTS `lecciones` (
  `lesson_id` bigint NOT NULL AUTO_INCREMENT,
  `course_id` bigint NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `contenido` text,
  `orden` int DEFAULT NULL,
  `tipo_contenido` enum('texto','video','codigo','interactivo') DEFAULT 'texto',
  `duracion_estimada` int DEFAULT NULL,
  PRIMARY KEY (`lesson_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `lecciones_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `cursos` (`course_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: desafios
-- =============================================
CREATE TABLE IF NOT EXISTS `desafios` (
  `challenge_id` bigint NOT NULL AUTO_INCREMENT,
  `lesson_id` bigint NOT NULL,
  `titulo` varchar(200) NOT NULL,
  `descripcion` text,
  `codigo_inicial` text,
  `solucion` text,
  `puntos` int DEFAULT '10',
  `dificultad` enum('Facil','Medio','Dificil') DEFAULT 'Medio',
  PRIMARY KEY (`challenge_id`),
  KEY `lesson_id` (`lesson_id`),
  CONSTRAINT `desafios_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `lecciones` (`lesson_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: desafios_usuarios
-- =============================================
CREATE TABLE IF NOT EXISTS `desafios_usuarios` (
  `submission_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `challenge_id` bigint NOT NULL,
  `codigo_enviado` text,
  `resultado` enum('Correcto','Incorrecto','Error') DEFAULT NULL,
  `fecha_envio` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`submission_id`),
  KEY `user_id` (`user_id`),
  KEY `challenge_id` (`challenge_id`),
  CONSTRAINT `desafios_usuarios_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `desafios_usuarios_ibfk_2` FOREIGN KEY (`challenge_id`) REFERENCES `desafios` (`challenge_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: progreso_usuarios
-- =============================================
CREATE TABLE IF NOT EXISTS `progreso_usuarios` (
  `progress_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `course_id` bigint NOT NULL,
  `porcentaje_completado` decimal(5,2) DEFAULT '0.00',
  `estado` enum('no_iniciado','en_progreso','completado') DEFAULT 'no_iniciado',
  `fecha_inicio` timestamp NULL DEFAULT NULL,
  `ultima_actividad` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`progress_id`),
  UNIQUE KEY `user_course_unique` (`user_id`,`course_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `progreso_usuarios_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `progreso_usuarios_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `cursos` (`course_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: logros
-- =============================================
CREATE TABLE IF NOT EXISTS `logros` (
  `achievement_id` bigint NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `icono` varchar(255) DEFAULT NULL,
  `condicion` text,
  PRIMARY KEY (`achievement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Tabla: logros_usuarios
-- =============================================
CREATE TABLE IF NOT EXISTS `logros_usuarios` (
  `user_achievement_id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `achievement_id` bigint NOT NULL,
  `fecha_obtenido` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_achievement_id`),
  UNIQUE KEY `user_achievement_unique` (`user_id`,`achievement_id`),
  KEY `achievement_id` (`achievement_id`),
  CONSTRAINT `logros_usuarios_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `usuarios` (`user_id`) ON DELETE CASCADE,
  CONSTRAINT `logros_usuarios_ibfk_2` FOREIGN KEY (`achievement_id`) REFERENCES `logros` (`achievement_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================
-- Datos de Ejemplo (Opcional)
-- =============================================

-- Insertar lenguajes
INSERT IGNORE INTO `lenguajes` (`nombre_lenguaje`, `descripcion`, `icono`) VALUES
('Java', 'Lenguaje de programación orientado a objetos', '/images/icons/java.png'),
('Python', 'Lenguaje de programación de alto nivel', '/images/icons/python.png'),
('JavaScript', 'Lenguaje de programación para desarrollo web', '/images/icons/javascript.png'),
('C++', 'Lenguaje de programación de propósito general', '/images/icons/cpp.png');

-- Insertar categorías
INSERT IGNORE INTO `categorias` (`nombre`) VALUES
('Fundamentos'),
('Desarrollo Web'),
('Estructuras de Datos'),
('Algoritmos'),
('Bases de Datos'),
('Programación Orientada a Objetos');

-- Insertar logros
INSERT IGNORE INTO `logros` (`nombre`, `descripcion`, `icono`, `condicion`) VALUES
('Primer Paso', 'Completaste tu primera lección', '/images/badges/first_step.png', 'Completar 1 lección'),
('Estudiante Dedicado', 'Mantuviste una racha de 7 días', '/images/badges/dedicated.png', 'Racha de 7 días'),
('Maestro del Código', 'Completaste 10 cursos', '/images/badges/master.png', 'Completar 10 cursos'),
('Desafío Aceptado', 'Resolviste 50 desafíos', '/images/badges/challenger.png', 'Resolver 50 desafíos');
