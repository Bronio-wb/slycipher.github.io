-- Primero eliminamos cualquier usuario existente de prueba
DELETE FROM usuarios WHERE username IN ('admin', 'developer', 'student', 'demo');

-- Insertamos usuarios de prueba con contraseñas BCrypt
-- Las contraseñas están hasheadas con BCrypt (admin123, dev123, student123, demo123)

INSERT INTO usuarios (username, nombre, apellido, email, password_hash, rol, activo, creado_en, racha) VALUES
('admin', 'Administrador', 'Sistema', 'admin@slycipher.com', '$2a$10$XqjjXg0YnQbVDM0YHkCZ9.5Kx9HEyY/yX8MzMc8xQ8VdX0aRgTfVm', 'ADMIN', true, NOW(), 0),
('developer', 'Juan', 'Developer', 'developer@slycipher.com', '$2a$10$XqjjXg0YnQbVDM0YHkCZ9.5Kx9HEyY/yX8MzMc8xQ8VdX0aRgTfVm', 'DEVELOPER', true, NOW(), 0),
('student', 'María', 'Estudiante', 'student@slycipher.com', '$2a$10$XqjjXg0YnQbVDM0YHkCZ9.5Kx9HEyY/yX8MzMc8xQ8VdX0aRgTfVm', 'STUDENT', true, NOW(), 0),
('demo', 'Demo', 'User', 'demo@example.com', '$2a$10$XqjjXg0YnQbVDM0YHkCZ9.5Kx9HEyY/yX8MzMc8xQ8VdX0aRgTfVm', 'USER', true, NOW(), 0);

SELECT 'Usuarios de prueba insertados correctamente!' as mensaje;
SELECT user_id, username, email, rol, activo FROM usuarios;
