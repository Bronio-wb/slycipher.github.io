# =====================================================
# Script de Prueba Rápida - SlyCipher API
# =====================================================
# Este script prueba todos los endpoints de la API
# =====================================================

$baseUrl = "http://localhost:8080/api"
$headers = @{
    "Content-Type" = "application/json"
}

Write-Host "=======================================" -ForegroundColor Cyan
Write-Host "  Prueba de API - SlyCipher" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host ""

# Función para hacer peticiones
function Test-Endpoint {
    param(
        [string]$Name,
        [string]$Url,
        [string]$Method = "GET",
        [object]$Body = $null
    )
    
    Write-Host "🔍 Probando: $Name" -ForegroundColor Yellow
    Write-Host "   URL: $Url" -ForegroundColor Gray
    Write-Host "   Método: $Method" -ForegroundColor Gray
    
    try {
        if ($Method -eq "GET") {
            $response = Invoke-RestMethod -Uri $Url -Method $Method -Headers $headers
        } else {
            $bodyJson = $Body | ConvertTo-Json
            $response = Invoke-RestMethod -Uri $Url -Method $Method -Headers $headers -Body $bodyJson
        }
        
        Write-Host "   ✅ Éxito - Status: 200 OK" -ForegroundColor Green
        
        if ($response -is [Array]) {
            Write-Host "   📊 Resultados: $($response.Count) elementos" -ForegroundColor Cyan
        }
        
        Write-Host ""
        return $response
    }
    catch {
        Write-Host "   ❌ Error: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
        return $null
    }
}

# Verificar si el servidor está corriendo
Write-Host "🔌 Verificando conexión al servidor..." -ForegroundColor Yellow
try {
    $health = Invoke-RestMethod -Uri "http://localhost:8080/actuator/health" -ErrorAction SilentlyContinue
    Write-Host "✅ Servidor en línea" -ForegroundColor Green
}
catch {
    Write-Host "❌ Servidor no disponible" -ForegroundColor Red
    Write-Host "   Asegúrate de que la aplicación esté corriendo en http://localhost:8080" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Presiona Enter para salir..."
    Read-Host
    exit 1
}
Write-Host ""

# =====================================================
# PRUEBAS DE CATEGORIAS
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CATEGORÍAS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$categorias = Test-Endpoint -Name "Listar categorías" -Url "$baseUrl/categorias"

if ($categorias -and $categorias.Count -gt 0) {
    $categoriaId = $categorias[0].categoryId
    Test-Endpoint -Name "Obtener categoría por ID" -Url "$baseUrl/categorias/$categoriaId"
}

# =====================================================
# PRUEBAS DE LENGUAJES
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  LENGUAJES" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$lenguajes = Test-Endpoint -Name "Listar lenguajes" -Url "$baseUrl/lenguajes"

if ($lenguajes -and $lenguajes.Count -gt 0) {
    $lenguajeId = $lenguajes[0].languageId
    Test-Endpoint -Name "Obtener lenguaje por ID" -Url "$baseUrl/lenguajes/$lenguajeId"
}

# =====================================================
# PRUEBAS DE CURSOS
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  CURSOS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$cursos = Test-Endpoint -Name "Listar cursos" -Url "$baseUrl/cursos"

if ($cursos -and $cursos.Count -gt 0) {
    $cursoId = $cursos[0].courseId
    Test-Endpoint -Name "Obtener curso por ID" -Url "$baseUrl/cursos/$cursoId"
}

# =====================================================
# PRUEBAS DE LECCIONES
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  LECCIONES" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$lecciones = Test-Endpoint -Name "Listar lecciones" -Url "$baseUrl/lecciones"

if ($lecciones -and $lecciones.Count -gt 0) {
    $leccionId = $lecciones[0].lessonId
    Test-Endpoint -Name "Obtener lección por ID" -Url "$baseUrl/lecciones/$leccionId"
    
    if ($cursos -and $cursos.Count -gt 0) {
        $cursoId = $cursos[0].courseId
        Test-Endpoint -Name "Obtener lecciones por curso" -Url "$baseUrl/lecciones/curso/$cursoId"
    }
}

# =====================================================
# PRUEBAS DE DESAFIOS
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  DESAFÍOS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$desafios = Test-Endpoint -Name "Listar desafíos" -Url "$baseUrl/desafios"

if ($desafios -and $desafios.Count -gt 0) {
    $desafioId = $desafios[0].challengeId
    Test-Endpoint -Name "Obtener desafío por ID" -Url "$baseUrl/desafios/$desafioId"
}

# =====================================================
# PRUEBAS DE LOGROS
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  LOGROS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$logros = Test-Endpoint -Name "Listar logros" -Url "$baseUrl/logros"

if ($logros -and $logros.Count -gt 0) {
    $logroId = $logros[0].achievementId
    Test-Endpoint -Name "Obtener logro por ID" -Url "$baseUrl/logros/$logroId"
}

# =====================================================
# PRUEBAS DE PROGRESO
# =====================================================
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  PROGRESO DE USUARIOS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

$progresos = Test-Endpoint -Name "Listar progresos" -Url "$baseUrl/progresos"

if ($progresos -and $progresos.Count -gt 0) {
    $progresoId = $progresos[0].progressId
    Test-Endpoint -Name "Obtener progreso por ID" -Url "$baseUrl/progresos/$progresoId"
}

# =====================================================
# RESUMEN
# =====================================================
Write-Host ""
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host "  RESUMEN DE PRUEBAS" -ForegroundColor Cyan
Write-Host "═══════════════════════════════════════" -ForegroundColor Cyan
Write-Host ""

Write-Host "📊 Datos encontrados en la base de datos:" -ForegroundColor Yellow
Write-Host "   Categorías: $($categorias.Count)" -ForegroundColor White
Write-Host "   Lenguajes: $($lenguajes.Count)" -ForegroundColor White
Write-Host "   Cursos: $($cursos.Count)" -ForegroundColor White
Write-Host "   Lecciones: $($lecciones.Count)" -ForegroundColor White
Write-Host "   Desafíos: $($desafios.Count)" -ForegroundColor White
Write-Host "   Logros: $($logros.Count)" -ForegroundColor White
Write-Host "   Progresos: $($progresos.Count)" -ForegroundColor White
Write-Host ""

if ($categorias.Count -eq 0 -or $lenguajes.Count -eq 0) {
    Write-Host "⚠️  NOTA: Algunas tablas están vacías" -ForegroundColor Yellow
    Write-Host "   Puedes agregar datos usando el archivo database_structure.sql" -ForegroundColor Yellow
    Write-Host "   o mediante los endpoints POST de la API" -ForegroundColor Yellow
} else {
    Write-Host "✅ API funcionando correctamente con datos existentes" -ForegroundColor Green
}

Write-Host ""
Write-Host "🌐 Endpoints disponibles:" -ForegroundColor Cyan
Write-Host "   - Categorías: $baseUrl/categorias" -ForegroundColor White
Write-Host "   - Lenguajes: $baseUrl/lenguajes" -ForegroundColor White
Write-Host "   - Cursos: $baseUrl/cursos" -ForegroundColor White
Write-Host "   - Lecciones: $baseUrl/lecciones" -ForegroundColor White
Write-Host "   - Desafíos: $baseUrl/desafios" -ForegroundColor White
Write-Host "   - Logros: $baseUrl/logros" -ForegroundColor White
Write-Host "   - Progresos: $baseUrl/progresos" -ForegroundColor White
Write-Host "   - Logros Usuarios: $baseUrl/logros-usuarios" -ForegroundColor White
Write-Host ""

Write-Host "📖 Para más ejemplos, revisa el archivo API_EXAMPLES.http" -ForegroundColor Cyan
Write-Host ""
Write-Host "Presiona Enter para salir..."
Read-Host
