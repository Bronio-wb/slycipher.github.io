# 🚀 Inicio Rápido - SlyCipher Java

## ⚡ Ejecución en 3 Pasos

### 1️⃣ Verificar Requisitos
Asegúrate de tener instalado:
- ✅ Java 17 o superior
- ✅ Maven 3.6+
- ✅ MySQL 8.0+ (corriendo con la BD `msqlslycipherr`)

### 2️⃣ Ejecutar el Proyecto

**Opción A - Script Automático (Recomendado):**
```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
.\run.ps1
```

**Opción B - Comando Directo:**
```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
mvn spring-boot:run
```

### 3️⃣ Probar la API

**Opción A - Script de Prueba:**
```powershell
.\test-api.ps1
```

**Opción B - Navegador:**
```
http://localhost:8080/api/categorias
http://localhost:8080/api/lenguajes
http://localhost:8080/api/cursos
```

**Opción C - PowerShell:**
```powershell
curl http://localhost:8080/api/categorias
```

---

## 📋 Comandos Útiles

### Compilar el proyecto
```powershell
mvn clean install
```

### Ejecutar la aplicación
```powershell
mvn spring-boot:run
```

### Generar JAR ejecutable
```powershell
mvn clean package
java -jar target/Slycipher-0.0.1-SNAPSHOT.jar
```

### Ver dependencias
```powershell
mvn dependency:tree
```

### Limpiar proyecto
```powershell
mvn clean
```

---

## 🌐 URLs Importantes

| Servicio | URL | Descripción |
|----------|-----|-------------|
| **Aplicación** | http://localhost:8080 | Página principal |
| **API Categorías** | http://localhost:8080/api/categorias | CRUD de categorías |
| **API Lenguajes** | http://localhost:8080/api/lenguajes | CRUD de lenguajes |
| **API Cursos** | http://localhost:8080/api/cursos | CRUD de cursos |
| **API Lecciones** | http://localhost:8080/api/lecciones | CRUD de lecciones |
| **API Desafíos** | http://localhost:8080/api/desafios | CRUD de desafíos |
| **API Logros** | http://localhost:8080/api/logros | CRUD de logros |
| **API Progresos** | http://localhost:8080/api/progresos | CRUD de progreso usuarios |

---

## 🧪 Pruebas Rápidas

### Crear una Categoría
```powershell
$body = @{
    nombre = "Desarrollo Web"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8080/api/categorias" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body
```

### Obtener todos los Cursos
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/cursos"
```

### Obtener Lecciones de un Curso
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/lecciones/curso/1"
```

---

## 🔧 Solución de Problemas

### Error: Puerto 8080 en uso
```powershell
# Ver qué proceso usa el puerto 8080
netstat -ano | findstr :8080

# Matar el proceso (usa el PID del comando anterior)
taskkill /PID <PID> /F
```

### Error: No se puede conectar a MySQL
1. Verifica que MySQL esté corriendo:
   ```powershell
   Get-Service MySQL*
   ```

2. Verifica las credenciales en `application.properties`:
   ```properties
   spring.datasource.url=jdbc:mysql://localhost:3306/msqlslycipherr
   spring.datasource.username=root
   spring.datasource.password=tu_password
   ```

3. Prueba la conexión:
   ```powershell
   mysql -u root -p msqlslycipherr
   ```

### Error: Base de datos no existe
```sql
CREATE DATABASE msqlslycipherr CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Error: Tablas no existen
Ejecuta el script SQL:
```powershell
mysql -u root -p msqlslycipherr < database_structure.sql
```

---

## 📚 Archivos de Ayuda

| Archivo | Descripción |
|---------|-------------|
| `README_JAVA.md` | Documentación completa del proyecto |
| `MIGRACION_COMPLETADA.md` | Resumen de la migración PHP → Java |
| `API_EXAMPLES.http` | Ejemplos de peticiones HTTP |
| `database_structure.sql` | Estructura de la base de datos |
| `run.ps1` | Script de ejecución interactivo |
| `test-api.ps1` | Script de prueba de la API |

---

## 🎯 Próximos Pasos

Después de verificar que todo funciona:

1. ✅ Revisar los datos en la base de datos
2. ✅ Probar los endpoints con Postman o cURL
3. ✅ Revisar los logs de la aplicación
4. ⏳ Agregar validaciones y manejo de errores
5. ⏳ Implementar autenticación JWT
6. ⏳ Crear el frontend (React, Vue, Angular, etc.)
7. ⏳ Agregar tests unitarios

---

## 💡 Tips

- Usa `Ctrl+C` para detener la aplicación
- Los cambios en el código se recargan automáticamente con Spring Boot DevTools
- Revisa los logs en la consola para debugging
- Usa el archivo `API_EXAMPLES.http` con la extensión REST Client de VS Code

---

## 📞 Ayuda

Si encuentras problemas:
1. Revisa los logs de la aplicación
2. Verifica que la base de datos esté corriendo
3. Consulta el archivo `README_JAVA.md` para más detalles
4. Revisa el archivo `MIGRACION_COMPLETADA.md` para ver qué se implementó

---

**¡Listo para empezar! 🚀**
