# =====================================================
# Script Simple de Inicio - SlyCipher
# No requiere Maven instalado (usa Maven Wrapper)
# =====================================================

Write-Host "=======================================" -ForegroundColor Cyan
Write-Host "  SlyCipher - Iniciar Aplicacion" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host ""

# Cambiar al directorio del proyecto
$projectPath = "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
Set-Location $projectPath

Write-Host "Directorio: $projectPath" -ForegroundColor Green
Write-Host ""

# Verificar si Java esta instalado
Write-Host "Verificando Java..." -ForegroundColor Yellow
try {
    $javaVersion = java -version 2>&1 | Select-Object -First 1
    Write-Host "Java encontrado: $javaVersion" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: Java no esta instalado" -ForegroundColor Red
    Write-Host "Instala Java 17+ desde: https://adoptium.net/" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Presiona Enter para salir..."
    Read-Host
    exit 1
}
Write-Host ""

# Verificar si existe mvnw.cmd
if (Test-Path ".\mvnw.cmd") {
    Write-Host "Usando Maven Wrapper (mvnw.cmd)" -ForegroundColor Green
    $mvnCmd = ".\mvnw.cmd"
}
elseif (Get-Command mvn -ErrorAction SilentlyContinue) {
    Write-Host "Usando Maven instalado" -ForegroundColor Green
    $mvnCmd = "mvn"
}
else {
    Write-Host "ERROR: No se encontro Maven ni Maven Wrapper" -ForegroundColor Red
    Write-Host ""
    Write-Host "Opcion 1: Instala Maven desde https://maven.apache.org/download.cgi" -ForegroundColor Yellow
    Write-Host "Opcion 2: Descarga el Maven Wrapper para el proyecto" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Presiona Enter para salir..."
    Read-Host
    exit 1
}
Write-Host ""

Write-Host "Iniciando la aplicacion..." -ForegroundColor Yellow
Write-Host "La aplicacion estara disponible en: http://localhost:8080" -ForegroundColor Green
Write-Host "API REST disponible en: http://localhost:8080/api/" -ForegroundColor Green
Write-Host ""
Write-Host "Presiona Ctrl+C para detener la aplicacion" -ForegroundColor Yellow
Write-Host ""

# Ejecutar la aplicacion
& $mvnCmd spring-boot:run

Write-Host ""
Write-Host "Aplicacion detenida" -ForegroundColor Yellow
Write-Host ""
Write-Host "Presiona Enter para salir..."
Read-Host
