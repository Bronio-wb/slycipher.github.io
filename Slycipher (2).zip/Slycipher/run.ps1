# =====================================================
# Script de Inicio - SlyCipher Java Spring Boot
# =====================================================

Write-Host "=======================================" -ForegroundColor Cyan
Write-Host "  SlyCipher - Spring Boot Application  " -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan
Write-Host ""

# Cambiar al directorio del proyecto
$projectPath = "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
Set-Location $projectPath

Write-Host "📂 Directorio del proyecto: $projectPath" -ForegroundColor Green
Write-Host ""

# Verificar si Maven está instalado
Write-Host "🔍 Verificando Maven..." -ForegroundColor Yellow
try {
    $mavenVersion = mvn --version 2>&1 | Select-Object -First 1
    Write-Host "✅ Maven encontrado: $mavenVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Maven no está instalado o no está en el PATH" -ForegroundColor Red
    Write-Host "   Por favor instala Maven desde: https://maven.apache.org/download.cgi" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Verificar si Java está instalado
Write-Host "🔍 Verificando Java..." -ForegroundColor Yellow
try {
    $javaVersion = java -version 2>&1 | Select-Object -First 1
    Write-Host "✅ Java encontrado: $javaVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Java no está instalado o no está en el PATH" -ForegroundColor Red
    Write-Host "   Por favor instala Java 17+ desde: https://adoptium.net/" -ForegroundColor Yellow
    exit 1
}
Write-Host ""

# Menú de opciones
Write-Host "Selecciona una opción:" -ForegroundColor Cyan
Write-Host "1. Compilar el proyecto (mvn clean install)" -ForegroundColor White
Write-Host "2. Ejecutar la aplicación (mvn spring-boot:run)" -ForegroundColor White
Write-Host "3. Compilar y ejecutar" -ForegroundColor White
Write-Host "4. Generar JAR y ejecutar" -ForegroundColor White
Write-Host "5. Ver logs de la aplicación" -ForegroundColor White
Write-Host "6. Salir" -ForegroundColor White
Write-Host ""

$opcion = Read-Host "Ingresa el número de opción"

switch ($opcion) {
    "1" {
        Write-Host ""
        Write-Host "🔨 Compilando el proyecto..." -ForegroundColor Yellow
        mvn clean install
        Write-Host ""
        Write-Host "✅ Compilación completada" -ForegroundColor Green
    }
    "2" {
        Write-Host ""
        Write-Host "🚀 Iniciando la aplicación..." -ForegroundColor Yellow
        Write-Host "   La aplicación estará disponible en: http://localhost:8080" -ForegroundColor Green
        Write-Host "   API REST disponible en: http://localhost:8080/api/" -ForegroundColor Green
        Write-Host ""
        Write-Host "⌨️  Presiona Ctrl+C para detener la aplicación" -ForegroundColor Yellow
        Write-Host ""
        mvn spring-boot:run
    }
    "3" {
        Write-Host ""
        Write-Host "🔨 Compilando el proyecto..." -ForegroundColor Yellow
        mvn clean install
        if ($LASTEXITCODE -eq 0) {
            Write-Host ""
            Write-Host "✅ Compilación exitosa" -ForegroundColor Green
            Write-Host ""
            Write-Host "🚀 Iniciando la aplicación..." -ForegroundColor Yellow
            Write-Host "   La aplicación estará disponible en: http://localhost:8080" -ForegroundColor Green
            Write-Host "   API REST disponible en: http://localhost:8080/api/" -ForegroundColor Green
            Write-Host ""
            Write-Host "⌨️  Presiona Ctrl+C para detener la aplicación" -ForegroundColor Yellow
            Write-Host ""
            mvn spring-boot:run
        } else {
            Write-Host ""
            Write-Host "❌ Error en la compilación" -ForegroundColor Red
        }
    }
    "4" {
        Write-Host ""
        Write-Host "🔨 Generando JAR..." -ForegroundColor Yellow
        mvn clean package -DskipTests
        if ($LASTEXITCODE -eq 0) {
            Write-Host ""
            Write-Host "✅ JAR generado exitosamente" -ForegroundColor Green
            Write-Host ""
            Write-Host "🚀 Ejecutando el JAR..." -ForegroundColor Yellow
            Write-Host "   La aplicación estará disponible en: http://localhost:8080" -ForegroundColor Green
            Write-Host "   API REST disponible en: http://localhost:8080/api/" -ForegroundColor Green
            Write-Host ""
            Write-Host "⌨️  Presiona Ctrl+C para detener la aplicación" -ForegroundColor Yellow
            Write-Host ""
            java -jar target/Slycipher-0.0.1-SNAPSHOT.jar
        } else {
            Write-Host ""
            Write-Host "❌ Error al generar el JAR" -ForegroundColor Red
        }
    }
    "5" {
        Write-Host ""
        Write-Host "📋 Logs de la aplicación (últimas 50 líneas):" -ForegroundColor Yellow
        Write-Host ""
        $logPath = "$projectPath\logs\application.log"
        if (Test-Path $logPath) {
            Get-Content $logPath -Tail 50
        } else {
            Write-Host "   No se encontraron logs en: $logPath" -ForegroundColor Red
            Write-Host "   Los logs se mostrarán en la consola cuando ejecutes la aplicación" -ForegroundColor Yellow
        }
    }
    "6" {
        Write-Host ""
        Write-Host "👋 ¡Hasta luego!" -ForegroundColor Cyan
        exit 0
    }
    default {
        Write-Host ""
        Write-Host "Opcion invalida" -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Presiona Enter para salir..."
Read-Host
