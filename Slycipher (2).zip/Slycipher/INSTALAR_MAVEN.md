# Instrucciones para Instalar Maven en Windows

## Opcion 1: Usar el Script start.ps1 (Recomendado - No requiere instalar Maven)

```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
.\start.ps1
```

Este script usa el Maven Wrapper (mvnw.cmd) que ya viene con el proyecto, por lo que NO necesitas instalar Maven.

---

## Opcion 2: Instalar Maven Manualmente

### Paso 1: Descargar Maven
1. Ve a: https://maven.apache.org/download.cgi
2. Descarga "apache-maven-3.9.x-bin.zip"

### Paso 2: Extraer Maven
1. Extrae el ZIP en `C:\Program Files\Apache\maven`
2. Deberia quedar algo como: `C:\Program Files\Apache\maven\apache-maven-3.9.x`

### Paso 3: Configurar Variables de Entorno

**Abrir Variables de Entorno:**
1. Presiona `Windows + Pause/Break` o busca "Variables de entorno"
2. Click en "Variables de entorno..."

**Agregar MAVEN_HOME:**
1. En "Variables del sistema", click en "Nueva..."
2. Nombre: `MAVEN_HOME`
3. Valor: `C:\Program Files\Apache\maven\apache-maven-3.9.x`
4. Click "Aceptar"

**Agregar a PATH:**
1. En "Variables del sistema", selecciona "Path"
2. Click "Editar..."
3. Click "Nuevo"
4. Agrega: `%MAVEN_HOME%\bin`
5. Click "Aceptar" en todas las ventanas

### Paso 4: Verificar Instalacion

**Abre una NUEVA ventana de PowerShell** (importante para que cargue las nuevas variables):

```powershell
mvn --version
```

Deberia mostrar algo como:
```
Apache Maven 3.9.x
Maven home: C:\Program Files\Apache\maven\apache-maven-3.9.x
Java version: 17.x.x
```

---

## Opcion 3: Instalar Maven con Chocolatey (Rapido)

Si tienes Chocolatey instalado:

```powershell
choco install maven
```

Si no tienes Chocolatey, instalalo primero:

```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```

Luego:
```powershell
choco install maven
```

---

## Verificar Java

Antes de todo, asegurate de tener Java 17 o superior:

```powershell
java -version
```

Si no tienes Java, descargalo desde: https://adoptium.net/

---

## Ejecutar el Proyecto

### Sin Maven instalado (Recomendado):
```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
.\start.ps1
```

### Con Maven instalado:
```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
mvn spring-boot:run
```

### Alternativa con Maven Wrapper:
```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
.\mvnw.cmd spring-boot:run
```

---

## Troubleshooting

### Error: "mvn no se reconoce como comando"
- Reinicia PowerShell despues de instalar Maven
- Verifica que Maven este en el PATH
- Usa `start.ps1` que no requiere Maven instalado

### Error: "JAVA_HOME no esta configurado"
1. Encuentra donde esta instalado Java:
   ```powershell
   Get-Command java | Select-Object Source
   ```
2. Agrega JAVA_HOME a las variables de entorno apuntando a la carpeta de Java (sin \bin)

### Error: "Puerto 8080 en uso"
```powershell
# Ver que proceso usa el puerto 8080
netstat -ano | findstr :8080

# Matar el proceso (reemplaza <PID> con el numero que viste)
taskkill /PID <PID> /F
```

---

## Solucion Mas Rapida

**Si solo quieres ejecutar el proyecto AHORA:**

```powershell
cd "c:\Users\Lesly\Downloads\phpslycipher\Slycipher"
.\mvnw.cmd spring-boot:run
```

Este comando funciona SIN necesidad de instalar Maven, usando el wrapper que ya esta en el proyecto.
