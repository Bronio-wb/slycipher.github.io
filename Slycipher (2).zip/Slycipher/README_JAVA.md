# Slycipher - Java Spring Boot Migration

## Descripción
SlyCipher es una plataforma web interactiva diseñada para facilitar el aprendizaje de lenguajes de programación como Java, JavaScript, Python y C++. Este proyecto es la migración de la versión original en PHP/Laravel a Java con Spring Boot.

## Tecnologías Utilizadas
- Java 17
- Spring Boot 3.x
- Spring Data JPA
- Spring Security
- MySQL 8.0
- Maven
- Thymeleaf

## Estructura del Proyecto
```
src/
├── main/
│   ├── java/
│   │   └── com/
│   │       └── slycipher/
│   │           └── Slycipher/
│   │               ├── controller/      # Controladores REST API
│   │               ├── dto/            # Data Transfer Objects
│   │               ├── model/          # Entidades JPA
│   │               ├── repository/     # Repositorios JPA
│   │               ├── security/       # Configuración de seguridad
│   │               ├── service/        # Lógica de negocio
│   │               └── SlycipherApplication.java
│   └── resources/
│       ├── application.properties
│       ├── static/                     # CSS, JS, imágenes
│       └── templates/                  # Plantillas Thymeleaf
```

## Entidades del Sistema

### 1. Usuario (usuarios)
- `user_id`: ID único del usuario
- `username`: Nombre de usuario
- `nombre`, `apellido`: Nombre completo
- `email`: Correo electrónico
- `password_hash`: Contraseña encriptada
- `fecha_nacimiento`: Fecha de nacimiento
- `rol`: Rol del usuario (estudiante, instructor, admin)
- `activo`: Estado del usuario
- `racha`: Días consecutivos de actividad
- `creado_en`: Fecha de registro

### 2. Lenguaje (lenguajes)
- `language_id`: ID del lenguaje
- `nombre_lenguaje`: Nombre (Java, Python, etc.)
- `descripcion`: Descripción del lenguaje
- `icono`: Ruta del ícono

### 3. Categoria (categorias)
- `category_id`: ID de la categoría
- `nombre`: Nombre de la categoría

### 4. Curso (cursos)
- `course_id`: ID del curso
- `titulo`: Título del curso
- `descripcion`: Descripción detallada
- `nivel`: Nivel (Principiante, Intermedio, Avanzado)
- `language_id`: Relación con lenguaje
- `category_id`: Relación con categoría
- `creado_por`: ID del usuario creador
- `estado`: Activo/Inactivo
- `duracion_estimada`: Duración en minutos
- `precio`: Precio del curso
- `requisitos`: Requisitos previos
- `fecha_creacion`: Fecha de creación

### 5. Leccion (lecciones)
- `lesson_id`: ID de la lección
- `course_id`: Relación con curso
- `titulo`: Título de la lección
- `contenido`: Contenido de la lección
- `orden`: Orden dentro del curso
- `tipo_contenido`: Tipo (texto, video, código)
- `duracion_estimada`: Duración en minutos

### 6. Desafio (desafios)
- `challenge_id`: ID del desafío
- `lesson_id`: Relación con lección
- `titulo`: Título del desafío
- `descripcion`: Descripción del desafío
- `codigo_inicial`: Código de inicio
- `solucion`: Solución esperada
- `puntos`: Puntos otorgados
- `dificultad`: Nivel de dificultad

### 7. ProgresoUsuario (progreso_usuarios)
- `progress_id`: ID del progreso
- `user_id`: Relación con usuario
- `course_id`: Relación con curso
- `porcentaje_completado`: Porcentaje (0-100)
- `estado`: Estado del progreso
- `fecha_inicio`: Fecha de inicio
- `ultima_actividad`: Última actividad

### 8. Logro (logros)
- `achievement_id`: ID del logro
- `nombre`: Nombre del logro
- `descripcion`: Descripción
- `icono`: Ruta del ícono
- `condicion`: Condición para obtenerlo

### 9. LogroUsuario (logros_usuarios)
- `user_achievement_id`: ID de la relación
- `user_id`: Relación con usuario
- `achievement_id`: Relación con logro
- `fecha_obtenido`: Fecha de obtención

## API REST Endpoints

### Categorías
- `GET /api/categorias` - Listar todas las categorías
- `GET /api/categorias/{id}` - Obtener categoría por ID
- `POST /api/categorias` - Crear nueva categoría
- `PUT /api/categorias/{id}` - Actualizar categoría
- `DELETE /api/categorias/{id}` - Eliminar categoría

### Lenguajes
- `GET /api/lenguajes` - Listar todos los lenguajes
- `GET /api/lenguajes/{id}` - Obtener lenguaje por ID
- `POST /api/lenguajes` - Crear nuevo lenguaje
- `PUT /api/lenguajes/{id}` - Actualizar lenguaje
- `DELETE /api/lenguajes/{id}` - Eliminar lenguaje

### Cursos
- `GET /api/cursos` - Listar todos los cursos
- `GET /api/cursos/{id}` - Obtener curso por ID
- `POST /api/cursos` - Crear nuevo curso
- `PUT /api/cursos/{id}` - Actualizar curso
- `DELETE /api/cursos/{id}` - Eliminar curso

### Lecciones
- `GET /api/lecciones` - Listar todas las lecciones
- `GET /api/lecciones/{id}` - Obtener lección por ID
- `GET /api/lecciones/curso/{cursoId}` - Obtener lecciones por curso
- `POST /api/lecciones` - Crear nueva lección
- `PUT /api/lecciones/{id}` - Actualizar lección
- `DELETE /api/lecciones/{id}` - Eliminar lección

### Desafíos
- `GET /api/desafios` - Listar todos los desafíos
- `GET /api/desafios/{id}` - Obtener desafío por ID
- `POST /api/desafios` - Crear nuevo desafío
- `PUT /api/desafios/{id}` - Actualizar desafío
- `DELETE /api/desafios/{id}` - Eliminar desafío

### Logros
- `GET /api/logros` - Listar todos los logros
- `GET /api/logros/{id}` - Obtener logro por ID
- `POST /api/logros` - Crear nuevo logro
- `PUT /api/logros/{id}` - Actualizar logro
- `DELETE /api/logros/{id}` - Eliminar logro

### Progreso de Usuarios
- `GET /api/progresos` - Listar todos los progresos
- `GET /api/progresos/{id}` - Obtener progreso por ID
- `GET /api/progresos/usuario/{usuarioId}` - Obtener progresos por usuario
- `GET /api/progresos/curso/{cursoId}` - Obtener progresos por curso
- `POST /api/progresos` - Crear nuevo progreso
- `PUT /api/progresos/{id}` - Actualizar progreso
- `DELETE /api/progresos/{id}` - Eliminar progreso

### Logros de Usuarios
- `GET /api/logros-usuarios` - Listar todos los logros de usuarios
- `GET /api/logros-usuarios/{id}` - Obtener logro de usuario por ID
- `GET /api/logros-usuarios/usuario/{usuarioId}` - Obtener logros por usuario
- `POST /api/logros-usuarios` - Asignar logro a usuario
- `DELETE /api/logros-usuarios/{id}` - Eliminar logro de usuario

## Configuración de la Base de Datos

### 1. Crear la base de datos en MySQL
```sql
CREATE DATABASE msqlslycipherr CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. Configurar application.properties
Edita el archivo `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:mysql://localhost:3306/msqlslycipherr?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=tu_password
```

### 3. Importar datos existentes
Si ya tienes datos en la base de datos PHP/Laravel, no es necesario hacer nada. El proyecto Java utilizará la misma base de datos.

## Cómo Ejecutar el Proyecto

### Requisitos Previos
- Java 17 o superior
- Maven 3.6+
- MySQL 8.0+
- Git

### Paso 1: Clonar el repositorio
```bash
cd c:\Users\Lesly\Downloads\phpslycipher\Slycipher
```

### Paso 2: Configurar la base de datos
Asegúrate de que MySQL esté corriendo y que la base de datos `msqlslycipherr` exista con todas las tablas.

### Paso 3: Compilar el proyecto
```bash
mvn clean install
```

### Paso 4: Ejecutar la aplicación
```bash
mvn spring-boot:run
```

O si prefieres ejecutar el JAR:
```bash
java -jar target/Slycipher-0.0.1-SNAPSHOT.jar
```

### Paso 5: Acceder a la aplicación
- **Web**: http://localhost:8080
- **API REST**: http://localhost:8080/api/

## Pruebas con Postman o cURL

### Ejemplo: Obtener todas las categorías
```bash
curl -X GET http://localhost:8080/api/categorias
```

### Ejemplo: Crear una nueva categoría
```bash
curl -X POST http://localhost:8080/api/categorias \
  -H "Content-Type: application/json" \
  -d '{"nombre":"Web Development"}'
```

### Ejemplo: Obtener todos los cursos
```bash
curl -X GET http://localhost:8080/api/cursos
```

## Diferencias con la Versión PHP

| Característica | PHP/Laravel | Java/Spring Boot |
|---------------|-------------|------------------|
| Framework | Laravel 11 | Spring Boot 3.x |
| ORM | Eloquent | JPA/Hibernate |
| Routing | routes/web.php | @RestController annotations |
| Templates | Blade | Thymeleaf |
| Migrations | Laravel Migrations | JPA (ddl-auto: none) |
| Security | Laravel Auth | Spring Security |
| API Response | JSON | JSON + DTOs |

## Próximos Pasos

1. ✅ Modelos (Entities) creados
2. ✅ Repositorios (Repositories) creados
3. ✅ Servicios (Services) con CRUD completo
4. ✅ Controladores REST (Controllers) implementados
5. ✅ DTOs creados para transferencia de datos
6. ✅ Configuración de seguridad mejorada
7. ⏳ Implementar autenticación JWT (opcional)
8. ⏳ Crear vistas con Thymeleaf
9. ⏳ Agregar validaciones con Bean Validation
10. ⏳ Implementar manejo de excepciones global
11. ⏳ Agregar pruebas unitarias
12. ⏳ Documentar API con Swagger/OpenAPI

## Notas Importantes

- El proyecto utiliza la **misma base de datos** que la versión PHP
- Las contraseñas deben estar encriptadas con BCrypt
- CORS está habilitado para desarrollo local
- CSRF está deshabilitado para facilitar pruebas de API
- Los endpoints de API están bajo `/api/`

## Solución de Problemas

### Error: "Package does not match expected package"
Este es un error de configuración de IDE. Los archivos funcionarán correctamente al ejecutar con Maven.

### Error: "Table doesn't exist"
Verifica que la base de datos tenga todas las tablas creadas desde la migración de Laravel.

### Error de conexión a MySQL
- Verifica que MySQL esté corriendo
- Confirma las credenciales en `application.properties`
- Verifica que el puerto 3306 esté disponible

## Contacto y Soporte
Para preguntas o soporte, contacta al equipo de desarrollo.
