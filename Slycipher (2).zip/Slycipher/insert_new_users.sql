-- Script para insertar los nuevos usuarios con credenciales personalizadas
-- Base de datos: msqlslycipherr

USE msqlslycipherr;

-- Admin1 - Juan Lopez (admin1@example.com / Adminsly123!)
INSERT INTO usuarios (username, nombre, apellido, email, password_hash, rol, creado_en, activo)
VALUES (
    'juanlopez',
    'Juan',
    'Lopez',
    'admin1@example.com',
    '$2a$10$yJ3vLZQxH9YxGxYxGxYxGeDpN.QXrZ.3QXrZ.3QXrZ.3QXrZ.3QXrZ.',  -- Este hash es temporal
    'ADMIN',
    NOW(),
    true
);

-- Developer1 (dev1@example.com / Devsly123!)
INSERT INTO usuarios (username, nombre, apellido, email, password_hash, rol, creado_en, activo)
VALUES (
    'developer1',
    'Carlos',
    'Desarrollador',
    'dev1@example.com',
    '$2a$10$yJ3vLZQxH9YxGxYxGxYxGeDpN.QXrZ.3QXrZ.3QXrZ.3QXrZ.3QXrZ.',  -- Este hash es temporal
    'DEVELOPER',
    NOW(),
    true
);

-- Student1 (est1@example.com / Estsly123*)
INSERT INTO usuarios (username, nombre, apellido, email, password_hash, rol, creado_en, activo)
VALUES (
    'estudiante1',
    'Ana',
    'Estudiante',
    'est1@example.com',
    '$2a$10$yJ3vLZQxH9YxGxYxGxYxGeDpN.QXrZ.3QXrZ.3QXrZ.3QXrZ.3QXrZ.',  -- Este hash es temporal
    'STUDENT',
    NOW(),
    true
);

-- Nota: Los hashes de contraseñas son temporales. 
-- Necesitas ejecutar el servidor Spring Boot para que genere los hashes correctos.
